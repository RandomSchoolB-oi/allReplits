return function()
	local self = {}
	self.EventQueue = {}
	self.EventSolvers = {}
	
	self.FireEvent = function(eventName, ...)
		table.insert(self.EventQueue, {
			Name = eventName,
			Parameters = {...},
		})
	end

	self.CreateSolver = function(solverName, solverFunction)
		self.EventSolvers[solverName] = solverFunction
	end
	
	self.SolveEvents = function()
		for _, event in ipairs(self.EventQueue) do
			local solver = self.EventSolvers[event.Name]
			if solver then
				solver(unpack(event.Parameters))
			end
		end
	end

	return self
end