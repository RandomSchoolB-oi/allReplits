local module = {}

module.new = function(r,g,b,a)
	return {
		R = r or 0,
		G = g or 0,
		B = b or 0,
		A = a or 1,
	}
end

module.Apply = function(color)
	local m = 255
	love.graphics.setColor(color.R * m, color.G * m, color.B * m, color.A * m)
end

module.from255 = function(r,g,b,a)
	return {
		R = (r or 0)/255,
		G = (g or 0)/255,
		B = (b or 0)/255,
		A = (a or 255)/255,
	}
end

module.Lerp = function(a,b,x)
	return module.new(
		b.R-a.R*x+a.R,
		b.G-a.G*x+a+G,
		b.B-a.B*x+a.B,
		b.A-a.A*x+a.A
	)
end

return module