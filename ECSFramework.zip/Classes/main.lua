local Path = "Classes"
Vector2 = require(Path..".Vector2")
Color = require(Path..".Color")
CFrame = require(Path..".CFrame")