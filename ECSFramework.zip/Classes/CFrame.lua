local module = {}
module.__index = module

local pi = math.pi
local halfPi = pi/2

module.new = function(x, y, r)
	if type(x) == "table" then
		x,y,r = x.X, x.Y, x.R
	end

	return setmetatable({
		X = x or 0,
		Y = y or 0,
		R = r or 0,

		UpVector = Vector2.fromAngle(r or 0),
		RightVector = Vector2.fromAngle((r or 0) + halfPi),
	}, module)
end

module.lookAt = function(x1,y1, x2,y2)
	return module.new(x1,y1,math.atan2(y2-y1,x2-x1))
end

function module:__add(other)
	return module.new(self.X + other.X, self.Y + other.Y, self.R)
end

function module:__sub(other)
	return module.new(self.X - other.X, self.Y - other.Y, self.R)
end

function module:__mul(other)
	if type(self) == "number" then
		self = module.new(self, self)
	end
	if type(other) == "number" then
		other = module.new(other, other)
	end

	local movedX = self.RightVector * other.X
	local movedY = self.UpVector * other.Y
	
	return module.new(
		self.X + (movedX.X + movedY.X),
		self.Y + (movedX.Y + movedY.Y),
		self.R + other.R
	)
end

return module