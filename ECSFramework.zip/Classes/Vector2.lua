local module = {}
module.__index = module

module.new = function(x, y)
	if type(x) == "table" then
		x,y = x.X, x.Y
	end
	
	return setmetatable({
		X = x or 0,
		Y = y or 0,
	}, module)
end

module.fromAngle = function(r)
	return module.new(math.sin(r), -math.cos(r))
end

function module:length()
	if self._length then
		return self._length
	end
	self._length = math.sqrt(self.X^2+self.Y^2)
	return self._length
end

function module:unit()
	if self._unit then
		return self._unit
	end
	self._unit = self/self:length()
	return self._unit
end

function module:toAngle()
	return math.atan2(self.Y, self.X)
end

function module:__add(other)
	return module.new(self.X + other.X, self.Y + other.Y)
end

function module:__sub(other)
	return module.new(self.X - other.X, self.Y - other.Y)
end

function module:__mul(other)
	if type(self) == "number" then
		self = module.new(self, self)
	end
	if type(other) == "number" then
		other = module.new(other, other)
	end

	return module.new(self.X * other.X, self.Y * other.Y)
end

function module:__div(other)
	if type(self) == "number" then
		self = module.new(self, self)
	end
	if type(other) == "number" then
		other = module.new(other, other)
	end

	return module.new(self.X / other.X, self.Y / other.Y)
end

function module:__unm()
	return module.new(-self.X, -self.Y)
end

return module