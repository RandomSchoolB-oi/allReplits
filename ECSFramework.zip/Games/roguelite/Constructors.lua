local module = {}

module.player = {
	{TransformComponent},
	{RectangleComponent},
	{PlayerControllerComponent},
}

return module