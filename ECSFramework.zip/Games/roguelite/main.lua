GameWorld = World()
GameWorld.AddSystem(TextSystem)
GameWorld.AddSystem(RectangleSystem)
GameWorld.AddSystem(ImageSystem)
GameWorld.AddSystem(PhysicsSystem)
GameWorld.AddSystem(PlayerControllerSystem)

DoTransformBoxes = true

require("Games.roguelite.Components.main")
require("Games.roguelite.Systems.main")

Constructors = require("Games.roguelite.Constructors")

-- GameWorld.AddSystem(GunSystem)
-- GameWorld.AddSystem(BulletSystem)
-- GameWorld.AddSystem(EnemiesSystem)

LocalPlayer = GameWorld.ConstructEntity(Constructors.player)

local slot1 = GameWorld.ConstructEntity({{TransformComponent}, {RectangleComponent}, {ToolSlotComponent, 1}})
local slot1 = GameWorld.ConstructEntity({{TransformComponent}, {RectangleComponent}, {ToolSlotComponent, 2}})
local slot1 = GameWorld.ConstructEntity({{TransformComponent}, {RectangleComponent}, {ToolSlotComponent, 3}})
local slot1 = GameWorld.ConstructEntity({{TransformComponent}, {RectangleComponent}, {ToolSlotComponent, 4}})

-- GameWorld.ConstructEntity(Constructors.gun)

function love.update(dt)
	GameWorld.Update(dt)
	
	-- if math.random(1, 100)  == 1 then
	-- 	local newEnemy = GameWorld.ConstructEntity(Constructors.enemy)
	
	-- 	newEnemy.GetComponent("Transform").Data.CFrame = CFrame.new(math.random(0, 40)/10, math.random(0, 40)/10)
	-- end
end

local lnW = 1/CellSize.X
function love.draw()
	love.graphics.setLineWidth(lnW)
	love.graphics.scale(CellSize.X, CellSize.Y)
	GameWorld.Draw()
end

function love.keypressed(key)
	GameWorld.InputBegan(key, false)
end
function love.keyreleased(key)
	GameWorld.InputEnded(key, false)
end
function love.mousepressed(x,y,button)
	GameWorld.InputBegan(button, true)
end
function love.mousereleased(x,y,button)
	GameWorld.InputEnded(button, true)
end