return function(slotId)
	local newComp = Component("ToolSlot", {
		SlotId = slotId,
	})

	return newComp
end