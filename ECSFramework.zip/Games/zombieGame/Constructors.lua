local module = {}


module.player = {
	{TransformComponent},
	{RectangleComponent},
	{PlayerControllerComponent},
}

module.enemy = {
	{TransformComponent},
	{RectangleComponent},
	{EnemyComponent},
}

module.bullet = {
	{TransformComponent, nil, Vector2.new(0.2, 0.05)},
	{RigidBodyComponent},
	{BulletComponent, 2, 25},
	{RectangleComponent, Color.from255(255, 255, 111)},
}
module.gun = {
	{TransformComponent, nil, Vector2.new(1,1)},
	{ToolComponent, "Gun"},
	{GunComponent, "TestGun", module.bullet, 8, 64, 0.3, 0.35},

	{ImageComponent, "Games/zombieGame/Images/Assault Rifle.png", Color.from255(255, 255, 255)},
	-- {RectangleComponent, Color.from255(120, 120, 120)},
}

return module