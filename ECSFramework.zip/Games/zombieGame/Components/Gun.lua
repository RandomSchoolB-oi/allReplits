return function(gunName, bullet, magSize, reserveSize, gripOffset, bulletOffset)
	local newComp = Component("Gun", {
		GunName = gunName,
		Bullet = bullet,
		
		MagSize = MagSize,
		AmmoReserveSize = reserveSize,
		Ammo = magSize,

		GripOffset = gripOffset,
		BulletOffset = bulletOffset,
	})
	
	return newComp
end