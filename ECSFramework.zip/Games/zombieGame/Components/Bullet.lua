return function(bulletSpeed, damage)
	local newComp = Component("Bullet", {
		Speed = bulletSpeed or 1,
		Damage = damage or 25,
		Lifetime = 0,
	})
	
	return newComp
end