return function(toolCategory)
	local newComp = Component("Tool", {
		Category = toolCategory or "Tool",
	})

	return newComp
end