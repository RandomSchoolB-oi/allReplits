local Path = "Games.zombieGame.Components"
ToolComponent = require(Path..".Tool")
GunComponent = require(Path..".Gun")
BulletComponent = require(Path..".Bullet")
EnemyComponent = require(Path..".Enemy")