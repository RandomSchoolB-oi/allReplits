return function(walkspeed, health)
	local newComp = Component("Enemy", {
		MaxHealth = health or 100,
		Health = health or 100,

		Speed = walkspeed or 0.5,
	})

	return newComp
end