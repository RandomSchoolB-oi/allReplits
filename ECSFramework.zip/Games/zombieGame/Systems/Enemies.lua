local self = System({"Transform", "Enemy"})

self.Update = function(entity, dt)
	local entityTransform = entity.GetComponent("Transform")
	local enemyComponent = entity.GetComponent("Enemy")
	local playerTransform = LocalPlayer.GetComponent("Transform")

	local eCF = entityTransform.Data.CFrame
	local pCF = playerTransform.Data.CFrame
	
	local looking = CFrame.lookAt(eCF.X, eCF.Y, pCF.X, pCF.Y)
	
	entityTransform.Data.CFrame = looking * CFrame.new(enemyComponent.Data.Speed * dt, 0)
end

self.Draw = function(entity)
	local transform = entity.GetComponent("Transform")
	local enemyComponent = entity.GetComponent("Enemy")

	local size = transform.Data.Scale
	local cf = transform.Data.CFrame

	local x, y = cf.X - size.X/2, cf.Y - size.Y/2
	local w, h = size.X, .1
	local p = (enemyComponent.Data.Health / enemyComponent.Data.MaxHealth)

	love.graphics.setColor(100, 0, 0)
	love.graphics.rectangle("fill", x, y, w, h)
	love.graphics.setColor(255, 0, 0)
	love.graphics.rectangle("fill", x, y, w * p, h)
end

self.Damage = function(entity, damage)
	local enemy = entity.GetComponent("Enemy")
	enemy.Data.Health = enemy.Data.Health - damage
	if enemy.Data.Health <= 0 then
		entity:Destroy()
	end
end

return self