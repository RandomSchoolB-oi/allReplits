local self = System({"Transform", "Gun", "Tool"})

self.Update = function(entity, dt)
	local entityTransform = entity.GetComponent("Transform")
	local gun = entity.GetComponent("Gun")
	local playerTransform = LocalPlayer.GetComponent("Transform")
	local pCF = playerTransform.Data.CFrame
	local mx, my = love.mouse.getPosition()
	local newCF = CFrame.lookAt(pCF.X, pCF.Y, mx, my) * CFrame.new(gun.Data.GripOffset, 0)
	entityTransform.Data.CFrame = newCF
	local normalized = newCF.R + math.pi/2
	if normalized < math.pi and normalized > 0 then
		entityTransform.Data.Scale.Y = math.abs(entityTransform.Data.Scale.Y)
	else
		entityTransform.Data.Scale.Y = -math.abs(entityTransform.Data.Scale.Y)
	end
end

self.InputBegan = function(entity, key, isMouse)
	local gun = entity.GetComponent("Gun")
	
	if isMouse and key == 1 then
		local dir = entity.GetComponent("Transform").Data.CFrame.RightVector

		local gunTransform = entity.GetComponent("Transform")
		local gCF = gunTransform.Data.CFrame
		
		local newProjectile = GameWorld.ConstructEntity(gun.Data.Bullet)
		newProjectile.GetComponent("Transform").Data.CFrame = gCF * CFrame.new(gun.Data.BulletOffset, 0)
		newProjectile.GetComponent("RigidBody").Data.Velocity = dir * newProjectile.GetComponent("Bullet").Data.Speed
	end
end

return self