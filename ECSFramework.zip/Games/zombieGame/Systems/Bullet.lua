local self = System({"Transform", "RigidBody", "Bullet"})

self.Update = function(entity, dt)
	local transform = entity.GetComponent("Transform")
	local rigidBody = entity.GetComponent("RigidBody")
	local bullet = entity.GetComponent("Bullet")

	local cf, v = transform.Data.CFrame, rigidBody.Data.Velocity

	bullet.Data.Lifetime = bullet.Data.Lifetime + dt 
	if bullet.Data.Lifetime > 6 then
		entity.Destroy()
		return
	end

	for _, enemy in ipairs(self.World.GetEntities({"Enemy"})) do
		if PhysicsSystem.AreTouching(entity, enemy, "circle") then
			EnemiesSystem.Damage(enemy, bullet.Data.Damage)
			entity:Destroy()
			return
		end
	end
	
	transform.Data.CFrame = CFrame.lookAt(cf.X, cf.Y, cf.X + v.X, cf.Y + v.Y)
end

return self