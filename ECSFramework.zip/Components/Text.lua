return function()
	local newComp = Component("Text", {
		Text = "hi mom",
	})
	
	return newComp
end