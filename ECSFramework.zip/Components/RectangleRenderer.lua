return function(color)
	local newComp = Component("RectangleRenderer", {
		Color = color or Color.new(1,1,1),
	})

	return newComp
end