local red = Color.new(1, 0, 0)
local green = Color.new(0, 1, 0)
DrawTransform = function(transform)
	if not DoTransformBoxes then return end
	local x = transform.Data.CFrame.X
	local y = transform.Data.CFrame.Y
	local w = transform.Data.Scale.X
	local h = transform.Data.Scale.Y

	love.graphics.push()
	love.graphics.translate(x, y)

	Color.Apply(red)
	love.graphics.rectangle("line", -w*0.5, -h*0.5, w, h)
	
	love.graphics.rotate(transform.Data.CFrame.R)
	Color.Apply(green)
	love.graphics.rectangle("line", -w*0.5, -h*0.5, w, h)
	
	love.graphics.pop()
end

return function(cf, scale)
	local newComp = Component("Transform", {
		Scale = scale or Vector2.new(1, 1),
		CFrame = cf or CFrame.new(0, 0, 0),
	})
	
	return newComp
end