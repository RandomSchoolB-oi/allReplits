return function()
	local newComp = Component("RigidBody", {
		Velocity = Vector2.new(0, 0),
	})

	return newComp
end