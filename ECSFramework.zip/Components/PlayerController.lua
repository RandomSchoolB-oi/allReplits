return function()
	local newComp = Component("PlayerController", {
		WalkSpeed = 1,
	})

	return newComp
end