return function(imagePath, tintColor)
	local newComp = Component("ImageRenderer", {
		TintColor = tintColor or Color.new(1,1,1),
		ImagePath = imagePath
	})

	return newComp
end