local Path = "Components"
TextComponent = require(Path..".Text")
TransformComponent = require(Path..".Transform")
RectangleComponent = require(Path..".RectangleRenderer")
ImageComponent = require(Path..".ImageRenderer")
RigidBodyComponent = require(Path..".RigidBody")
PlayerControllerComponent = require(Path..".PlayerController")