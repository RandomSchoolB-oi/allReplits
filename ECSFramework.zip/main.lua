function love.load()
	love.window.setMode(400,400)
	
	require("Classes.main")
	require("ECS.main")
	require("Systems.main")
	require("Components.main")
	CellSize = Vector2.new(100,100)

	local getMousePositionOriginal = love.mouse.getPosition
	love.mouse.getPosition = function()
		local x, y = getMousePositionOriginal()
		return x / CellSize.X, y / CellSize.Y
	end

	-- require("Games.zombieGame.main")
	require("Games.roguelite.main")
end