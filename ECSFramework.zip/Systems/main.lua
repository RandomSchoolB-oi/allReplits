local Path = "Systems"
TextSystem = require(Path..".TextSystem")
RectangleSystem = require(Path..".RectangleRenderer")
ImageSystem = require(Path..".ImageRenderer")
PhysicsSystem = require(Path..".Physics")
PlayerControllerSystem = require(Path..".PlayerControllerSystem")