local self = System({"Transform", "Text"})

self.Update = function(entity, dt)
	local textComponent = entity.GetComponent("Text")
	if entity.PrevText ~= textComponent.Text then
		if entity.TextObject then
			entity.TextObject:release()
			entity.TextObject = nil
		end

		-- entity.TextObject = love
	end
end

self.Draw = function(entity)
	local textComponent = entity.GetComponent("Text")
	local transformComponent = entity.GetComponent("Transform")

	love.graphics.rectangle("line", 
		transformComponent.Data.CFrame.X, transformComponent.Data.CFrame.Y, 
		transformComponent.Data.Scale.X, transformComponent.Data.Scale.Y
	)
end

return self