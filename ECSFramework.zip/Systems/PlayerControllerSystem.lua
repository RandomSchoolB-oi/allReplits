local self = System({"Transform", "PlayerController"})

self.Update = function(entity, dt)
	local transform = entity.GetComponent("Transform")
	local playerController = entity.GetComponent("PlayerController")

	local moveDirection = Vector2.new(0, 0)

	local upPressed = (love.keyboard.isDown("w") or love.keyboard.isDown("up")) and 1 or 0
	local downPressed = (love.keyboard.isDown("s") or love.keyboard.isDown("down")) and 1 or 0

	local leftPressed = (love.keyboard.isDown("a") or love.keyboard.isDown("left")) and 1 or 0
	local rightPressed = (love.keyboard.isDown("d") or love.keyboard.isDown("right")) and 1 or 0

	local moveAmt = dt*playerController.Data.WalkSpeed
	transform.Data.CFrame = transform.Data.CFrame + Vector2.new((rightPressed - leftPressed)*moveAmt, (downPressed - upPressed)*moveAmt)
end

return self