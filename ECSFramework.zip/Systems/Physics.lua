local self = System({"Transform", "RigidBody"})

self.AreTouching = function(a,b,mode) -- aabbCheck
	-- mode, min, max, circle, regular

	local transform1 = a.GetComponent("Transform")
	local transform2 = b.GetComponent("Transform")

	local pos1 = Vector2.new(transform1.Data.CFrame.X, transform1.Data.CFrame.Y)
	local pos2 = Vector2.new(transform2.Data.CFrame.X, transform2.Data.CFrame.Y)

	if mode == "circle" then
		local radius1 = transform1.Data.Scale:length()
		local radius2 = transform2.Data.Scale:length()
		local dist = (pos1 - pos2):length()
		return dist < (radius1+radius2) * 0.5
	else
		local size1 = transform1.Data.Scale
		local size2 = transform2.Data.Scale

		if mode == "min" then
			local x1 = math.min(size1.X, size1.Y)
			local x2 = math.min(size2.X, size2.Y)
			size1 = Vector2.new(x1,x1)
			size2 = Vector2.new(x2,x2)
		elseif mode == "max" then
			local x1 = math.max(size1.X, size1.Y)
			local x2 = math.max(size2.X, size2.Y)
			size1 = Vector2.new(x1,x1)
			size2 = Vector2.new(x2,x2)
		end

		local bigSize = (size1+size2)*0.5
		local dist = (pos1-pos2)
		dist.X = math.abs(dist.X)
		dist.Y = math.abs(dist.Y)

		return dist.X < bigSize.X and dist.Y < bigSize.Y
	end
end

self.Update = function(entity, dt)
	local transform = entity.GetComponent("Transform")
	local rigidBody = entity.GetComponent("RigidBody")

	transform.Data.CFrame = transform.Data.CFrame + rigidBody.Data.Velocity * dt
end

self.Draw = function(entity)
	local transform = entity.GetComponent("Transform")
	local rigidBody = entity.GetComponent("RigidBody")

	love.graphics.setColor(255, 0, 0)
	love.graphics.line(
		(transform.Data.CFrame.X),
		(transform.Data.CFrame.Y),

		(transform.Data.CFrame.X + rigidBody.Data.Velocity.X), 
		(transform.Data.CFrame.Y + rigidBody.Data.Velocity.Y)
	)
end

return self