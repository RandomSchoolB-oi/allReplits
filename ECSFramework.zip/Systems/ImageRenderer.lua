local self = System({"Transform", "ImageRenderer"})

local loadedImages = {}

self.Update = function(entity, dt)
	local imageRenderer = entity.GetComponent("ImageRenderer")
	local imagePath = imageRenderer.Data.ImagePath
	if imageRenderer.LastImagePath ~= imagePath then
		local image = loadedImages[imagePath] or love.graphics.newImage(imagePath)
		loadedImages[imagePath] = image
		
		imageRenderer.DrawableImage = image
		imageRenderer.LastImagePath = imagePath
	end
end

self.Draw = function(entity)
	local imageRenderer = entity.GetComponent("ImageRenderer")
	local transform = entity.GetComponent("Transform")

	if not imageRenderer.DrawableImage then
		return
	end
	
	Color.Apply(imageRenderer.Data.TintColor)

	local x = transform.Data.CFrame.X
	local y = transform.Data.CFrame.Y
	local w = transform.Data.Scale.X
	local h = transform.Data.Scale.Y

	local imageSizeX, imageSizeY = imageRenderer.DrawableImage:getDimensions()

	local scaledX = w/imageSizeX
	local scaledY = h/imageSizeY
	
	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(transform.Data.CFrame.R)
	
	love.graphics.draw(imageRenderer.DrawableImage, -w*0.5, -h*0.5, 0, scaledX, scaledY)
	love.graphics.pop()

	DrawTransform(transform, true)
end

return self