local self = System({"Transform", "RectangleRenderer"})

self.Draw = function(entity)
	local rectangle = entity.GetComponent("RectangleRenderer")
	local transform = entity.GetComponent("Transform")
	
	Color.Apply(rectangle.Data.Color)

	local x = transform.Data.CFrame.X
	local y = transform.Data.CFrame.Y
	local w = transform.Data.Scale.X
	local h = transform.Data.Scale.Y

	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(transform.Data.CFrame.R)
	
	love.graphics.rectangle("fill", -w*0.5, -h*0.5, w, h)
	love.graphics.pop()
	
	DrawTransform(transform, true)
end

return self