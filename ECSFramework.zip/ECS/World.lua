local UniqueID = 0
function GetUniqueID()
	UniqueID = UniqueID + 1
	return UniqueID
end

return function()
	local self = {}
	self.ID = GetUniqueID()
	self.Entities = {}
	self.Systems = {}
	
	self.AddEntity = function(entity)
		table.insert(self.Entities, entity)
	end
	self.AddSystem = function(system)
		system.World = self
		table.insert(self.Systems, system)
	end

	self.ConstructEntity = function(components)
		local newEntity = Entity()
		for i,v in ipairs(components) do
			local newComponent = v[1](unpack(v,2))
			newEntity.AddComponent(newComponent)
		end
		self.AddEntity(newEntity)
		return newEntity
	end

	self.EntityMatches = function(entity, required)
		for _, component in ipairs(required) do
			if not entity.HasA(component) then
				return false
			end
		end
		return true
	end
	
	self.GetEntities = function(requires)
		local matching = {}
		for _, entity in ipairs(self.Entities) do
			if self.EntityMatches(entity, requires) then
				table.insert(matching, entity)
			end
		end
		return matching
	end

	local function callEntityFunction(fName, ...)
		for _, system in ipairs(self.Systems) do
			local f = system[fName]
			if f then
				for _, entity in ipairs(self.Entities) do
					if self.EntityMatches(entity, system.RequiredComponents) then
						f(entity, ...)
					end
				end
			end
		end
	end
	
	self.Update = function(dt)
		for i = #self.Entities, 1, -1 do
			local entity = self.Entities[i]
			if entity.Remove then
				table.remove(self.Entities, i)
			end
		end

		callEntityFunction("Update", dt)
	end

	self.Draw = function()
		callEntityFunction("Draw")
	end

	self.InputBegan = function(button, isMouse)
		callEntityFunction("InputBegan", button, isMouse)
	end
	self.InputEnded = function(button, isMouse)
		callEntityFunction("InputEnded", button, isMouse)
	end
	
	return self
end