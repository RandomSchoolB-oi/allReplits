return function()
	local self = {}
	self.ID = GetUniqueID()
	self.Components = {}

	self.AddComponent = function(component)
		self.Components[component.ComponentName] = component
		return component
	end
	self.GetComponent = function(componentName)
		return self.Components[componentName]
	end

	self.HasA = function(componentName)
		return not not self.Components[componentName]
	end

	self.Destroy = function()
		self.Remove = true
	end
	
	return self
end