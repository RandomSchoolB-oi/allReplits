local ECSPath = "ECS"
Entity = require(ECSPath..".Entity")
Component = require(ECSPath..".Component")
System = require(ECSPath..".System")
World = require(ECSPath..".World")