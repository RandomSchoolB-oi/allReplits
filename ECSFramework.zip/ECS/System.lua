return function(requiredComponents)
	local self = {}
	self.RequiredComponents = requiredComponents

	self.Update = function(entity, dt)
	end

	self.Draw = function(entity)
	end
	
	return self
end