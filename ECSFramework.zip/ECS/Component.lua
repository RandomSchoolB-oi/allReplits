return function(componentName, data)
	local self = {}
	self.ComponentName = componentName
	self.Data = data or {}
	
	return self
end