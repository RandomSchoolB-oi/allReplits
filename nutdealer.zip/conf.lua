function love.conf(t)
	config = t
	config.modules.joystick = false
	config.modules.physics = false
end