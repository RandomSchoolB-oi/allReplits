local module = {}
module.__index = module

module.new = function(scene)
	local self = setmetatable({}, module)
	self.maid = maid.new()
	self.scene = scene

	self.size = vector2.new(100, 100)
	self.enabled = false

	return self
end

function module:moveCamera(playerPos)
	local screenSize = vector2.new(love.graphics.getDimensions())
	local newPosition = vector2.new()

	if screenSize.x < self.size.x then
		newPosition.x = screenSize.x/2
	elseif screenSize.x > self.size.x then
		-- clamped playerPos
		local half = screenSize.x/2
		newPosition.x = math.clamp(playerPos.x, half, self.size.x-half)
	end

	if screenSize.y < self.size.y then
		newPosition.y = screenSize.y/2
	elseif screenSize.y > self.size.y then
		-- clamped playerPos
		local half = screenSize.y/2
		newPosition.y = math.clamp(playerPos.y, half, self.size.y-half)
	end

	self.camera.position = newPosition
end

function module:destroy()
	self.maid:destroy()
end

module.init = function()
	instance.addClass("room", module)
end

return module