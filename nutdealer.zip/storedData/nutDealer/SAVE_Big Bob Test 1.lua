return {
    ["flags"] = {
        ["introduction"] = true,
        ["talkBox"] = true,
    },
    ["playerPosition"] = {
        ["y"] = 164.65969266632,
        ["x"] = 251.852394901,
    },
}