Vector2 = {}
Vector2.__index = Vector2

clamp = function(a,b,c)
	return math.min(math.max(a, b), b)
end

Vector2.new = function(x,y, isUnit)
	local vector = {
		X = x or 0,
		Y = y or 0,
	}
	vector.Magnitude = math.sqrt(vector.X ^ 2 + vector.Y ^ 2)
	local highestVector = math.max(math.abs(vector.X), math.abs(vector.Y))

	if not isUnit then
	--print(vector.X, vector.Y, highestVector)
		vector.Unit = Vector2.new(vector.X / highestVector, vector.Y / highestVector, true)
	end
	return setmetatable(vector, Vector2)
end

function Vector2:__sub(other)
	return Vector2.new(self.X - other.X, self.Y - other.Y)
end
function Vector2:__add(other)
	return Vector2.new(self.X + other.X, self.Y + other.Y)
end
function Vector2:__mul(other)
	return Vector2.new(self.X * other, self.Y * other)
end
function Vector2:__div(other)
	return Vector2.new(self.X / other, self.Y / other)
end
function Vector2:__unm()
	return self * -1
end


function Vector2:__call()
	return self.X, self.Y
end