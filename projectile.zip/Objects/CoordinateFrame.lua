CFrame = {}
CFrame.__index = CFrame

CFrame.new = function(x,y,r)
	local cf = {
		Position = Vector2.new(x,y), 
		R = r or 0
	}
	cf.X = cf.Position.X
	cf.Y = cf.Position.Y

	--local lx,ly = cf.R*(math.cos(math.deg(cf.R))), cf.R*(math.sin(math.deg(cf.R)))
	--cf.LookVector = Vector2.new(lx,ly)
	local lx,ly = math.cos(cf.R), math.sin(cf.R)
	cf.LookVector = -Vector2.new(lx,ly)

	local rx,ry = math.cos(cf.R + (math.pi / 2)), math.sin(cf.R + (math.pi / 2))
	cf.RightVector = Vector2.new(rx,ry)
	
	return setmetatable(cf, CFrame)
end

CFrame.lookAt = function(x1,y1, x2, y2)
	local angle = math.atan2(y2 - y1, x2- x1)

	return CFrame.new(x1, y1, angle)
end

function CFrame:__sub(other)
	return CFrame.new(self.X - other.X, self.Y - other.Y, self.R)
end
function CFrame:__add(other)
	return CFrame.new(self.X + other.X, self.Y + other.Y, self.R)
end

--function CFrame:__mul(other)
--	local angleX, angleY = math.cos(self.R), math.sin(self.R)
--
--	return CFrame.new(
--		self.X + (angleX * other.X), 
--		self.Y + (angleY * other.Y), 
--		self.R + other.R)
--end

function CFrame:__call()
	return self.X, self.Y, self.R
end