Color3 = {}
Color3.__index = Color3

Color3.new = function(r,g,b)
	local color = {
		R = r or 1,
		G = g or 1,
		B = b or 1,
	}
	color.R = color.R * 255
	color.G = color.G * 255
	color.B = color.B * 255

	return setmetatable(color, Color3)
end

function Color3:__call()
	love.graphics.setColor(self.R, self.G, self.B)
end