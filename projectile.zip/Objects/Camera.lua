Camera = {}
Camera.__index = Camera

function Camera.new()
	local cam = {}
	cam.CFrame = CFrame.new(0, 0)

	return cam
end