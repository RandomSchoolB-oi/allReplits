require("Objects.CoordinateFrame") 
require("Objects.Vector2") 
require("Objects.Color3") 
require("Objects.Camera") 
require("Objects.Part") 
require("Objects.Projectile")

sx,sy = 300,300
function love.load()
	love.window.setMode(sx*2,sy*2)
end

local mouseX,mouseY = love.mouse.getPosition()

local Player = Instance.new()
Player.Size = Vector2.new(50,50)

local part2 = Instance.new()
part2.Size = Vector2.new(30,25)

local part3 = Instance.new()

camera = Camera.new()

local line = {}
for i=1,0 do 
	local newPart = Instance.new()
	newPart.Size = Vector2.new(10,10)
	newPart.Shape = "Circle"
	line[#line+1] = newPart
end

local elapsedTime = 0

function love.update(dt)
	elapsedTime = elapsedTime + dt

	mouseX, mouseY = love.mouse.getPosition()
	mouseX, mouseY = Player.CFrame.X + mouseX - sx, Player.CFrame.Y + mouseY - sy
	local mousePos = Vector2.new(mouseX, mouseY)
	-- character mover
	if love.keyboard.isDown("w") then
		Player.CFrame = Player.CFrame + Player.CFrame.LookVector * 100 * dt
	end

	Player.CFrame = CFrame.lookAt(Player.CFrame.X, Player.CFrame.Y, mouseX, mouseY)
	part2.CFrame = Player.CFrame + Player.CFrame.LookVector * 35

	camera.CFrame = Player.CFrame

	local power = (part2.Position - mousePos).Magnitude
	for i,v in pairs(line) do
		local frontOfPlayer = part2.CFrame + part2.CFrame.LookVector * (50 * (power/200)) * i
		local SetY = CFrame.new(frontOfPlayer.X, frontOfPlayer.Y - (i ^ 3), frontOfPlayer.R)
		v.CFrame = SetY
	end

	if love.mouse.isDown(1) then
		Projectile.new(part2.CFrame, 100)
	end

	updateAllProjectiles(dt)
end

function love.mousepressed()
end

function love.draw()

	Instance.render()
end