function love.load()
	WIDTH,HEIGHT = 400,400
	love.window.setMode(WIDTH, HEIGHT)
	body = {
		position = {
			x = 0, 
			y = 0,
		},
		size = {
			x = 50,
			y = 50,
		},
		rotation = math.pi/4,
		velocity = {
			x = 0, 
			y = 0,
		},
	}
end

c = function(numb, min, max)
	--return math.min(math.max(num, min), max)
	return numb > max and max or numb < min and min or numb
end
function love.update(dt)
	body.velocity.x = body.velocity.x + 0 * dt
	body.velocity.y = body.velocity.y + 100 * dt
	body.position.x = c(body.position.x + body.velocity.x * dt, -WIDTH/2 + body.size.x/2, WIDTH/2-body.size.x/2)
	body.position.y = c(body.position.y + body.velocity.y * dt, -HEIGHT/2 + body.size.y/2, HEIGHT/2-body.size.y/2)
end

function love.draw()
	love.graphics.push()
	love.graphics.translate(WIDTH/2, HEIGHT/2)
	love.graphics.translate(body.position.x, body.position.y)
	love.graphics.rotate(body.rotation)

	local x,y = body.position.x, body.position.y
	local w,h = body.size.x, body.size.y

	love.graphics.rectangle("line", -w/2,-h/2, w,h)

	love.graphics.pop()
end