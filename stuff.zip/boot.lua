math.randomseed(os.time())
Signal = require("Objects.Signal")
updateSignal = Signal.new()
drawSignal = Signal.new()
return function(load)
	Vector, CFrame, Graphics, Color3 = require("Objects.Vector"), require("Objects.CFrame"), require("Objects.Graphics"), require("Objects.Color3")
	IK = require("Objects.IK.Snake")
	Segment = require("Objects.IK.Segment")
	mathf = require("Objects.Mathf")
	Ray = require("Objects.Raycast")
	Udim = require("Objects.Udim")
	require("Objects.Enum")
	require("Objects.String")
	UserInput = require("Objects.Input")
	Instance = require("Objects.Instance")
	Region = require("Objects.Region")
	TreeClass = require("Objects.Tree.Tree")
	AnimationClass = require("Objects.Animation")
	local tweenModule = require("Objects.Tween")
	Tween = tweenModule.tween
	TweenInfo = tweenModule.tweenInfo
	
	--Thread = require("Objects.Thread")
	require("Objects.Thread")(updateSignal)
	
	AnchorClass = require("Objects.Anchor")
	SpringClass = require("Objects.Spring")

	
	local rpb = require("Objects.Gui.RadialProgressBar")
	local progressBar = require("Objects.Gui.ProgressBar")
	--local bpb = require("Objects.Gui.RadialProgressBar")
	GuiObjects = {
		Joystick = require("Objects.Gui.Joystick"),
		Slider = require("Objects.Gui.Slider"),
		Gamepad = require("Objects.Gui.Gamepad"),
		GridLayout = require("Objects.Gui.GridLayout"),
		ListLayout = require("Objects.Gui.ListLayout"),
		ProgressBar = {
			new = function(type, ...)
				if type == "Radial" then
					return rpb.new(...)
				elseif type == "Bar" then
					return progressBar.new(...)
				end
			end
		},
		ColorPicker = require("Objects.Gui.ColorPicker")
	}

	tick = function()
		return ElapsedTime
	end

	WIDTH,HEIGHT = 500,500
	TITLE = "name"
	BACKGROUND_COLOR = Color3.new(50,50,50)
	DRAWRAYS = true
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	SunDirection = Vector.new(1,1)
	DTMUL = 1
	--STUDSIZE = 1

	local lastW, lastH
	ElapsedTime = 0

	local lastUpdate = ElapsedTime
	local lastDraw = ElapsedTime

	love.load = load

	function love.mouse.position()
		return (CFrame.Angles(-CAMERA.R) * CFrame.new(Vector.new(love.mouse.getPosition()) + -CAMERA.Position - Vector.new(WIDTH, HEIGHT))).Position
	end
	function love.update(delta)
		dt = delta * DTMUL
		ElapsedTime = ElapsedTime + dt

		if not paused then
			-- local s,e = pcall(function()
				if update then
					update(dt)
				end
				
				updateSignal:Run(dt)
			-- end)
			-- if not s and e then
			-- 	print("error in update:",e)
			-- end
		end
		lastUpdate = os.clock()
	end
	function love.draw()
		if WIDTH ~= lastW or HEIGHT ~= lastH then
			lastW,lastH = WIDTH, HEIGHT
			love.window.setMode(WIDTH,HEIGHT)
		end
		TITLE = TITLE or "Game"
		if _G.CURRENT_TITLE ~= TITLE then
			_G.CURRENT_TITLE = TITLE
			love.window.setTitle(TITLE)
		end

		love.graphics.setBackgroundColor(BACKGROUND_COLOR.R,BACKGROUND_COLOR.G,BACKGROUND_COLOR.B)
		
		love.graphics.push()
		love.graphics.translate((Vector.new(WIDTH, HEIGHT) + CAMERA)())
		love.graphics.rotate(CAMERA.R)

		--local s,e = pcall(function()
			if draw then
				draw(os.clock() - lastDraw)
			end
		--end)
		
		
		drawSignal:Run(dt)

		if DRAWRAYS then
			drawRays()
		end
		
		love.graphics.pop()
		if paused then
			love.graphics.setLineWidth(3)
			text("Paused", WIDTH/2 ,HEIGHT/2, 2)
			love.graphics.setLineWidth(1)
		end
		if DRAWFPS then
			text(tostring(math.floor(1/dt + 1)), 20, 20, 1)
		end

		lastDraw = os.clock()
		-- if not s and e then
		-- 	error("error in draw: "..e)
		-- end
	end
end