local colors = {a = {Color = Color3.new(0,0,0), Transparency = 1},b = {Color = Color3.new(94.35,43.87275,43.87275), Transparency = 0},c = {Color = Color3.new(255,118.575,118.575), Transparency = 0},d = {Color = Color3.new(255,182.88868660714,99.45), Transparency = 0},}
local image = {{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.c,colors.c,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.c,colors.c,colors.c,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.b,colors.b,colors.c,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.c,colors.c,colors.c,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.c,colors.c,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.d,colors.d,colors.d,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
}
return image