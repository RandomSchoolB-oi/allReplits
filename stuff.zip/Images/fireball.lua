local colors = {
	a = {Color = Color3.new(0,0,0), Transparency = 1},
	b = {Color = Color3.new(255,108.30895044643,47.175), Transparency = 0},
}
local image = {
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.b,colors.b,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.b,colors.b,colors.b,colors.b,colors.a,colors.a,},
{colors.a,colors.a,colors.b,colors.b,colors.b,colors.b,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.b,colors.b,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
{colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,colors.a,},
}
return image