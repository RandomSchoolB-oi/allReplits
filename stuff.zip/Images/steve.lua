local colors = {a = {Color = Color3.new(14.841,99.99742125,247.35), Transparency = 0},b = {Color = Color3.new(255,197.97812946429,136.425), Transparency = 0},c = {Color = Color3.new(137.7,92.773838169643,58.5225), Transparency = 0},d = {Color = Color3.new(255,255,255), Transparency = 0},}
local image = {{colors.c,colors.c,colors.c,colors.b,colors.b,colors.b,colors.b,colors.b,},
{colors.c,colors.c,colors.b,colors.b,colors.d,colors.b,colors.b,colors.b,},
{colors.c,colors.c,colors.b,colors.b,colors.a,colors.b,colors.c,colors.c,},
{colors.c,colors.c,colors.b,colors.b,colors.b,colors.c,colors.b,colors.c,},
{colors.c,colors.c,colors.b,colors.b,colors.b,colors.c,colors.b,colors.c,},
{colors.c,colors.c,colors.b,colors.b,colors.a,colors.b,colors.c,colors.c,},
{colors.c,colors.c,colors.b,colors.b,colors.d,colors.b,colors.b,colors.b,},
{colors.c,colors.c,colors.c,colors.b,colors.b,colors.b,colors.b,colors.b,},
}
return image