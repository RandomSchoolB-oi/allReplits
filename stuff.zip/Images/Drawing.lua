local colors = {a = {Color = Color3.new(117.3,86.275197321429,52.785), Transparency = 0},b = {Color = Color3.new(81.4215,158.1,153.62252330357), Transparency = 0},c = {Color = Color3.new(113.61525,170.85,165.52716825), Transparency = 0},d = {Color = Color3.new(158.1,116.28396160714,71.145), Transparency = 0},e = {Color = Color3.new(5.7375,80.101510714286,191.25), Transparency = 0},f = {Color = Color3.new(0,0,0), Transparency = 1},g = {Color = Color3.new(99.45,73.146362946429,44.7525), Transparency = 0},}
local image = {{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.e,colors.e,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.c,colors.e,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.e,colors.f,colors.f,colors.f,colors.f,colors.g,colors.d,colors.e,colors.e,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.c,colors.e,colors.e,colors.f,colors.g,colors.d,colors.a,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.b,colors.b,colors.e,colors.d,colors.a,colors.f,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.e,colors.c,colors.e,colors.f,colors.f,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.b,colors.c,colors.e,colors.b,colors.e,colors.f,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.b,colors.e,colors.f,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.e,colors.c,colors.e,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.f,colors.f,colors.e,colors.e,colors.f,colors.f,},
{colors.f,colors.f,colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
{colors.f,colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
{colors.f,colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
{colors.e,colors.b,colors.c,colors.b,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
{colors.e,colors.b,colors.b,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
{colors.e,colors.e,colors.e,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,colors.f,},
}
return image