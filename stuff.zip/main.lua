 --auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
-- require("boot")(function()
-- 	function update(dt)
-- 	end

-- 	function draw(dt)
-- 	end
-- end)
local games = {
	"ZombieMultiplayer", 
	"Raycaster", 
	"test", 
	"ImageMaker", 
	
	"Pong",
	"SpinWheel",
	"BlockGame",
	"8ball"
}
require("Games."..games[7]..".main")

