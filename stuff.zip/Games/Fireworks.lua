--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
TITLE = "Fireworks"
	local fireworks = {}
	local serial = 0

	local newFirework = function()
		local firework = {
			CFrame = CFrame.new(math.random(-WIDTH/2, WIDTH/2), HEIGHT/2 + 10, math.rad(math.random(-15, 15))),
			--CFrame = CFrame.new(0,0),
			Pellets = {},
			Start = os.clock(),
			Lifetime = math.random()+.5,
			Speed = 250,
			Color = Color3.newHSV(math.random(0, 255), 1,1),
		}
		local id = serial
		serial = serial + 1
		firework.id = id
		fireworks[id] = firework
	end

	newFirework()

	function update(dt)
		if math.random() < 0.1 then
			newFirework()
		end
		for id, firework in pairs(fireworks) do
			if os.clock() - firework.Start >= firework.Lifetime * 4 then
				fireworks[id] = nil
			else
				if os.clock() - firework.Start >= firework.Lifetime then
					if #firework.Pellets <= 0 then
						for i = 1, math.random(25, 50) do
							firework.Pellets[#firework.Pellets+1] = {
								Position = firework.CFrame.Position, 
								Velocity = (firework.CFrame * CFrame.Angles(math.rad(math.random(-65, 65)-90))).LookVector * (math.random(50, 200) + firework.Speed),
								Color = Color3.newHSV(math.random(0, 255), 1,1),
							}
						end
					end
					for i,v in pairs(firework.Pellets) do
						v.Position = v.Position + v.Velocity * dt
						v.Velocity = v.Velocity + Vector.new(0, 500) * dt
					end
				else
					firework.CFrame = firework.CFrame * CFrame.new(0, -firework.Speed * dt)
					firework.Speed = firework.Speed - dt * 50
				end
			end
		end
	end

	function draw(dt)
		for id, firework in pairs(fireworks) do
			if os.clock() - firework.Start >= firework.Lifetime then
				for i, v in pairs(firework.Pellets) do
					local cf = CFrame.lookAt(v.Position, v.Position + v.Velocity)love.graphics.setColor(255,255,111)
					v.Color()
					rect(1, cf.X, cf.Y, v.Velocity.Magnitude * dt*3, 5, cf.R)
				end
			else
				firework.Color()
				rect(1, firework.CFrame.X, firework.CFrame.Y, firework.Speed*dt/1.25, firework.Speed*dt*3, firework.CFrame.R)
			end
		end
	end
end)