local module = {}
module.__index = module

local walkDirections = {
	a = Vector.new(1, 0),
	d = Vector.new(-1, 0),
	w = Vector.new(0, 1),
	s = Vector.new(0, -1),
}

module.new = function()
	local player = setmetatable({}, module)
	
	player.Position = Vector.new(0, 0)
	player.walkSpeed = 150
	
	updateSignal:Connect(function(dt)
		player:update(dt)
	end)
	
	return player
end

function module:update(dt)
	local walkDir = Vector.new()
	for key, dir in pairs(walkDirections) do
		if love.keyboard.isDown(key) then
			walkDir = walkDir + dir
		end
	end
	if walkDir.Magnitude > 0.1 then
		local added = walkDir.Unit * player.walkSpeed * dt

		player.Position = player.Position + added
	end

local camOffset = Vector.new(-WIDTH/2, -HEIGHT/2)
	CAMERA = CFrame.new(player.Position + camOffset)
end

return module