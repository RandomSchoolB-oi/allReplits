local module = {}
module.__index = module

local gravity = Vector.new(0, 100)
local moveDirections = {
	a = Vector.new(-1, 0),
	d = Vector.new(1, 0),
	-- w = Vector.new(0, -1),
	-- s = Vector.new(0, 1),
}

function module:validatePoint(point)
	local gx,gy = blockClass.getGridPos(point.X, point.Y)
	if world[gx] and world[gx][gy] then
		return
	end
	return true
end

function module:canBeAt(pos)
	local size = self.Size

	local corners = {
		pos - Vector.new(size.X/2, 0),
		pos + Vector.new(size.X/2, 0),
		pos + (size * Vector.new(0 -1)),
		pos + (size * Vector.new(1, -1))
	}
	local allValid = true
	for i,v in pairs(corners) do
		if not self:validatePoint(v) then
			allValid = false
			break
		end
	end
	return allValid
end

function module:moveIfCan(dir)
	local pos = self.Position
	local canMoveX = self:canBeAt(pos + Vector.new(dir.X, 0))
	local canMoveY = self:canBeAt(pos + Vector.new(0, dir.Y))
	
	if canMoveX and canMoveY then
		self.Position = self.Position + dir
	elseif canMoveX then
		self.Position = self.Position + Vector.new(dir.X, 0)
	elseif canMoveY then
		self.Position = self.Position + Vector.new(0, dir.Y)
	end
	return not canMoveX, not canMoveY
end

module.new = function()
	local self = setmetatable({}, module)
	
	self.Position = Vector.new(0, 0)
	self.Size = Vector.new(30, 30)
	self.Velocity = Vector.new(0, 0)
	self.grounded = false

	drawSignal:Connect(function()
		love.graphics.setColor(255,255,255)
		local size = self.Size
		local pos = self.Position
		rectCF(0, pos - Vector.new(-size.X/2, size.Y), size)
	end)
	updateSignal:Connect(function(dt)
		local moveDir = Vector.new()
		for i,v in pairs(moveDirections) do
			if love.keyboard.isDown(i) then
				moveDir = moveDir + v
			end
		end
		self.Velocity = self.Velocity + moveDir * 30 * dt
		
		local gravityDT = Vector.new(0, 50) * dt
		local hitX, hitY = self:moveIfCan(self.Velocity + gravityDT)
		self.grounded = hitY
		if not self.grounded then
			self.Velocity = self.Velocity + gravityDT
		end
			
		local removeVeloc = Vector.new(hitX and 0 or 1, hitY and 0 or 1)
		self.Velocity = ((self.Velocity - (self.Velocity * Vector.new(1.25, 1) * dt * 5)) * removeVeloc)

		if self.grounded and love.keyboard.isDown("space") then
			self.Velocity = self.Velocity - Vector.new(0, 20)
		end
	end)
	
	return self
end

return module