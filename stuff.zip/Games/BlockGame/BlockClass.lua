local module = {}
module.__index = module

blockSize = Vector.new(50, 50)
local renderDistance = 10

world = {}

local blockColors = {
	Stone = Color3.new(100,100,100),
	Grass = Color3.new(170,255,0),
}
local surround = {}
local breakRadius = 2

for x = -breakRadius, breakRadius, 1 do
	for y = -breakRadius, breakRadius, 1 do
		if not (x == 0 and y == 0) then
			surround[#surround+1] = Vector.new(x,y)
		end
	end
end

module.getGridPos = function(x,y)
	local x = x + blockSize.X/2
	local y = y + blockSize.Y/2
	local gx = (x - (x % blockSize.X)) / blockSize.X
	local gy = (y - (y % blockSize.Y)) / blockSize.Y

	return gx,gy
end

module.getBlock = function(x,y)
	if world[x] and world[x][y] then
		return world[x][y]
	end
end

module.setBlock = function(x,y, block)
	local occupying = module.getBlock(x,y)
	if occupying then
		occupying:destroy(true)
	end
	
	block.x = x
	block.y = y
	
	if not world[x] then
		world[x] = {}
	end
	world[x][y] = block
end

module.new = function(x,y, blockName, isCave)
	local block = setmetatable({}, module)

	block.name = blockName or "Stone"
	block.isCave = isCave

	module.setBlock(x,y, block)
	
	return block
end


function module:destroy(noSurround)
	world[self.x][self.y] = nil
	module.new(self.x, self.y, "Air")
	if not noSurround then
		for i,v in pairs(surround) do
			local nx, ny = self.x + v.X, self.y + v.Y
			if not module.getBlock(nx,ny) then
				module.new(nx,ny, "Stone")
			end
		end
	end
end

drawSignal:Connect(function()
	for x,row in pairs(world) do
		for y, block in pairs(row) do
			if block.name ~= "Air" then

				-- local rx,ry
				-- -- if player then
				-- -- 	rx,ry = player.Position.X, player.Position.Y
				-- -- else
				-- 	rx,ry = CAMERA.X + WIDTH/2, CAMERA.Y + HEIGHT/2
				-- -- end
				-- local cx,cy = module.getGridPos(rx, ry)
				-- local camGrid = Vector.new(cx,cy)
					
				-- local blockVector = Vector.new(x,y)
		
				-- local dist = (blockVector - camGrid).Magnitude
					
				-- if dist <= renderDistance then
					--render the block
					local projectedPos = Vector.new(x,y) * blockSize
					blockColors[block.name]()
					rectCF(1, projectedPos, blockSize)
					blockColors[block.name](.75)
					rectCF(nil, projectedPos, blockSize)
				-- end
			end
		end
	end
end)
	
return module