require("boot")(function()
	WIDTH,HEIGHT = 600,600	
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)

	blockClass = require("Games.BlockGame.BlockClass")
	playerClass = require("Games.BlockGame.Player")
		for y = 1, 1 do
			for x = -5, 5 do
				blockClass.new(x,y, "Stone")
			end
		end
	DRAWFPS = true
	player = playerClass.new()
		
	function update(dt)
		
	end

	function draw(dt)
		
	end

	UserInput.InputBegan:Connect(function(input)
		if input.Mouse == Enum.Mouse.LeftMouseButton then
			local pos = love.mouse.position()
			local x,y = blockClass.getGridPos(pos.X,pos.Y)
					print(pos.X, pos.Y)
					print(x,y)
			local block =  blockClass.getBlock(x,y)

			if block then 
				block:destroy() 
			end
			return
		end
		if input.Keyboard == Enum.Keyboard.P then
			paused = not paused
			return
		end
	end)
end)