--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
-- require("boot")(function()
-- 	function update(dt)
		
-- 	end

-- 	function draw(dt)

-- 	end
-- end)


math.randomseed(os.time())
--require("Tools.Language")
require("Tools.InstanceStore")
require("boot")(function()
	WIDTH,HEIGHT = 400,400
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	
	FPS = 900000
	TITLE = "Zombie"
	BACKGROUND_COLOR = Color3.new(50,50,50)
	--DRAWRAYS = true
	Instance.CircleSegments = 12
	DRAWFPS = true
	dead = false
	paused = false
	showSpread = false
	DTMUL = 1
	local lastHurt = 0

	local zombiesPerRound
	local currentGun
	local gun
	local gunData
	local maxhealth = 10
	local healthPerHeart = 2
	player = {maxhealth = maxhealth, health = maxhealth}

	relfectors = {}

	local wall1 = Instance.new("Part")
	wall1.Size = Vector.new(1, HEIGHT)
	wall1.Position = Vector.new(-WIDTH/2, 0)
	
	local wall2 = Instance.new("Part")
	wall2.Size = Vector.new(1, HEIGHT)
	wall2.Position = Vector.new(WIDTH/2, 0)
	
	local wall3 = Instance.new("Part")
	wall3.Size = Vector.new(WIDTH, 1)
	wall3.Position = Vector.new(0, -HEIGHT/2)
	
	local wall4 = Instance.new("Part")
	wall4.Size = Vector.new(WIDTH, 1)
	wall4.Position = Vector.new(0, HEIGHT/2)

	relfectors[#relfectors+1] = wall1
	relfectors[#relfectors+1] = wall2
	relfectors[#relfectors+1] = wall3
	relfectors[#relfectors+1] = wall4

	local treeClass = require("Objects.Tree.Tree")

	local gunClass = require("Objects.Pew.Pew")
	local enemyClass = require("Objects.Enemy.EnemyClass")
	local cooldown = GuiObjects.ProgressBar.new("Radial", 0, 1, 0, 25, 100)
	local gunDelay = GuiObjects.ProgressBar.new("Bar", 0, 1, 10, 75, 1)

	
	local movementDirections = {
		w = Vector.new(0, -1),
		a = Vector.new(-1, 0),
		s = Vector.new(0, 1),
		d = Vector.new(1, 0),
	}
	camRot = 0
	local lastMousePos = love.mouse.position()


	local worldPowerups = {}

	local guns = {
		gunClass.new("Pistol"),
		gunClass.new("Shotgun"),
		gunClass.new("Assault Rifle"),
		gunClass.new("Burst Assault Rifle"),
		gunClass.new("Grenade Launcher"),
		gunClass.new("Mini-Gun"),
		gunClass.new("Hunting Rifle"),
		gunClass.new("Railgun"),
		gunClass.new("Sub Machine Gun"),
	}

	cycleGun = function(dir)
		currentGun = currentGun + dir
		if currentGun <= 0 then 
			currentGun = #guns
		elseif currentGun > #guns then
			currentGun = 1
		end
		gun = guns[currentGun]
		for i,v in pairs(guns) do
			v.Visible = false
		end
		gun.Visible = true
		gunData = pewData[gun.Type]
	end

	function newPowerup(powerup, x,y)
		worldPowerups[#worldPowerups+1] = {
			Position = Vector.new(x,y),
			Name = powerup,
			Life = 0,
		}
	end

	local function refreshAmmo()
		for i,v in pairs(guns) do
			local data = pewData[v.Type]
			v.ammo = data.magSize
			v.totalAmmo = data.magSize * 15
		end
	end

	local function refreshGame()
		dead = false
		player = {maxhealth = maxhealth, health = maxhealth}
		zombiesPerRound = 2
		gunOrigin = Vector.new(0,0)

		currentGun = 2
		cycleGun(-1)

		zombieData = {
			round = 0,
			totalZombiesSpawned = 0,
			zombiesLeft = 0
		}
		refreshAmmo()
		for i,v in pairs(enemies) do
			v:Destroy()
		end
		worldPowerups = {}
	end
	refreshGame()
	--GuiObjects.ColorPicker.init()

	local powerUps = {
		["Max Ammo"] = {
			lifeTime = 10,
			render = function(x,y)
				love.graphics.setColor(255,255,111)
				rect(1, x,y,110,60)
				love.graphics.setColor(200,200,75)
				love.graphics.setLineWidth(5)
				text("Ammo", x, y, 2)
				love.graphics.setLineWidth(1)
			end,
			callback = function(self)
				refreshAmmo()
			end,
		},
		["Medkit"] = {
			lifeTime = 5,
			render = function(x,y)
				love.graphics.setColor(255,255,255)
				rect(1, x,y,50,50)
				love.graphics.setColor(255,0,0)
				love.graphics.setLineWidth(5)
				text("+", x, y, 3)
				love.graphics.setLineWidth(1)
			end,
			callback = function(self)
				player.health = player.maxhealth
			end,
		},
		["New Gun"] = {
			lifeTime = 25,
			render = function(x,y)
				love.graphics.setColor(200,200,200)
				rect(1, x,y,50,50)
			end,
			callback = function(self)
				local possibleGuns = {
					"Assault Rifle",
					"Burst Assault Rifle",
					"Grenade Launcher",
					"Hunting Rifle",
					"Mini-Gun",
					"Pistol",
					"Railgun",
					"Shotgun",
					"Sub Machine Gun"
				}
				local newgun = gunClass.new(possibleGuns[math.random(1, #possibleGuns)])
				if #guns < 2 then
					newgun.Visible = false
					guns[2] = newgun
				else
					gun:Destroy()
					gun = newgun
					guns[currentGun] = newgun
				end
			end,
		},
	}
	powerupArray = {}
	for i,v in pairs(powerUps) do
		powerupArray[#powerupArray+1] = i
	end

	local ammoLabel = Instance.new("Text")
	ammoLabel.Position = Vector.new(0, HEIGHT/2 - 35)

	local gunLabel = Instance.new("Text")
	gunLabel.Position = Vector.new(0, HEIGHT/2 - 15)

	local zombieLabel = Instance.new("Text")
	zombieLabel.Position = Vector.new(0, -HEIGHT/2 + 20)

	local roundLabel = Instance.new("Text")
	roundLabel.Position = Vector.new(WIDTH/2-20, HEIGHT/2 - 20)


	
	UserInput.InputBegan:Connect(function(input)
		if input.Keyboard == Enum.Keyboard.P then
			paused = not paused
			return
		end
		if input.Keyboard == Enum.Keyboard.H then
			if dead and not paused then
				refreshGame()
			end
		end
		if not dead and not paused then
			if input.Mouse == Enum.Mouse.LeftMouseButton then
				if gun.ammo <= 0 then
					if not gun.Reloading then
						gun:reload()
					end
					return
				end
				gun:click(love.mouse.position())
			elseif input.Keyboard then
				if input.Keyboard == Enum.Keyboard.E then
					cycleGun(1)
				elseif input.Keyboard == Enum.Keyboard.Q then
					cycleGun(-1)
				elseif input.Keyboard == Enum.Keyboard.R then
					if not gun.Reloading then
						gun:reload()
					end
				elseif input.Keyboard == Enum.Keyboard.U then
					showSpread = not showSpread
				end
			end
		end
	end)

	function update(dt)
		if paused then
			return
		end
		for i,v in pairs(enemies) do
			if dead then
			else
				if (v.CFrame.Position - gunOrigin).Magnitude <= 30 and tick() - lastHurt > 1 then
					lastHurt = tick()
					gun:unclick()
					player.health = player.health - 1
					if player.health <= 0 then
						dead = true
					end
				end
			end
		end
		if dead then
			return
		end
		if zombieData.zombiesLeft > 0 then
			if math.random() <= 0.01 then
				enemyClass.new()
				zombieData.zombiesLeft = zombieData.zombiesLeft - 1
				zombieData.totalZombiesSpawned = zombieData.totalZombiesSpawned + 1
			end
		end
		for i,v in pairs(worldPowerups) do
			v.Life = v.Life + dt
			if v.Life > powerUps[v.Name].lifeTime then
				worldPowerups[i] = nil
			end
		end
		-- for i,v in pairs(guns) do
		-- 	for _, bullet in pairs(v.Bullets) do
		for id, powerup in pairs(worldPowerups) do
			if (powerup.Position - gunOrigin).Magnitude < 50 then
				powerUps[powerup.Name].callback(powerup)
				worldPowerups[id] = nil
				break
			end
		end
		-- 	end
		-- end
		if #enemies <= 0 and zombieData.zombiesLeft <= 0 then
			zombieData.round = zombieData.round + 1
			zombieData.zombiesLeft = zombieData.round * zombiesPerRound
		end
		if UserInput.isDown(Enum.Keyboard.Z) then
			enemyClass.new()
		end 
		if UserInput.isDown(Enum.Keyboard.C) then
			CAMERA = CAMERA:Lerp(CFrame.new(-WIDTH/2, -HEIGHT/2), .2)
		end 
		local movementDirection = Vector.new()
		for i,v in pairs(movementDirections) do
			if UserInput.isDown(i) then
				movementDirection = movementDirection + v
			end
		end
		if movementDirection.Magnitude > 0 then
			local sprinting = UserInput.isDown("lshift")
			local walkspeed = 100 * ((sprinting and not abs) and 1.75 or 1)  * (ads and .25 or 1)
			gunOrigin = gunOrigin + (movementDirection.Unit * walkspeed * dt)
		end
		gunOrigin = Vector.new(
			mathf.clamp(gunOrigin.X, -WIDTH/2, WIDTH/2),
			mathf.clamp(gunOrigin.Y, -HEIGHT/2,HEIGHT/2)
		)
		gun.Position = gunOrigin
		
	--	CAMERA = CFrame.new(CAMERA.Position) * CFrame.Angles(camRot * mathf.clamp(1-((tick() - gun.LastBurst)/gunData.fireRate),0,1))
		-- if love.mouse.isDown(2) then
		-- 	local speed = 1
		-- 	if love.keyboard.isDown("q") then
		-- 		speed = 2
		-- 	end
		-- 	local mouseDelta = (love.mouse.position() - lastMousePos) * speed --* dt * 50
		-- 	CAMERA = CAMERA * CFrame.new(mouseDelta)
		-- end
		-- lastMousePos = love.mouse.position()

		gun.To = love.mouse.position()
		if not UserInput.isDown(1) then
			for i,v in pairs(guns) do
				gun:unclick()
			end
		end
		cooldown.MaximumValue = pewData[gun.Type].reloadTime
		gunDelay.MaximumValue = pewData[gun.Type].fireRate

		

		local ZombieCount = 0
		for i,v in pairs(enemies) do
			ZombieCount = ZombieCount + 1
		end

		zombieLabel.Text = ZombieCount.." zombies left"
		ammoLabel.Text = tostring(gun.ammo).."/"..tostring(gun.totalAmmo)
		gunLabel.Text = gun.Type
		roundLabel.Text = zombieData.round
	end

	function draw(dt)

		love.graphics.setColor(255,255,255)
		if dead then
			text("you died", 0 ,0, 2)
			text("h to retry", 0 ,40, 1)
		end

		love.graphics.setColor(255,255,255, 150)
		--love.graphics.circle("fill", gunOrigin.X, gunOrigin.Y, 30)

		love.graphics.setColor(255,255,255)
		local tim = tick() - gun.ReloadStart
		if tim < pewData[gun.Type].reloadTime then
			cooldown:render(tim, love.mouse.position())
		end
		local tim = tick() - gun.LastFire
		if tim < pewData[gun.Type].fireRate then
			gunDelay:render(tim, Vector.new(-75/2, HEIGHT/2 - 68))
		end
		

		local x,y,w,h = 0,HEIGHT/2-100, 10,10
		local p = 5
		x = x - (maxhealth * w + (maxhealth-1) * p) / (healthPerHeart*2)

		for _i = 1, player.maxhealth,healthPerHeart do
			local i = _i/healthPerHeart
			love.graphics.setColor(0,0,0)

			local hearts = player.maxhealth/healthPerHeart
			
			local X = i * w + i * p + x
			rect(1,X, y, w,h)
			local health = player.health-_i + 1
			if health > 0 then
				love.graphics.setColor(255,0,0)
				if health > 1 or healthPerHeart == 1 then
					rect(1,X, y, w,h)
				else
					rect(1,X - w/(healthPerHeart^2), y, w/healthPerHeart,h)
				end
			end
		end
		love.graphics.setColor(255,255,255,100)
		love.graphics.circle("fill", 0, y, 10)
	
		local spread = ads and pewData[gun.Type].adsSpread or pewData[gun.Type].spread
		local distSpread = math.abs(spread[1]) + math.abs(spread[2])
		local siz = ((gun.Position - gun.To).Magnitude - pewData[gun.Type].barrelLength) * (math.tan(math.rad(distSpread)) /2)
		local cf = CFrame.new(love.mouse.position(), math.rad(0))
		local lineCount = 3
		for i = 1, lineCount do
			local lineCF = cf * CFrame.Angles(i/lineCount * math.pi*2) * CFrame.new(0, siz + 6)
			rect(1, lineCF.X, lineCF.Y, 5, 10, lineCF.R)
		end

		for i,v in pairs(worldPowerups) do
			powerUps[v.Name].render(v.Position.X, v.Position.Y)
			love.graphics.setColor(0,0,0,150)
			text(tostring(math.floor(powerUps[v.Name].lifeTime - v.Life + .5)), v.Position.X + 15, v.Position.Y - 15, 1)
		end
	end
end)