--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	path = "Games.ZombieMultiplayer."
	gunClass = require(path.."Pew.Pew")
	enemyClass = require(path.."Enemy.EnemyClass")
	powerupClass = require(path.."PowerupClass")
	local playerClass = require(path.."PlayerClass")

	local player = playerClass.new()
	local player2 = playerClass.new()

	local lastSpawn = tick()

	zombieData = {
		round = 5,
		totalZombiesSpawned = 0,
		zombiesLeft = 0
	}

	relfectors = {}

	local wall1 = Instance.new("Part")
	wall1.Size = Vector.new(1, HEIGHT)
	wall1.Position = Vector.new(-WIDTH/2, 0)
	
	local wall2 = Instance.new("Part")
	wall2.Size = Vector.new(1, HEIGHT)
	wall2.Position = Vector.new(WIDTH/2, 0)
	
	local wall3 = Instance.new("Part")
	wall3.Size = Vector.new(WIDTH, 1)
	wall3.Position = Vector.new(0, -HEIGHT/2)
	
	local wall4 = Instance.new("Part")
	wall4.Size = Vector.new(WIDTH, 1)
	wall4.Position = Vector.new(0, HEIGHT/2)

	relfectors[#relfectors+1] = wall1
	relfectors[#relfectors+1] = wall2
	relfectors[#relfectors+1] = wall3
	relfectors[#relfectors+1] = wall4

	function update(dt)
		if tick() - lastSpawn > 2 then
			enemyClass.new()
			lastSpawn = tick()
		end
		for _, enemy in pairs(enemies) do
			for _, player in pairs(players) do
				if (player.CFrame.Position - enemy.CFrame.Position).Magnitude < 50 then
					
				end
			end
		end
	end

	function draw(dt)
	end
end)