worldPowerups = {}

function newPowerup(powerup, x,y)
	worldPowerups[#worldPowerups+1] = {
		Position = Vector.new(x,y),
		Name = powerup,
		Life = 0,
	}
end

local powerUps = {
	["Max Ammo"] = {
		lifeTime = 10,
		render = function(x,y)
			love.graphics.setColor(255,255,111)
			rect(1, x,y,110,60)
			love.graphics.setColor(200,200,75)
			love.graphics.setLineWidth(5)
			text("Ammo", x, y, 2)
			love.graphics.setLineWidth(1)
		end,
		callback = function(self)
			refreshAmmo()
		end,
	},
	["Medkit"] = {
		lifeTime = 5,
		render = function(x,y)
			love.graphics.setColor(255,255,255)
			rect(1, x,y,50,50)
			love.graphics.setColor(255,0,0)
			love.graphics.setLineWidth(5)
			text("+", x, y, 3)
			love.graphics.setLineWidth(1)
		end,
		callback = function(self)
			player.health = player.maxhealth
		end,
	},
	["New Gun"] = {
		lifeTime = 25,
		render = function(x,y)
			love.graphics.setColor(200,200,200)
			rect(1, x,y,50,50)
		end,
		callback = function(self)
			local possibleGuns = {
				"Assault Rifle",
				"Burst Assault Rifle",
				"Grenade Launcher",
				"Hunting Rifle",
				"Mini-Gun",
				"Pistol",
				"Shotgun",
				"Sub Machine Gun"
			}
			local newgun = gunClass.new(possibleGuns[math.random(1, #possibleGuns)])
			if #guns < 2 then
				newgun.Visible = false
				guns[2] = newgun
			else
				gun:Destroy()
				gun = newgun
				guns[currentGun] = newgun
			end
		end,
	},
}
powerupArray = {}
for i,v in pairs(powerUps) do
	powerupArray[#powerupArray+1] = i
end