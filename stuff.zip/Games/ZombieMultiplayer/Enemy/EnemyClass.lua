local module = {}
module.__index = module

enemies = {}
enemyPartLookup = {}
local serial = 0

local showImage = true


module.new = function()
	local rotation = math.rad(math.random(0, 360))
	local dist = math.sqrt(WIDTH^2, HEIGHT^2)/2 + math.random(100, 300)

	local zombie = setmetatable({}, module)
	local CFrame = CFrame.new(0, 0, rotation) * CFrame.new(0, dist)
	local Part = Instance.new("Part")
	local w = math.random(75, 125)
	Part.CFrame = CFrame
	zombie.CFrame = CFrame
	zombie.Part = Part
	zombie.Part.Visible = false
	zombie.Part.Color = Color3.new(0, 125, 0)
	zombie.Part.Size = Vector.new(w,w)
	zombie.Speed = math.random(25, 50)
	zombie.Decal = love.graphics.newImage("Images/Zombie.png")

	local health = zombieData.round--math.random(10,50)/10
	zombie.Health = health
	zombie.MaxHealth = health

	local id = serial
	serial = serial + 1
	zombie.id = id
	enemies[id] = zombie

	enemyPartLookup[zombie.Part] = zombie

	return zombie
end

function module:drawHealth()
	local cf, size, thickness = self.CFrame, self.Part.Size, 5
	local y = cf.Y - size.Y/2 - thickness - 2
	local percent = self.Health / self.MaxHealth

	love.graphics.setColor(255, 25, 25)
	rect(1, cf.X, y, size.X, thickness)
	love.graphics.setColor(170, 255, 0)
	rect(1, cf.X - (size.X - size.X * percent)/2, y, size.X * percent, thickness)
	love.graphics.setColor(0, 0, 0)
	rect(false, cf.X, y, size.X, thickness)
	-- local dashes = self.MaxHealth - 1

	-- for i = 1, self.MaxHealth, pewData[gun.Type].damage do
	-- 	local left = cf.X - size.X/2
	-- 	rect(1, left + (i/self.MaxHealth * size.X), y, 1, thickness)
	-- end
end

function module:Destroy()
	if math.random(1, 2) == 1 then
		newPowerup(powerupArray[math.random(1, #powerupArray)], self.CFrame.X, self.CFrame.Y)
	end
	enemies[self.id] = nil
	self.Part:Destroy()
	for i,v in pairs(self) do
		self[i] = v
	end
end

drawSignal:Connect(function()
	for id, self in pairs(enemies) do
		local cf, size, thickness = self.CFrame, self.Part.Size, 6
		local y = cf.Y - size.Y/2 - thickness - 2
		local percent = self.Health / self.MaxHealth
		love.graphics.setColor(255, 255, 255)
		if showImage then
			image(self.Decal, cf, Vector.new(96, 96), self.Part.Size)
		else
			love.graphics.setColor(10, 200, 5)
			rect(1, cf.X, cf.Y, size.X, size.Y, cf.R)
			love.graphics.setColor(0, 100, 0)
			love.graphics.setLineWidth(2)
			rect(nil, cf.X, cf.Y, size.X, size.Y, cf.R)
			love.graphics.setLineWidth(1)
		end
		self:drawHealth()
	end
end)

updateSignal:Connect(function(dt)
	for id, self in pairs(enemies) do
		local closest
		for pid, player in pairs(players) do
			if closest and (player.CFrame.Position - self.CFrame.Position).Magnitude < (closest.CFrame.Position - self.CFrame.Position).Magnitude or not closest then
				if not player.dead then
					closest = player
				end
			end
		end
		local from, to = self.CFrame.Position, closest.CFrame.Position--(CAMERA * CFrame.new(WIDTH/2, HEIGHT/2)).Position
		local looking = to-from--CFrame.lookAt(from, to)
		local pos = from + (looking.Unit * (self.Speed * dt))
		self.Part.CFrame = CFrame.new(pos)
		self.CFrame = CFrame.new(pos)
		if self.Health <= 0 then
			self:Destroy()
		end
	end
end)

return module