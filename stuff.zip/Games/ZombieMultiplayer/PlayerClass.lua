local module = {}
module.__index = module

players = {}
local serial = 1

local directions = {
	LeftTurn = {R = -4},
	RightTurn = {R = 4},
	Forward = {Y = -1},
	Backwards = {Y = 1},
	Left = {X = -1},
	Right = {X = 1},
}

local playerControls = {
	{
		LeftTurn = Enum.Keyboard.Q,
		RightTurn = Enum.Keyboard.E,
		Forward = Enum.Keyboard.W,
		Backwards = Enum.Keyboard.S,
		Left = Enum.Keyboard.A,
		Right = Enum.Keyboard.D,

		Fire = Enum.Keyboard.X,

		Swap = Enum.Keyboard.Z,

		Reload = Enum.Keyboard.C,
	},
	{
		LeftTurn = Enum.Keyboard.R,
		RightTurn = Enum.Keyboard.Y,
		Forward = Enum.Keyboard.T,
		Backwards = Enum.Keyboard.G,
		Left = Enum.Keyboard.F,
		Right = Enum.Keyboard.H,

		Fire = Enum.Keyboard.B,

		Swap = Enum.Keyboard.V,

		Reload = Enum.Keyboard.N,
	},
}

function module.new()
	local id = serial
	serial = serial + 1
	local player = setmetatable({
		id = id,
		CFrame = CFrame.new(0,0,0),
		Controls = playerControls[id],
		Guns = {
			gunClass.new("Pistol"),
			gunClass.new("Grenade Launcher"),
		},
		currentGun = 1,
		Walkspeed = 100,
		Health = 4,
		ReloadGui = GuiObjects.ProgressBar.new("Radial", 0, 1, 10, 50, 100)
	}, module)
	players[id] = player

	return player
end

function module:cycleGun(dir)
	self.currentGun = mathf.packmanInc(self.currentGun, 1, #self.Guns, dir)
end

function module:kill()
	self.dead = true
end

-- drawSignal:Connect(function()
-- 	for id, self in pairs(players) do
-- 	end
-- end)

UserInput.InputBegan:Connect(function(input)
	for id, self in pairs(players) do
		if not self.dead then
			if input.Keyboard == self.Controls.Swap then
				self:cycleGun(1)
			elseif input.Keyboard == self.Controls.Reload then
				self.Guns[self.currentGun]:reload()	
			end
		end
	end
end)

updateSignal:Connect(function(dt)
	for id, self in pairs(players) do
		if not self.dead then
			local newRot = CFrame.new()
			local newPos = Vector.new()
			self.ReloadGui.MaximumValue = pewData[self.Guns[self.currentGun].Type].reloadTime		
			for dirName, key in pairs(self.Controls) do
				if directions[dirName] and love.keyboard.isDown(key) then
					local dir = directions[dirName]
	
					local cf = {X = 0, Y = 0, R = 0}
					for axis, amount in pairs(dir) do
						cf[axis] = amount * dt
					end
	
					local move = Vector.new(
						cf.X,
						cf.Y
					)
					
					local rot = CFrame.Angles(cf.R)
	
					newRot = newRot * rot
					newPos = newPos + move
				end
			end
			self.CFrame = self.CFrame * newRot + (newPos.Magnitude > 0 and (newPos.Unit * self.Walkspeed * dt) or Vector.new())
			
			self.CFrame = CFrame.new(mathf.clamp(self.CFrame.X, -WIDTH/2, WIDTH/2), mathf.clamp(self.CFrame.Y, -WIDTH/2, WIDTH/2), self.CFrame.R)
			self.Guns[self.currentGun].Position = self.CFrame.Position
			self.Guns[self.currentGun].To = self.CFrame.Position - self.CFrame.RightVector
			for i,gun in pairs(self.Guns) do
				if i == self.currentGun and love.keyboard.isDown(self.Controls.Fire) then
					gun:click(gun.To)
						gun.Visible = true
				else
					gun:unclick()
					if i ~= self.currentGun then
						gun.Visible = false
					else
						gun.Visible = true
					end
				end
			end
			for i,v in pairs(enemies) do
				if (tick() - (self.lastHurt or 0) > 1/2) and (v.CFrame.Position - self.CFrame.Position).Magnitude < 50 then
					self.lastHurt = tick()
					self.Health = self.Health - 1
					if self.Health <= 0 then
						self:kill()
					end
				end
			end
		end
	end
end)

	drawSignal:Connect(function()
		for id, player in pairs(players) do
			local w,h = Vector.new(100,10)()
			local x,y = (id-1) * w-WIDTH/2 + (id-1) * 25, HEIGHT/2

			
			love.graphics.setLineWidth(1)
			love.graphics.setColor(255,69,69)
			love.graphics.rectangle("fill",x, y - h, w,h)
			love.graphics.setColor(170,255,0)
			love.graphics.rectangle("fill",x, y - h, w - w * (1-player.Health/4),h)
			love.graphics.setColor(0,0,0)
			love.graphics.rectangle("line",x, y - h, w,h)
			love.graphics.setColor(255,255,255)
			text("player "..tostring(id) , x + w/2, y - 20, 1)
			--text(id, player.CFrame.X, player.CFrame.Y, 1)
			local currentGun = player.Guns[player.currentGun]
			image(currentGun.Decal, CFrame.new(x + w/2, y - 60), Vector.new(80,80))
			if player.dead then
				love.graphics.setColor(255,0,0)
				love.graphics.setLineWidth(5)
				text("X",x + w/2,y - h/2 - 50, 5)
			else
				local value = currentGun.ReloadStart - tick()
				if value > -player.ReloadGui.MaximumValue then
					player.ReloadGui:render(math.abs(value), currentGun.Position)
				end
			end
		end
	end)

return module