return {
	Size = Vector.new(3,3),
	Lifetime = 3,
	pierce = 3,
}