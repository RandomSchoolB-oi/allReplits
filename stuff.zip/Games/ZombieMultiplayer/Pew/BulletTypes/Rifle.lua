return {
	Size = Vector.new(15,3),
	Lifetime = 5,
	pierce = 10,
}