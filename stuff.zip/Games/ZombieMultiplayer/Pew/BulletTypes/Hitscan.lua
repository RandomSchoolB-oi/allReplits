return {
	hitscan = true,
	pierce = 10,
}