return {
	Size = Vector.new(10,5),
	Lifetime = 5,
	OnUpdate = function(a,b)
		homingProjectile(a,b,0.2)
	end,
}