return {
	Size = Vector.new(50,50),
	Lifetime = 2,
	OnDeath = function(self, cf, target)
		explode(self, cf, target, math.random(2,5), "Bomb", {-180, 180})
	end,
}