return {
	Size = Vector.new(20,20),
	Lifetime = 10,
	OnDeath = function(self, cf, target)
		explode(self, cf, target, math.random(30,50), "Default", {-180, 180})
	end,
	OnUpdate = function(a,b)
		homingProjectile(a,b,.05)
	end
}