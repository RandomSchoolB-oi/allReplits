local module = {}
module.__index = module

local bullets = {}
local serial = 0

module.new = function(from, cf, speed, type)
	local data = from and pewData[from.Type] or pewData.Pistol
	local origin = cf.Position + cf.LookVector * data.barrelLength
	if bulletData[type].hitscan then
		local hit = {}
		for i=1, (bulletData[type].pierce or 1) do
			local ignore = {}
			for _,p in pairs(hit) do
				ignore[#ignore+1] = p.Part
			end

			local part, pos, norm = Ray.new(cf, 10000, ignore):cast()
			
			if part then
				local enemy = enemyPartLookup[part]

				if enemy and not mathf.find(hit, enemy) then
					hit[#hit+1] = enemy
					enemy.Health = enemy.Health - data.damage
				end
			end
		end
		return
	end
	local bullet = setmetatable({
		Origin = origin,
		Direction = cf.LookVector,
		Position = origin,
		Speed = speed or 100,
		
		Lifetime = bulletData[type].Lifetime,
		SpeedDegeneration = data.speedReduction,
		From = from,
		Hit = {},
		Ray = Ray.new(cf, speed, nil, relfectors),
		Type = type,

		Life = 0,
	},module)

	local id = serial
	serial = serial + 1
	bullet.id = id
	bullets[id] = bullet

	return bullet
end

function module:draw()
	if self then
		local data = bulletData[self.Type]
		local cf = CFrame.lookAt(self.Position, self.Position + self.Direction)
		local length = (cf.Position - self.Origin).Magnitude * 2
		local to = cf * CFrame.new(-mathf.clamp(length, 0, self.Speed/20), 0)
		love.graphics.setColor(255,255,255,150)
		lineVec(cf, to)
		love.graphics.setColor(255,255,111)
		rectCF(1, cf, data.Size)
	else
		for i,v in pairs(bullets) do
			v:draw()
		end
	end
end

function module:Destroy(...)
	if self.id then
		local data = bulletData[self.Type]
		-- enemyPartLookup[self.Part] = nil
		-- self.Part:Destroy()
		if data.OnDeath then
			data.OnDeath(self.From, CFrame.new(self.Position), ...)
		end

		local id = self.id
		bullets[id] = nil
		for i,v in pairs(self) do
			self[i] = nil
		end
	end
end

function module:update(dt)
	if self then
		self.Life = self.Life + dt
		if self.Life < self.Lifetime then
			local data = bulletData[self.Type]
			self.Ray.CFrame = CFrame.lookAt(self.Position, self.Position + self.Direction)
			self.Ray.Length = self.Speed * dt
			local pos, part, norm = self.Ray:cast()

			if pos and part and norm then
				local newDir = self.Ray.CFrame.LookVector:reflect(norm)
				self.Direction = newDir
			end

			if data.OnUpdate then
				data.OnUpdate(self, dt)
			end
			for i,v in pairs(enemies) do
				if not mathf.find(self.Hit, v) then
					local size, pos = v.Part.Size, v.CFrame.Position
					local topleft, bottomRight = pos - size/2, pos + size/2
					if self.Position > topleft and self.Position < bottomRight then
						v.Health = v.Health - (pewData[self.From.Type].damage or 1)
						self.Hit[#self.Hit+1] = v
						if #self.Hit >= (data.pierce or 1) then
							self:Destroy(v)
							return
						end
					end
				end
			end
			self.Position = self.Position + (self.Direction * dt * self.Speed)
			self.Speed = self.Speed * (1-dt * self.SpeedDegeneration)
		else
			self:Destroy()
		end
	else
		for i,v in pairs(bullets) do
			v:update(dt)
		end
	end
end

drawSignal:Connect(function(dt)
	module.draw()
end)
updateSignal:Connect(function(dt)
	module.update(nil, dt)
end)

return module