homingProjectile = function(self, dt, strength)
	local closest
	for i,v in pairs(enemies) do
		if closest and (v.CFrame.Position - self.Position).Magnitude < (closest.CFrame.Position - self.Position). Magnitude or not closest then
			closest = v
		end
	end
	if closest then
	local full, current = CFrame.lookAt(self.Position, closest.CFrame.Position).LookVector, self.Direction
		self.Direction = lerp(current, full, strength)
	end
end
explode = function(self, cf, target, quantity, type, rotationRange)
	local gun = self
	local data = pewData[gun.Type]

	for i = 1, quantity do
		local rot = math.rad(math.random(rotationRange[1], rotationRange[2]))
		bulletClass.new(
			gun, 
			
			cf * 
			CFrame.Angles(rot), 

			data.speed + math.random(0, data.speedVariation),

			type
		)
	end
end