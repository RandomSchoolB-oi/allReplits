local module module = {
	fireRate = 1.2,
	burstDelay = .3,
	fireAmount = 1,
	burstAmount = 3,
	speed = 400,
	speedVariation = 200,
	spread = {-5,5},
	adsSpread = {-0,0},
	speedReduction = .5,
	--holdable = true,
	magSize = 15,
	barrelLength = 25,
	bulletType = "Default",
	reloadTime = 1.25,
	damage = 1.2
}
return module