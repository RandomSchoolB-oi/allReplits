local module module = {
	fireRate = 1.5,
	burstDelay = .1,
	fireAmount = 1,
	burstAmount = 1,
	speed = 250,
	speedVariation = 100,
	spread = {0,0},
	speedReduction = .95,
	--holdable = true,
	magSize = 1,
	barrelLength = 75,
	bulletType = "Hitscan",
	reloadTime = 2,
	damage = 25,
}
return module