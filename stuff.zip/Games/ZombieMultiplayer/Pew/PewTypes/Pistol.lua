local module module = {
	fireRate = .2,
	burstDelay = .1,
	fireAmount = 1,
	burstAmount = 1,
	speed = 800,
	speedVariation = 100,
	spread = {-2,2},
	adsSpread = {-1,1},
	speedReduction = 0,
	--holdable = true,
	magSize = 8,
	barrelLength = 45,
	gripOffset = 8,
	image = "Pistol.png",
	bulletType = "Default",
	reloadTime = 1,
	damage = 1
}
return module