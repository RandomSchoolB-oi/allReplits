local module module = {
	fireRate = 0,
	burstDelay = .075,
	fireAmount = 1,
	burstAmount = 1,
	speed = 500,
	speedVariation = 100,
	spread = {-10,10},
	adsSpread = {-7,7},
	speedReduction = .1,
	holdable = true,
	magSize = 100,
	barrelLength = 0,
	bulletType = "Default",
	reloadTime = 5,
	damage = 10
}
return module