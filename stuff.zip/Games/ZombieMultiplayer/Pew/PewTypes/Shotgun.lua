local module module = {
	fireRate = 1,
	burstDelay = 0,
	fireAmount = 7,
	burstAmount = 1,
	speed = 400,
	speedVariation = 100,
	spread = {-20,20},
	adsSpread = {-10,10},
	speedReduction = .65,
	--holdable = true,
	magSize = 4,
	barrelLength = 45,
	gripOffset = 25,
	image = "Shotgun.png",
	bulletType = "Pellet",
	reloadTime = 2,
	damage = .75
}
return module