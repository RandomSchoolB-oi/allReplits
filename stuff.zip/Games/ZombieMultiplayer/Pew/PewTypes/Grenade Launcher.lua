local module module = {
	fireRate = 1.25,
	burstDelay = 0,
	fireAmount = 1,
	burstAmount = 1,
	speed = 750,
	speedVariation = 0,
	spread = {-8,8},
	adsSpread = {-1,1},
	speedReduction = .1,
	--holdable = true,
	magSize = 6,
	barrelLength = 45,
	gripOffset = 8,
	image = "GrenadeLauncher.png",
	bulletType = "Bomb",
	reloadTime = 2,
	damage = 5
}
return module

-- local module module = {
-- 	fireRate = 0,
-- 	burstDelay = 0,
-- 	fireAmount = 3,
-- 	burstAmount = 1,
-- 	speed = 1000,
-- 	speedVariation = 0,
-- 	spread = {-180,180},
-- 	speedReduction = .95,
-- 	holdable = true,
-- 	magSize = 1000,
-- 	barrelLength = 30,
-- 	bulletType = "SuperBomb",
-- 	reloadTime = .1,
-- 	render = function(cf)
-- 		Color3.new(123, 109, 109)()
-- 		local forward = cf * CFrame.new(module.barrelLength/2, 0)
-- 		rect(1, forward.X, forward.Y, module.barrelLength, 7, cf.R)
-- 	end,
-- 	damage = 20
-- }
-- return module