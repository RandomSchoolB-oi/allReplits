local module = {}
module.__index = module

bulletClass = require(path.."Pew.Bullet")
require(path.."Pew.SharedFunctions")
local gunHas = {}
local bulletHas = {}
pewData = setmetatable({}, {
	__index = function(self, index)
		if not gunHas[index] then
			gunHas[index] = require(path.."Pew.PewTypes."..index)
		end
		return gunHas[index]
	end
})
bulletData = setmetatable({}, {
	__index = function(self, index)
		if not bulletHas[index] then
			bulletHas[index] = require(path.."Pew.BulletTypes."..index)
		end
		return bulletHas[index]
	end
})
ads = false

local guns = {}
local serial = 0

module.new = function(Type)
	local data = pewData[Type]
	local pew = setmetatable({
		LastFire = -10,
		LastBurst = -10,
		Bullets = {},
		Position = Vector.new(0,0),
		To = Vector.new(0,0),
		_burstFired = 0,
		ammo = data.magSize,
		totalAmmo = data.magSize * 15,
		Visible = true,
		ReloadStart = 0,
		Reloading = false,
		BulletSerial = 1,

		Type = Type
	},module)
	if data.image then
		pew.Decal = love.graphics.newImage("Images/"..data.image)
	end
	local id = serial
	serial = serial + 1
	pew.id = id
	guns[id] = pew
	return pew
end

function module:reload()
	local data = pewData[self.Type]
	if self.ammo < data.magSize then
		self.Reloading = true
		self.ReloadStart = tick()
	end
end

function module:update(dt)
	if self then
		ads = UserInput.isDown(2)
		local data = pewData[self.Type]
		if self.Reloading then
			if tick() - self.ReloadStart >= data.reloadTime then
				self.ReloadStart = 0
				self.Reloading = false
				local ammoGive = mathf.clamp(data.magSize - self.ammo, 0, self.totalAmmo)
				self.ammo = self.ammo + ammoGive
				self.totalAmmo = self.totalAmmo - ammoGive
			end
			return
		end
		if self.ammo >= 1 and (self.clicking and (data.holdable or not data.holdable and (not self.shot or self._burstFired > 0))) then
			if self._burstFired > 0 and tick() - self.LastBurst > data.burstDelay then
				self._burstFired = self._burstFired - data.fireAmount
				self.LastBurst = tick()
				self.shot = true
				self.ammo = self.ammo - 1
				camRot = math.rad(math.random(data.spread[1], data.spread[2]))
				for i =1, data.fireAmount do
					local spreadRange = (not ads and data.spread) or (ads and data.adsSpread or data.spread)
					local spread = math.random(spreadRange[1], spreadRange[2]) 
					local bullet = bulletClass.new(
						self, 
						CFrame.lookAt(self.Position, self.To) * CFrame.new(data.barrelLength) * CFrame.Angles(math.rad(spread)), 
						data.speed + math.random(0, data.speedVariation), 
						data.bulletType
					)
					self.Bullets[self.BulletSerial] = bullet
					self.BulletSerial = self.BulletSerial + 1
				end
			end
		end
		for i,v in pairs(self.Bullets) do
			if not v.id then
				self.Bullets[i] = nil
			end
		end
	else
		for i,v in pairs(guns) do
			v:update(dt)
		end
	end
end

function module:click(to)
	local data = pewData[self.Type]
	if self.ammo <= 0 then
		-- if not self.Reloading then
		-- 	self:reload()
		-- end
		return
	end
	if tick() - self.LastFire >= data.fireRate and not self.clicking then
		self.clicking = true
		self.shot = nil
		self.LastFire = tick()
		self._burstFired = data.fireAmount * data.burstAmount
		if data.holdable then
			self._burstFired = math.huge
		end
		self.LastBurst = 0
		self.To = to
		--else
		--print("cant fire")
	end
end

function module:unclick() 
	self.clicking = false
	self._burstFired = 0
end

function module:Destroy()
	guns[self.id] = nil
end

updateSignal:Connect(function(dt)
	module.update(nil, dt)
end)

drawSignal:Connect(function()
	for i,v in pairs(guns) do
		if v.Visible then
			local data = pewData[v.Type]
			if showSpread then
				love.graphics.setColor(255,255,255, 100)
				local spreadRange = (not ads and data.spread) or (ads and data.adsSpread or data.spread)
				if math.abs(spreadRange[1] - spreadRange[2]) > 0 then
					local points = {
						(CFrame.lookAt(v.Position, v.To) * CFrame.new(data.barrelLength)).Position
					}
					for i = spreadRange[1], spreadRange[2], 2 do
						local to = CFrame.lookAt(v.Position, v.To) * CFrame.new(data.barrelLength) * CFrame.Angles(math.rad(i)) * CFrame.new((v.Position - v.To).Magnitude - data.barrelLength, 0)
						--love.graphics.line(v.Position.X, v.Position.Y, to.X, to.Y)
						points[#points+1] = to.Position
					end
					local xys = {}
					for i,v in pairs(points) do
						local x,y = v()
						xys[#xys+1] = x
						xys[#xys+1] = y
					end
					love.graphics.polygon("fill", unpack(xys))
				else
					Color3.new(255,255,255)(1, .75)
					local to = love.mouse.position()
					lineVec(v.Position, to)
				end
			end
			if v.Decal then
				Color3.new(255,255,255)()
				local scale = Vector.new(100, 100)
				local rot = CFrame.lookAt(v.Position, v.To).R
				if rot > math.pi /2 and rot < math.pi * 1.5 then
					scale = scale * Vector.new(1, -1)
				end
				image(
					v.Decal, 
					CFrame.lookAt(v.Position, v.To) * CFrame.new(data.barrelLength - data.gripOffset), 
					scale
				)
			end
		end
	end
end)

return module