--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	TITLE = "2d Rubik's cube"
	WIDTH, HEIGHT = 500,500
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	
	local resolution = 5
	local cellX, cellY = WIDTH/resolution, HEIGHT/resolution
	local board = {}
	local moveDir = Vector.new()
	local dragData
	local lastMousePos

	local y = 1
	for i = 1,resolution^2 do
		local x = (i % resolution) + 1
		if (i % resolution) == 0 then
			y = y + 1
		end

		local slot = {x = x, y = y}

		local button = Instance.new("Part")
		slot.button = button
		button.Clickable = true
		button.Color = Color3.new(255):Lerp(Color3.new(0,0,255), i/resolution)
		button.Activated:Connect(function()
			dragData = {
				dir = Vector.new(),
				slot = slot,
			}
			lastMousePos = love.mouse.position()
		end)

		board[#board+1] = slot
	end

	UserInput.InputEnded:Connect(function(input)
		if input.Mouse == Enum.Mouse.LeftMouseButton then
			dragData = nil
		end
	end)

	local packmanInc = function(numb, min, max, dir)
		local new = numb + dir
		if new > max then
			return min + dir
		elseif new < min then
			return max - dir
		else
			return new
		end
	end

	local percent = 1

	function update(dt)
		if dragData then
			local deltaMouse = love.mouse.position() - lastMousePos
			lastMousePos = love.mouse.position()
			dragData.dir = dragData.dir + deltaMouse

			if math.abs(dragData.dir.X) > math.abs(dragData.dir.Y) then
				for i,v in pairs(board) do
					if v.y == dragData.slot.y then
						v.x = packmanInc(v.x, 1, resolution, deltaMouse.X / cellX)
					end
				end
			else
				for i,v in pairs(board) do
					if v.X == dragData.slot.x then
						v.y = packmanInc(v.y, 1, resolution, deltaMouse.Y / cellY)
					end
				end
			end
		else
			for i,v in pairs(board) do
				v.x = math.floor(v.x + .5)
				v.y = math.floor(v.y + .5)
			end
		end
		for i,v in pairs(board) do
			v.button.Position = Vector.new(-WIDTH/2 + cellX/2 + (v.x-1) * cellX, -HEIGHT/2 + cellY/2 + (v.y-1) * cellY)
		end
	end

	function draw(dt)
	end
end)