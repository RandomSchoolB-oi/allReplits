--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	-- local animClass = require("Objects.Animation")
	-- local anim = animClass.new()
	-- anim:addFrame("Zombie.png")
	-- anim:addFrame("Zombie-old.png")

	WIDTH, HEIGHT = 500,700
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)

	AnchorClass = require("Objects.Anchor")
	SpringClass = require("Objects.Spring")

	local a1, a2 = AnchorClass.new(nil, 25), AnchorClass.new(nil, 25)

	a1.Position = Vector.new(0, -100)
	a1.Anchored = true
		a2.Mass = 0
		
	local spring = require("Objects.Spring").new(a1,a2)
	
	function update(dt)
		if love.mouse.isDown(1) then
			a2.Position = love.mouse.position()
			return
		end
	end

			
	function draw(dt)
	end
end)