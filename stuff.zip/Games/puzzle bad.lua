--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	TITLE = "2d Rubik's cube"
	WIDTH, HEIGHT = 500,500
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	
	local resolution = 5

	local dragDirection = Vector.new(0,0)
	local cellX, cellY = WIDTH/resolution, HEIGHT/resolution
	local board = {}
	local currentDragging
	local lastmousePos

	local letters = [[afkpubglqvchmrwdinsxejoty]]
	local buttonSerial = 1

	local setXY = function()
		for x,collumn in pairs(board) do
			for y,data in pairs(collumn) do
				data.x = x
				data.y = y
				data.button.Position = Vector.new(
					-WIDTH/2 + cellX/2 + (x-1)*cellX,
					-HEIGHT/2 + cellY/2 + (y-1)*cellY
				)
			end
		end
	end


	for x = 1, resolution do
		board[x] = {}
		for y = 1, resolution do
			local button = Instance.new("Part")
			local slot = {x = x, y = y, button = button}

			button.Clickable = true
			local xp, yp = x/resolution, y/resolution

			local zp = (xp+yp) / 4
			local r,b = xp * 255, yp * 255

			button.Color = Color3.new(r, 0, b)
			button.Size = Vector.new(cellX, cellY)
			button.Transparency = .5

			button.Text = letters:sub(buttonSerial, buttonSerial)
			buttonSerial = buttonSerial + 1

			button.Activated:Connect(function()
				lastmousePos = love.mouse.position()
				currentDragging = {x = slot.x, y = slot.y, button = button}
				print("Clicked", slot.x, slot.y)
			end)
			board[x][y] = slot
		end
	end
	setXY()

	UserInput.InputEnded:Connect(function(input)
		if input.Mouse == Enum.Mouse.LeftMouseButton then
			currentDragging = nil
			dragDirection = Vector.new()
		end
	end)

	local packmanInc = function(numb, min, max, dir)
		local new = numb + dir
		if new > max then
			return min
		elseif new < min then
			return max
		else
			return new
		end
	end

	local percent = 1

	function update(dt)
		if currentDragging then
			dragDirection = dragDirection + love.mouse.position() - lastmousePos
			lastmousePos = love.mouse.position()
			if dragDirection.Magnitude > 30 then
				if math.abs(dragDirection.X) > math.abs(dragDirection.Y) then
					local dir = mathf.sign(dragDirection.X)
					local newBoard = {}
					for x, collumn in pairs(board) do
						newBoard[x] = {}
					end
					for x, collumn in pairs(board) do
						for y, data in pairs(collumn) do
							if y == currentDragging.y then
								newBoard[packmanInc(x, 1, resolution, dir)][y] = data
							else
								newBoard[x][y] = data
							end
						end
					end
					board = newBoard
					dragDirection = dragDirection - Vector.new(cellX  * dir, 0)
					currentDragging.x = packmanInc(currentDragging.x, 1, resolution, dir)
				else
					local dir = mathf.sign(dragDirection.Y)
					local newCollumn = {}

					for i,v in pairs(board[currentDragging.x]) do
						newCollumn[packmanInc(i, 1, resolution, dir)] = v
					end

					board[currentDragging.x] = newCollumn

					dragDirection = dragDirection - Vector.new(0, cellY * dir)
					currentDragging.y = currentDragging.y + dir
				end
				setXY()
				--dragDirection = currentDragging.button.Position
			end
			--lastmousePos = lastmousePos + dragDirection
		end
	end

	function draw(dt)
		love.graphics.setColor(255,255,255)
		love.graphics.setLineWidth(5)
		lineVec(love.mouse.position(), love.mouse.position() + dragDirection)
	end
end)