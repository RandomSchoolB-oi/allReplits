--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
TITLE = "Rain"
	local drops = {}
	local serial = 0
	local gravity = Vector.new(0, 2000)

	local w,h,s = 1, 2,1
	local r,g,b = 50, 50, 255

	local wSlider = GuiObjects.Slider.new(1, 10, .1, 200)
	local hSlider = GuiObjects.Slider.new(1, 10, .1, 200)
	--local sSlider = GuiObjects.Slider.new(0, 10, .1, 200)

	local rSlider = GuiObjects.Slider.new(0, 255, 1, 200)
	local gSlider = GuiObjects.Slider.new(0, 255, 1, 200)
	local bSlider = GuiObjects.Slider.new(0, 255, 1, 200)

	local gxSlider = GuiObjects.Slider.new(-2000, 2000, 1, 200)
	local gySlider = GuiObjects.Slider.new(-2000, 2000, 1, 200)

	local dropCount = GuiObjects.Slider.new(0, 700, 1, 200)

	wSlider.Position = Vector.new(-250, 220)
	hSlider.Position = Vector.new(-250, 200)
	--sSlider.Position = Vector.new(-250, 180)

	bSlider.Position = Vector.new(-250, 150)
	gSlider.Position = Vector.new(-250, 130)
	rSlider.Position = Vector.new(-250, 110)
	gxSlider.Position = Vector.new(50, 220)
	gySlider.Position = Vector.new(50, 200)
	dropCount.Position = Vector.new(50, 180)

	function shuffleProperties(drop, new)
		local y = -HEIGHT/2 + math.random(-200, -100)
		if new then
			y = math.random(-height/2, height/2)
		end
		
		drop.Position = Vector.new(math.random(-WIDTH/2, WIDTH/2), y)
		drop.Distance = math.random(1, 5)
		drop.Velocity = Vector.new(0, math.random(100, 1000))
	end

	local newDrop = function()
		local drop = {}
		shuffleProperties(drop)

		local id = serial
		serial = serial + 1
		drop.id = id
		drops[id] = drop
	end

	dropCount.Moved:Connect(function(value)
		drops = {}
		for i = 1, value do
			newDrop()
		end
	end)


	local min, max = Vector.new(-WIDTH/2-300, -HEIGHT/2-300), Vector.new(WIDTH/2+300, HEIGHT/2+300)

	function update(dt)
		gravity = Vector.new(gxSlider.value, gySlider.value)
		w,h,s = wSlider.value, hSlider.value--, sSlider.value
		r,g,b = rSlider.value, gSlider.value, bSlider.value
		for id, drop in pairs(drops) do
			if drop.Position.X < min.X or drop.Position.Y < min.Y or drop.Position.X > max.X or drop.Position.Y > max.Y then
				shuffleProperties(drop)
			else
				drop.Position = drop.Position + ((drop.Velocity + gravity) * dt * drop.Distance/6)
			end
		end
	end

	function draw(dt)
		love.graphics.setColor(r,g,b)
		for id, drop in pairs(drops) do
			rect(1, drop.Position.X, drop.Position.Y, w * (drop.Distance/2), h * (drop.Distance/2))
		end
		love.graphics.setColor(255, 255, 255)
		text("height", -15, 200, 1)
		text("width",  -20, 220, 1)
	--	text("speed",  -20, 180, 1)
		text("r", -45, 110, 1)
		text("g", -45, 130, 1)
		text("b", -45, 150, 1)
		text("gx", 35, 220, 1)
		text("gy", 35, 200, 1)
		text("quantity", -5, 180, 1)
	end
end)