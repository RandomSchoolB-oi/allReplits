local module = {}
module.__index = module

local hand = {}
local handVisual = Instance.new("Part")
handVisual.Color = Color3.new(150, 150, 150)
handVisual.OutlineThickness = 0
handVisual.Clickable = false

local itemImages = {
	--Log = "Zombie.png",
	Log = Color3.new(255,255,255)
}

module.new = function(slotCount, dimentions)
	local self = setmetatable({
		slots = {},
		dimentions = dimentions or {4,4},
		_parts = {},
		_grid = GuiObjects.GridLayout.new()
	}, module)

	for i = 1, slotCount do
		self.slots[i] = {}
	end

	return self
end

function module:swap(index)
	local from,to = self.slots[index], hand

	local function swapVal(val)
		from[val], to[val] = to[val], from[val]
	end
	swapVal("name")
	swapVal("quantity")
end

function module:giveIndex(index, name, amount)
	local maxStack = 16
	local slot = self.slots[index]
	local currentQuantity = slot.quantity or 0
	local amountAdded = mathf.clamp(currentQuantity + amount, 0, maxStack) - currentQuantity

	slot.quantity = currentQuantity + amountAdded

	return amountAdded
end

function module:give(name, amount)
	local maxStack = 16
	for i,v in pairs(self.slots) do
		if amount > 0 and v.name == name then
			amount = amount - self:giveIndex(i, name, amount)
		end
	end
	if amount > 0 then
		for i,v in pairs(self.slots) do
			if amount > 0 and not v.name then
				local amountAdded = mathf.clamp(amount, 0, maxStack)
	
				v.quantity = amountAdded
				v.name = name
				
				amount = amount - amountAdded
			end
		end
	end
	if amount > 0 then
		return amount
	end
end

function module:render(from, to)
	local dim = self.dimentions
	local size = (to - from)
	size = Vector.new(math.abs(size.X), math.abs(size.Y))
	
	for index, slot in pairs(self.slots) do
		local x = index % dim[1]

		local image = itemImages[slot.name or ""]-- or ""
		
		if not self._parts[index] then
			local part = Instance.new("Part")
			part.Activated:Connect(function()
				if hand.name then
					if hand.name == slot.name then
						local amountAdded = self:giveIndex(index, hand.name, hand.quantity)
						hand.quantity = hand.quantity - amountAdded
						if hand.quantity <= 0 then
							hand = {}
						end
					else
						self:swap(index)
					end
				else
					self:swap(index)
				end
			end)
			part.OutlineThickness = 0
			part.Clickable = true
			self._parts[index] = part
		end

		local part = self._parts[index]
		--part.Image = 
		part.Color = image or Color3.new(100, 100, 100)
		part.Text = tostring(index)
	end
	local cellSize = Vector.new(size.X / dim[1], size.Y / dim[2])
	self._grid.Position = from + cellSize/2
	self._grid.MaxCellCount = dim[1]
	self._grid.CellSize = cellSize
	self._grid.CellPadding = Vector.new(6, 6)
	self._grid:allign(self._parts)
	-- for key, part in pairs(self._parts) do
	-- 	local value = self.slots[key]

	-- 	if value.quantity and value.quantity > 0 then
	-- 		local x,y = part.Position()
	-- 		local w,h = part.Size()
	-- 		part.TextColor()
	-- 		text(tostring(value.quantity), x + w/2,y + h/2 - 10,1, "r")
	-- 	end
	-- end
end

drawSignal:Connect(function()
	if hand.name then
		handVisual.Position = love.mouse.position()
		handVisual.Visible = true
		--handVisual.Image = itemImages[hand.name or ""] or ""
	else	
		handVisual.Visible = false
	end
end)

return module