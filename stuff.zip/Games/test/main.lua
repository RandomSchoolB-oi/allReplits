--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
-- require("boot")(function()
-- 	WIDTH, HEIGHT = 500,700
-- 	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)

-- 	-- local containerClass = require("Games.test.ContainerClass")

-- 	-- local container = containerClass.new(4*3, {4, 3})

-- 	-- container:give("Log", 32)

	
-- 	function update(dt)
-- 	end

-- 	function draw(dt)
-- 		--container:render(Vector.new(-250, 0), Vector.new(250, -350))
-- 	end
-- end)

require("boot")(function()
	WIDTH, HEIGHT = 500,700
 	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	local myImage = require("Images.fireball")
	local snake = IK.new()
	for i = 1, 2 do
		snake:add(100)
		end
		snake.base = Vector.new()
		
	function update(dt)
			snake.to = love.mouse.position()
	end

	function draw(dt)
		image(myImage, CFrame.new(0, 0, math.pi/4) * CFrame.new(0, 50), Vector.new(100,100))
	end
end)