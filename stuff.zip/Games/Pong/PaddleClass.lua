local module = {}
module.__index = {}

players = {}
local serial = 0

local directions = {
	Up = 1,
	Down = -1,
}
local screenScale = {
	X = WIDTH,
	Y = HEIGHT,
}
	
local playerData = {
	{
		controls = {
			Down = Enum.Keyboard.Q,
			Up   = Enum.Keyboard.A,
		},
		Origin = CFrame.new(-WIDTH/2, 0),
		Size = Vector.new(10,100),
		Axis = "Y",
	},
	{
		controls = {
			Down = Enum.Keyboard.O,
			Up   = Enum.Keyboard.L,
		},
		Origin = CFrame.new(WIDTH/2, 0),
		Size = Vector.new(10,100),
		Axis = "Y",
	},
	{
		controls = {
			Down = Enum.Keyboard.W,
			Up   = Enum.Keyboard.I,
		},
		Origin = CFrame.new(0, -HEIGHT/2),
		Size = Vector.new(100,10),
		Axis = "X",
	},
	{
		controls = {
			Down = Enum.Keyboard.S,
			Up   = Enum.Keyboard.K,
		},
		Origin = CFrame.new(0, HEIGHT/2),
		Size = Vector.new(100,10),
		Axis = "X",
	},
}
	
module.new = function()

	local player = {}
	serial = serial + 1
	local id = serial
	player.id = id
	players[id] = player

	local data = playerData[id]
		
	local part = Instance.new("Part")
	part.Size = Vector.new(5,50)
	part.CFrame = data.Origin
	part.Size = data.Size
	player.part = part
	player.score = 0
	

	return player
end

updateSignal:Connect(function(dt)
	for id, self in pairs(players) do
		for dir, control in pairs(playerData[id].controls) do
			if love.keyboard.isDown(control) then
				local fakevec = {X = 0, Y = 0, R = 0}
				local axis = playerData[id].Axis
				fakevec[axis] = directions[dir] * dt * 400
						
				local cfmul = CFrame.new(fakevec.X, fakevec.Y, fakevec.R)
				local cf = self.part.CFrame * cfmul
				local tbl = {X = cf.X, Y = cf.Y, R = cf.R}
				tbl[axis] = mathf.clamp(tbl[axis], -screenScale[axis]/2 + self.part.Size[axis]/2, screenScale[axis]/2 - self.part.Size[axis]/2)
				local clamped = CFrame.new(tbl.X, tbl.Y, tbl.R)
				
				self.part.CFrame = clamped
			end
		end
	end
end)
	
return module