local module = {}
module.__index = module

local balls = {}
local serial = 0
local defaultVelocity = Vector.new(400, 150)
	
module.new = function()
		
	local ball = setmetatable({},module)
	local part = Instance.new("Part")
	part.Shape = "Circle"
	part.Size = Vector.new(25,25)
	part.Transparency = 0

	ball.immunity = 0
	ball.part = part
	ball.velocity = defaultVelocity
	ball.collisionRay = Ray.new(CFrame.new(), 10, {part}, nil, false)
	
	local id = serial
	serial = serial + 1
	ball.id = id
	balls[id] = ball
		
	return ball
end

-- drawSignal:Connect(function()
-- 	for id, self in pairs(balls) do
-- 		local from = self.part.Position
-- 		local to = from + self.velocity * 1000
-- 		love.graphics.setColor(255,255,255)
-- 		love.graphics.line(from.X, from.Y, to.X, to.Y)
-- 	end
-- end)

function module:update(dt)
	if self.immunity <= 0 then
		self.immunity = 0
		local ball = self.part
		local velocity = self.velocity	
		local hw = (WIDTH - ball.Size.X)/2
		local hh = (HEIGHT - ball.Size.Y)/2
		

		self.collisionRay.CFrame = CFrame.lookAt(ball.Position, ball.Position + velocity * dt)
		self.collisionRay.Length = ball.Size.X/2 + velocity.Magnitude * dt
				
		local part, pos, norm = self.collisionRay:cast()
		if norm then
			self.velocity = velocity.Unit:reflect(norm) * (velocity.Magnitude * 1)
		else
			ball.Position = ball.Position + velocity * dt
		end

		if #players < 1 then return end
				
		local hw = WIDTH/2
		local hh = HEIGHT/2
		local add = function(player, velocity)
			if not player then return end
			player.score = player.score + 1
			self.part.Position = Vector.new(0,0)
			self.velocity = defaultVelocity * velocity
			self.immunity = 1
		end
		if self.part.Position.X < -hw then
			local player = players[2]
			add(player, Vector.new(1, 1))
			return
		end
		if self.part.Position.X > hw then
			local player = players[1]
			add(player, Vector.new(-1, 1))
			return
		end
			
		if self.part.Position.Y < -hh then
			local player = players[3]
			add(player, Vector.new(1, 1))
			return
		end
		if self.part.Position.Y > hh then
			local player = players[4]
			add(player, Vector.new(1, -1))
			return
		end
	else
		self.immunity = self.immunity - dt
	end	
end

updateSignal:Connect(function(dt)
	for id, self in pairs(balls) do
		self:update(dt)
	end
end)

return module