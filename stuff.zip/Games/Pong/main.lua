--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	WIDTH,HEIGHT = 800,400	
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)


	local barrier1 = Instance.new("Part")
	barrier1.CFrame = CFrame.new(0, -HEIGHT/2)
	barrier1.Size = Vector.new(WIDTH, 2)
			
	local barrier2 = Instance.new("Part")
	barrier2.CFrame = CFrame.new(0, HEIGHT/2)
	barrier2.Size = Vector.new(WIDTH, 2)
			
	-- local barrier3 = Instance.new("Part")	
	-- barrier3.CFrame = CFrame.new(-WIDTH/2, 0)
	-- barrier3.Size = Vector.new(0, HEIGHT)
			
	-- local barrier4 = Instance.new("Part")
	-- barrier4.CFrame = CFrame.new(WIDTH/2, 0)
	-- barrier4.Size = Vector.new(0, HEIGHT)

	-- local p1 = Instance.new("Part")
	-- p1.CFrame = CFrame.new(WIDTH/2, HEIGHT/2, math.pi/4)
	-- local p2 = Instance.new("Part")
	-- p2.CFrame = CFrame.new(-WIDTH/2, HEIGHT/2, math.pi/4)
	-- local p3 = Instance.new("Part")
	-- p3.CFrame = CFrame.new(WIDTH/2, -HEIGHT/2, math.pi/4)
	-- local p4 = Instance.new("Part")
	-- p4.CFrame = CFrame.new(-WIDTH/2, -HEIGHT/2, math.pi/4)
			
	local ballClass = require("Games.Pong.BallClass")
	local playerClass = require("Games.Pong.PaddleClass")

	local balls = {
		ballClass.new(),
	}
	for i,v in pairs(balls) do
		v.part.Position = Vector.new((i - #balls/2) * 40,0)
	end
	
	local p1 = playerClass.new()
	local p2 = playerClass.new()
	-- local p3 = playerClass.new()
	-- local p4 = playerClass.new()
	
	local paddles = {}
	
	function update(dt)
		
	end

	function draw(dt)
		--text(tostring(p1.score), tostring(p2.score),0, -100, 2)
		text(tostring(p1.score), -50, 0, 2)
		text(tostring(p2.score), 50, 0, 2)
		-- text(tostring(p3.score), 0, -50, 2)
		-- text(tostring(p4.score), 0, 50, 2)
		-- local currentFrame = anim.Decal
		-- if currentFrame then
		-- 	image(currentFrame, CFrame.new(), Vector.new(100, 100))
		-- end
	end

	UserInput.InputBegan:Connect(function(input)
		if input.Keyboard == Enum.Keyboard.P then
			paused = not paused
			return
		end
	end)
end)