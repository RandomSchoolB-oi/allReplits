--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal Region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	TITLE = "tic tac toe"
	WIDTH, HEIGHT = 500,500
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)
	local playerCount = 2
	local playerSigns = {
		"X",
		"O",
		"Y",
		"Z",
	}
	local resolution = 3
	local winQuantity = 3
	local cellX, cellY = WIDTH / resolution, HEIGHT / resolution

	local board = {}
	local player = 1

	local reset = function()
		for x, collumn in pairs(board) do
			for y, data in pairs(collumn) do
				data.player = 0
			end
		end
	end

	local lookForWinner = function(list)
		for i,v in pairs(list) do
			if i > 0 and v >= winQuantity then
				print(playerSigns[i], "won")
				reset()
				return
			end
		end
	end

	local checkForWin = function()
		local embedded = {}
		for x = 1, resolution do
			local collumn = {}
			for y = 1, resolution do
				local player = board[x][y].player
				collumn[player] = (collumn[player] or 0) + 1
			end
			embedded[#embedded+1] = collumn
		end

		for y = 1, resolution do
			local row = {}
			for x = 1, resolution do
				local player = board[x][y].player
				row[player] = (row[player] or 0) + 1
			end
			embedded[#embedded+1] = row
		end

		local diagonal1 = {}
		for i = 1, resolution do
			local player = board[i][i].player
			diagonal1[player] = (diagonal1[player] or 0) + 1
		end
		local diagonal2 = {}
		for i = 1, resolution do
			local player = board[i][resolution-i + 1].player
			diagonal2[player] = (diagonal2[player] or 0) + 1
		end

		lookForWinner(diagonal1)
		lookForWinner(diagonal2)
		for i,v in pairs(embedded) do
			lookForWinner(v)
		end
	end

	for x = 1, resolution do
		board[x] = {}
		for y = 1, resolution do
			local button = Instance.new("Part")
			button.Clickable = true
			button.Size = Vector.new(cellX, cellY)
			button.Position = Vector.new(
				-WIDTH/2 + cellX/2 + cellX * (x - 1),
				-HEIGHT/2 + cellY/2 + cellY * (y - 1)
			)
			button.Transparency = .5
			button.Activated:Connect(function()
				if board[x][y].player == 0 then
					board[x][y].player = player
					player = player % playerCount + 1
					
					checkForWin()
				end
			end)
			board[x][y] = {
				button = button,
				player = 0,
			}
		end
	end

	function update(dt)
	end

	function draw(dt)
		love.graphics.setColor(0,0,0)
		love.graphics.setLineWidth(5)
		for x, collumn in pairs(board) do
			for y, data in pairs(collumn) do
				text(playerSigns[data.player] or "", data.button.Position.X, data.button.Position.Y, 5)
			end
		end
	end
end)