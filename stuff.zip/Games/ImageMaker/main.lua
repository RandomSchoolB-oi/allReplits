--auto fill words --[[CAMERA cast wait delay newThread Thread ElapsedTime updateSignal drawSignal region GunClass TreeClass update draw dt init WIDTH HEIGHT FPS TITLE BACKGROUND_COLOR DRAWRAYS DRAWFPS CircleSegments InputBegan Connect Mouse Keyboard LeftMouseButton RightMouseButton graphics CFrame Vector Color3 Enum Instance new rect ellipse Ray UserInput mathf Signal newHSV IK GuiObjects ColorPicker Gamepad GridLayout Joystick ListLayout ProgressBar Bar Radial base to]]
require("boot")(function()
	local image = {}
	print("What resolution? (int)")
	local resolution = io.read()
	local brushRadius = 0
	local gridPadding = 0
	WIDTH,HEIGHT = 400,400
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)

	-- local Modes = {
	-- 	[1] = "Drawing",
	-- 	[2] = "Color Select",
	-- }
			
	local mode = 2

	local cellX, cellY = WIDTH / resolution, HEIGHT / resolution

	for x = 1, resolution do
		image[x] = {}
		for y = 1, resolution do
			image[x][y] = {Color = Color3.new(), Transparency = 1}
		end
	end

	local color = Color3.new(255,255,255)

			
	local convert = function()
		local varNames = {
			"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"
		}
		local varSerial = 0
		local lookup = {}
		for x,collumn in pairs(image) do
			for y, data in pairs(collumn) do
				local r,g,b = data.Color.R, data.Color.G,data.Color.B
				local t = data.Transparency
				local str = tostring(r)..","..tostring(g)..","..tostring(b)..","..tostring(t)
				lookup[str] = true
			end
		end
		--assign variablenames
		for i,v in pairs(lookup) do
			varSerial = varSerial + 1
			lookup[i] = varNames[varSerial]
		end

		-- construct string
		local colorlist = "local colors = {"
		for i,v in pairs(lookup) do
			local s = split(i, ",")
			local r,g,b,t = s[1], s[2], s[3], s[4]
			local str = v.." = {Color = Color3.new("..r..","..g..","..b.."), Transparency = "..t.."},"
			colorlist = colorlist ..str
		end
		colorlist = colorlist .. "}"
		local imageStr = "local image = {"
		for x,collumn in pairs(image) do
			imageStr = imageStr .. "{"
			for y, data in pairs(collumn) do
				local r,g,b = data.Color.R, data.Color.G,data.Color.B
				local t = data.Transparency
				local str = tostring(r)..","..tostring(g)..","..tostring(b)..","..tostring(t)
				local text = "colors."..lookup[str]..","
						imageStr = imageStr .. text
			end			
			imageStr = imageStr .. "},"..nl
		end
		imageStr = imageStr .. "}"
		
		print(colorlist)
		print(imageStr)
		print("return image")
	end
		
	UserInput.InputBegan:Connect(function(input)
		if input.Keyboard == Enum.Keyboard.E then
			mode = mode % 2 + 1
		elseif input.Keyboard == Enum.Keyboard.Q then
			convert()
		end
	end)

	GuiObjects.ColorPicker.init()

			
	function update(dt)
		color = GuiObjects.ColorPicker.getColor()
		if mode == 1 then
			local lmbDown = love.mouse.isDown(1)
			local rmbDown = love.mouse.isDown(2)
			if lmbDown or rmbDown then
				local res = resolution - 1
				local mx,my = love.mouse.getX()+1, love.mouse.getY()+1
				-- local fx,fy = 
				-- math.ceil((mx - mx % res) / WIDTH * res) + 1, 
				-- math.ceil((my - my % res) / HEIGHT * res) + 1
				local fx,fy = 
				math.ceil((mx - mx % cellX) / cellX) + 1, 
				math.ceil((my - my % cellY) / cellY) + 1
				local fVec = Vector.new(fx,fy)
				for _x = -brushRadius, brushRadius do
					for _y = -brushRadius, brushRadius do
						local xyVec = Vector.new(_x,_y) + fVec
						local x,y = xyVec()
						if (xyVec - fVec).Magnitude <= brushRadius then
							if image[x] and image[x][y] then
								if lmbDown then
									image[x][y].Color = color
									image[x][y].Transparency = 0
								elseif rmbDown then
									image[x][y].Color = Color3.new(0,0,0)
									image[x][y].Transparency = 1
								end
							end
						end
					end
				end
				
			end
		end
		GuiObjects.ColorPicker.Enabled = mode == 2 	
	end

	function draw(dt)
		if mode == 1 then
			for x,collumn in pairs(image) do
				for y,data in pairs(collumn) do
					data.Color(1, data.Transparency)
					rect(
						1, 
						
						(x - 1) * cellX - (WIDTH/2) + (cellX/2), 
						(y - 1) * cellY - (HEIGHT/2) + (cellY/2), 

						cellX - (2 * gridPadding), 
						cellY - (2 * gridPadding)
					)
				end
			end
		end
	end
end)