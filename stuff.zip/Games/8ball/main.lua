require("boot")(function()
	WIDTH,HEIGHT = 400,400
	CAMERA = CFrame.new(-WIDTH/2, -HEIGHT/2)

	local board = {
		Size = Vector.new(100,200),
		Balls = {},
		qball = ballClass.new(50, 150)
	}
	
	function update(dt)
			
	end

	function draw(dt)
			
	end
end)