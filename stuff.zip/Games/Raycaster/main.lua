--require("Tools.Language")
--require("Tools.InstanceStore")
require("boot")(function()
	WIDTH,HEIGHT = 500,500
	FPS = 900000
	TITLE = "name"
	BACKGROUND_COLOR = Color3.new(50,50,50)
	
	local top = Instance.new("Part")
	top.CFrame = CFrame.new(0, -HEIGHT/2)
	top.Size = Vector.new(WIDTH, 2)
	local bottom = Instance.new("Part")
	bottom.CFrame = CFrame.new(0, HEIGHT/2)
	bottom.Size = Vector.new(WIDTH, 2)
	local left = Instance.new("Part")
	left.CFrame = CFrame.new(-WIDTH/2, 0)
	left.Size = Vector.new(2, HEIGHT)
	local right = Instance.new("Part")
	right.CFrame = CFrame.new(WIDTH/2, 0)
	right.Size = Vector.new(2, HEIGHT)
	local box = Instance.new("Part")
	box.Color = Color3.new(255,0,0)
	--box.CFrame = CFrame.new(WIDTH/2 - 50, HEIGHT/2 - 50)

	local parts = {
			top,bottom,left,right,box
	}
	for i,v in pairs(parts) do
		v.Visible = false
	end

	local lightDir = Vector.new(1,0).Unit
			
	local maxDist = math.sqrt(WIDTH^2+HEIGHT^2)/2
	local fov = 90
	local rayCount = 45
	local rays = {}
	local point = CFrame.new()
	local updateRays = function()
		local radfov = math.rad(fov)
		for i,v in pairs(rays) do
			v.CFrame = point * CFrame.Angles(lerp(-radfov/2, radfov/2, i/rayCount))
		end
	end

	for i=1,rayCount do
		rays[#rays+1] = Ray.new(CFrame.new(), 1000000)
	end

	function update(dt)
	--	point = CFrame.lookAt(point.Position, love.mouse.position())
		if love.keyboard.isDown("w") then
			point = point + point.LookVector * 100 * dt
		end
		if love.keyboard.isDown("s") then
			point = point + point.LookVector * -100 * dt
		end
		if love.keyboard.isDown("a") then
			point = point * CFrame.Angles(-math.pi * dt)
		end
		if love.keyboard.isDown("d") then
			point = point * CFrame.Angles(math.pi * dt)
		end
			point = CFrame.new(mathf.clamp(point.X , -WIDTH/2, WIDTH/2), mathf.clamp(point.Y, -HEIGHT/2, HEIGHT/2), point.R)
		updateRays()
	end
	function draw(dt)
		for i,v in pairs(rays) do
			local part, pos, norm = v:cast()
			-- if pos then 
			-- 	love.graphics.setColor(255, 255, 255)
			-- 	love.graphics.line(pos.X, pos.Y, point.X, point.Y)
			-- 	love.graphics.circle("fill", pos.X, pos.Y, 5)
			-- end
			if pos and part then
				local dot = norm:dot(lightDir)
					
				local dist = (pos - point.Position).Magnitude
				local cos = math.cos(v.CFrame.R)
				local color = part.Color:Lerp(Color3.new(0,0,0), mathf.clamp(dist/maxDist, 0, 1))
				color(1-(dot/2 + .5))
				rect(1, 
					lerp(-WIDTH/2, WIDTH/2, i/#rays), 
					0, 
					WIDTH/#rays, 
					mathf.clamp(HEIGHT - (cos * (dist)), 0, HEIGHT)
				)
			end
			-- if pos then
			-- 	love.graphics.circle("fill", pos.X, pos.Y, 5)
			-- 	love.graphics.line(pos.X, pos.Y, point.X, point.Y)
			-- end
		end
		love.graphics.setColor(255, 255, 255)
		local look = point.LookVector * 10
		love.graphics.circle("fill", point.X, point.Y, 5)
		love.graphics.line(point.X, point.Y, point.X + look.X, point.Y + look.Y)
	end
end)