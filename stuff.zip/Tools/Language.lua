 -- just an experimental thing, you can ignore this whole script
local variables = {}
local functions
functions = {
	["log"] = function(variable)
		print(variables[variable])
	end,
	["set"] = function(varname, value)
		local isnumber, isbool = tonumber(value), value == "false" and true or value == "true" and true
		if isnumber then
			variables[varname] = isnumber
		elseif isbool then
			variables[varname] = value == "false" and false or value == "true" and true
		else
			variables[varname] = value
		end
	end,
	["get"] = function(var)
		return variables[var]
	end,
	["+"] = function(var1name,var2name)
		local var1,var2 = functions.get(var1name), functions.get(var2name)
		functions.set(var1name, var1+var2)
	end
}
function compile(code)
	local lines = split(code, ";")
	local codeList = {}
	for index, line in pairs(lines) do
		local splited = split(line,":")

		local call, values = splited[1], split(splited[2], ",")

		if functions[call] then
			functions[call](unpack(values))
		end
	end
	return codeList
end

function run(code)
	for i,v in pairs(code) do
		v()
	end
end