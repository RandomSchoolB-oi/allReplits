local classCount = {}
local newline = [[

]]
InstanceToLua = function(instance)
	local className = instance.ClassName
	local varName = className.."_"..(classCount[className] or 0)

	local x,y,r = instance.CFrame()
	local w,h = instance.Size()

	local code = "local "..varName.." = Instance.new(\""..className.."\");" .. varName..".CFrame = CFrame.new("..x..", "..y..", "..r..");"..varName..".Size = Vector.new("..w..", "..h..");"
	code = code:gsub(";",nl)
	classCount[className] = (classCount[className] or 0) + 1
	love.system.setClipboardText(code)
	print(code)
end
saveAllParts = function()
	for i,v in pairs(Instance.SaveableParts) do
		InstanceToLua(v)
	end
end