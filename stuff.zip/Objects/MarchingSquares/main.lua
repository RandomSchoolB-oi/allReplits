local module = {}

local lookup = require("Objects.MarchingSquares.lookup")

local cells = {}
for y = 0,1, 0.5 do
	for x = 0,1, 0.5 do
		cells[#cells+1] = Vector.new(x,y)
	end
end

module.draw = function(world, x,y, size)
	local key = module.getKey(world, x, y)
	local pattern = lookup[key]
	if pattern then
		for _, shape in pairs(pattern) do
			local wx,wy = size * Vector.new(x,y)
			local points = {}
			for i,v in pairs(shape) do
				points[#points+1] = (cells[v] + Vector.new(x,y)) * size
			end
			drawPolygon(1, points)
		end
	end
end

module.getCell = function(world,x,y)
	if world[x] then
		return world[x][y]
	end
end

module.getKey = function(world,x,y)
	local key = ""
	for _y = 0, 1 do
		for _x = 0, 1 do
			local cell = module.getCell(world, x + _x, y + _y) or 0
			key = key..tostring(cell)
		end
	end
	return key
end

module.drawWorld = function(world, from, to)
	local cellSize = (to - from) / Vector.new(#world, #world[1])
	for x, row in pairs(world) do
		for y, cell in pairs(row) do
			module.draw(world,x,y,cellSize)
		end
	end
end

return module