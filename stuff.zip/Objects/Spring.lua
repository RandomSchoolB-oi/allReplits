local gravity = Vector.new(0, 1000)
-- 	if love.mouse.isDown(1) then
-- 		spring.endPoint = love.mouse.position()
-- 		spring.velocity = Vector.new()
-- 		return
-- 	end


local module = {}
module.__index = module

local springs = {}
local serial = 0

module.new = function(a,b)
	local spring = setmetatable({
		anchorA = a or AnchorClass.new(),
		anchorB = b or AnchorClass.new(Vector.new(0, 50)),

		segments = 11,
		radius = 25,

		stiffness = 150,
		restLength = 100,
		deceleration = 0.075,
	}, module)

	local id = serial
	serial = serial + 1
	spring.id = id
	springs[id] = spring

	return spring
end

function module:Destroy()
	springs[self.id] = nil
end

function module:Update(dt)
	local spring = self
	local a,b = spring.anchorA, spring.anchorB
	
	local springLength = (a.Position - b.Position).Magnitude
	local length = springLength - spring.restLength
	local force = length * spring.stiffness


	local looking = CFrame.lookAt(a.Position, b.Position)
	local aForce = looking.LookVector * force + gravity
	local bForce = looking.LookVector * -force + gravity

	--spring.endPoint = spring.endPoint + spring.velocity 
	a.Velocity, b.Velocity = a.Velocity + aForce * dt, b.Velocity + bForce * dt
end

function module:Draw()
	local spring = self
	local a,b = spring.anchorA.Position, spring.anchorB.Position
	local segments = spring.segments
	local lastPoint = a
	local rightVec = CFrame.lookAt(a, b).RightVector
	local length = (lastPoint - b).Magnitude

	local radius = map(length, 0, spring.radius * (segments-1) * math.pi, spring.radius, 0)
	for i = 1, segments do
		local percent = i / segments
		local point = a:Lerp(b, percent)
		local off = ((i % 2) - .5) * 2
				point = point + rightVec * off * radius
		if i == segments then
			point = b
		end
		
		lineVec(lastPoint, point)
		lastPoint = point
	end
end

updateSignal:Connect(function(dt)
	for i,v in pairs(springs) do
		v:Update(dt)
	end
end)

drawSignal:Connect(function()
	for i,v in pairs(springs) do
		v:Draw()
	end
end)

return module