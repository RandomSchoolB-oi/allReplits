local module = {}
module.__index = module

local tweens = {}
local serial = 0

function module.new(object, info, properties)
	local current = {}
	for i,v in pairs(properties) do
		current[i] = object[i]
	end

	local tween = setmetatable({
		object = object,
		info = info,
		properties = {from = current, to = properties},
		timeIn = 0,
		playing = false,
		Done = Signal.new(),
	}, module)

	local id = serial
	serial = serial + 1
	tween.id = id
	tweens[id] = tween

	return tween
end

function module:play()
	self.playing = true
end

function module:stop()
	self.playing = false
end

local tweenStyles = {
	Linear = function(from, to, a)
		return from * (1-a) + to * a
	end,
	Exponential = function(from, to, a)
		return (from * ((1-a) ^ 2) + to * (a^2))
	end,
	Quad = function(from, to, a)
		return (from * ((1-a) ^ 4) + to * (a^4))
	end,
}

updateSignal:Connect(function(dt)
	for id, self in pairs(tweens) do
		if self.playing then
			local allDone = true
			self.timeIn = self.timeIn + dt
			for prop, to in pairs(self.properties.to) do
				self.object[prop] = tweenStyles[self.info.style](self.properties.from[prop], to, mathf.clamp((self.timeIn) / self.info.length * 2, 0, 1))
				if self.object[prop] ~= to then
					allDone = false
				end
			end
			if allDone then
				self.playing = false
				self.Done:Run(tick())
			end
		end
	end
end)


return {
	tween = module, 
	tweenInfo = {new = function(length, style)
		return {length = length or 1, style = style or "Linear"}
	end}
}