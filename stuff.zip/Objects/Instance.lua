local module = {}
module.__index = module

module.Gravity = Vector.new(0, 1962)

local parts = {}
local serializer = 0

local types = {
	Part = "BasePart",
	EditableFrame = "BasePart",
	Text = "BasePart",
}

local clickedButton

module.type = "Instance"

module.CircleSegments = 10
local drawShadows = false

function module:Inside(pos)
	if self.Shape == "Circle" then
		return self.Size.X/2 >= (self.Position - pos).Magnitude
	elseif self.Shape == "Rectangle" or self.Shape == "Wedge" then
		local topLeft = self.Position - self.Size/2
		local bottomRight = self.Position + self.Size/2
		return pos > topLeft and pos < bottomRight
	end
end

within = function(x1,y1, x2,y2,w2,h2)
	x2 = x2 - w2/2
	y2 = y2 - h2/2
	return x1 > x2 and y1 > y2 and x1 < x2+w2 and y1 < y2+h2
end

module.Parts = parts

module.SaveableParts = {}

module.new = function(className, save)
	assert(types[className], "not a valid instance type")
	local part = {
		ClassName = className,
		CFrame = CFrame.new(0, 0, 0),
		Position = Vector.new(0, 0),
		Size = Vector.new(100, 100),
		Color = Color3.new(255, 255, 255),
		Visible = true,
		Transparency = 0,
		Shape = "Rectangle",
		OutlineStyle = "Border",
		OutlineThickness = 1,
		Changed = Signal.new(),
		TextColor = Color3.new(255,255,255),
		TextSize = 1,
		TextThickness = 1,
		--Touched = Signal.new(),
		Text = "",
		Image = "",

		Activated = Signal.new(),
		InputBegan = Signal.new(),
		-- InputEnded = Signal.new(),
		AutomaticColor = true,
		Clickable = false,
	}
	part.OutlineColor = part.Color



	if className == "EditableFrame" then
		part._dragData = {
			left = module.new("Part"),
			right = module.new("Part"),
			up = module.new("Part"),
			down = module.new("Part"),
		}
		part.OutlineStyle = nil
		for i,v in pairs(part._dragData) do
			v.Size = Vector.new(20,20)
			v.OutlineStyle = nil
			v.Clickable = true

			v.Activated:Connect(function()
				part._dragData.dragOffset = v.Position - love.mouse.position()
				part._dragData.currentDrag = v
			end)
		end
	elseif types[className] == "BasePart" then
		part.CanCollide = true
		part.Anchored = true
		part.Velocity = Vector.new()
		part._VelocityRay = true--Ray.new(CFrame.new(1,1),1)
		if className == "Text" then
			--part.Transparency = 1
			part.Text = "Label"
			part.Transparency = 1
			part.OutlineThickness = 0
		end
	end

	local metapart = setmetatable(part, module)
	local editTable = setmetatable({},{
		__index = function(self, index)
			return part[index]
		end,
		__newindex = function(self, index, value)
			if index == "CFrame" then
				part.Position = value.Position
			elseif index == "Position" then
				part.CFrame = CFrame.new(value.X, value.Y, part.CFrame.R)
			else
				if part[index] == nil then
					return
				end
			end
			if index == "Image" then
				if value ~= "" then
					part._decal = love.graphics.newImage("Images/" .. value)
				else
					part._decal = nil
				end
			end
			if part[index] ~= value then
				local oldValue = part[index]
				part[index] = value
				part.Changed:Run(index, oldValue, value)
			end
		end
	})

	local id = serializer
	serializer=serializer+1
	part.id = id
	parts[id] = editTable

	if className == "EditableFrame" then
		editTable.Activated:Connect(function()
			editTable._dragData.dragOffset = editTable.Position - love.mouse.position()
			editTable._dragData.currentDrag = editTable
		end)
	elseif editTable:IsA("BasePart") then
		part._VelocityRay = Ray.new(part.CFrame, 100, {editTable})
	end
	if save then
		module.SaveableParts[#module.SaveableParts+1] = editTable
	end

	return editTable
end

function module:IsA(className)
	return className == self.ClassName or types[self.ClassName] == className
end

function module:Destroy()
	parts[self.id or -1] = nil
	for i,v in pairs(self) do
		self[i] = nil
	end
end

function updateParts(dt)
	for i,v in pairs(parts) do
		
		if v:IsA("EditableFrame") then
			local currentDragging = v._dragData.currentDrag
			local mousePos = love.mouse.position() + (v._dragData.dragOffset or Vector.new(0, 0))
			if UserInput.isDown(1) then
				if currentDragging == v._dragData.left or currentDragging == v._dragData.right then
					currentDragging.Position = Vector.new(mousePos.X, v.Position.Y)
					v.Position = v._dragData.right.Position:Lerp(v._dragData.left.Position, .5)
					v.Size = Vector.new((v._dragData.left.Position - v._dragData.right.Position).Magnitude-(v._dragData.left.Size.X), v.Size.Y)
				elseif currentDragging == v._dragData.up or currentDragging == v._dragData.down then
					currentDragging.Position = Vector.new(v.Position.X, mousePos.Y)
					v.Position = v._dragData.up.Position:Lerp(v._dragData.down.Position, .5)
					v.Size = Vector.new(v.Size.X, (v._dragData.up.Position - v._dragData.down.Position).Magnitude-(v._dragData.up.Size.Y))
				elseif currentDragging == v then
					currentDragging.Position = mousePos
				end
			else
				v._dragData.currentDrag = nil
			end
			local x,y = v.Position()
			local w,h = v.Size()
			v._dragData.left.Position = Vector.new(x - w/2-(v._dragData.left.Size.X/2), y)
			v._dragData.right.Position = Vector.new(x + w/2+(v._dragData.right.Size.X/2), y)
			v._dragData.up.Position = Vector.new(x, y - h/2-(v._dragData.up.Size.Y/2))
			v._dragData.down.Position = Vector.new(x, y + h/2+(v._dragData.down.Size.Y/2))
		elseif v:IsA("BasePart") then
			if not v.Anchored then
				local nextPos = v.Position + v.Velocity * dt
				v.Velocity = (v.Velocity) + module.Gravity * dt
				local canMove = true
					
				for _, other in pairs(parts) do
					if other ~= v and v:colliding(nextPos, other) then
						canMove = false
					end
				end
				if canMove then
					v.Position = nextPos
				else
					if v.Velocity.Magnitude > 1 then
						v.Velocity = v.Velocity * Vector.new(-.5,-.5)
						local oldVelocity = v.Velocity
						
						v.Velocity = oldVelocity.Unit:reflect(norm) * (oldVelocity.Magnitude * 1)
					else
						v.Velocity = Vector.new(0,0)
					end
				end
			end
		end
	end
end

function module:thicknessFromAngle(angle)
		local angle = angle + self.CFrame.R % (math.pi*2)
	local w,h = (self.Size/2)()
	local diag = math.sqrt(w^2+h^2)

	local space = (diag*2) - self.Size.Magnitude/2
		
	local c = math.abs(math.cos(angle*2))
	return diag + space - space * (c/2)
end
	
function drawParts()
	if drawShadows then
		for i,v in pairs(parts) do
			love.graphics.push()
			love.graphics.translate((CAMERA.Position + Vector.new(WIDTH/2, HEIGHT/2))())
			
			local x,y,r = v.CFrame()
			local w,h = v.Size()
			if v.Visible then
				local sunX, sunY = (SunDirection * 6)()
				love.graphics.setColor(0, 0, 0, 100)
				if v.Shape == "Rectangle" then
					rect(1, x + sunX, y + sunY, w, h, r)
				elseif v.Shape == "Circle" then
					ellipse(1, x + sunX, y + sunY, w, h, r)	
				elseif v.Shape == "Wedge" then
					tri(1, x-w/2, y-h/2, x-w/2, y+h/2, x+w/2, y+h/2)
				end
			end
			love.graphics.pop()
		end
	end

	for i,v in pairs(parts) do
		if v.Visible then
			local rmx,rmy = love.mouse.position()()
			local mx,my = love.mouse.getPosition()
			local x,y,r = v.CFrame()
			local w,h = v.Size()
			-- x,y = x * STUDSIZE, y * STUDSIZE
			-- w,h = w * STUDSIZE, h * STUDSIZE
			
			local inside = within(rmx,rmy, x,y, w,h)
			love.graphics.push()
			love.graphics.translate((CAMERA.Position + Vector.new(WIDTH/2, HEIGHT/2))())

			if v.Clickable and inside and v.AutomaticColor then
				if UserInput.isDown(1) then
					v.Color(1.2, v.Transparency)
				else
					v.Color(.8, v.Transparency)
				end
			else
				v.Color(1, v.Transparency)
			end
			if v.Shape == "Rectangle" then
				if v.OutlineStyle == "Border" then
					if v.OutlineThickness > 0 then
						rect(true, x,y, w,h,r)
						v.OutlineColor(.5)
						love.graphics.setLineWidth(v.OutlineThickness)
						rect(false, x,y,w+v.OutlineThickness*2,h+v.OutlineThickness*2, r)
						love.graphics.setLineWidth(1)
					else
						rect(true, x,y, w,h,r)
					end
				elseif v.OutlineStyle == "Fancy" then
					rect(true, x,y, w,h,r)
					love.graphics.push()
					love.graphics.translate(x,y)
					love.graphics.rotate(r)
					local t = v.OutlineThickness
					--top
					v.OutlineColor(.9)
					for i=0, t-1 do
						rect(true, 0, -h/2+i,w-i*2,1, 0)
					end
					--bottom
					v.OutlineColor(.6)
					for i=0, t-1 do
						rect(true, 0, h/2-i,w-i*2,1, 0)
					end
					--left
					v.OutlineColor(.85)
					for i=0, t-1 do
						rect(true, -w/2+i, 0,1,h-i*2, 0)
					end
					--right
					v.OutlineColor(.65)
					for i=0, t-1 do
						rect(true, w/2-i, 0,1,h-i*2, 0)
					end

					love.graphics.pop()
				elseif v.OutlineStyle == "Glass" then
					rect(true, x,y, w,h,r)
					love.graphics.push()
					love.graphics.translate(x,y)
					love.graphics.rotate(r)
					local t = v.OutlineThickness
					v.OutlineColor(.5)
					rect(true, w/2-t/2, 0, t,h,0)
					v.OutlineColor(.5)
					rect(true, 0, h/2-t/2, w,t,0)
					v.OutlineColor(.9)
					rect(true, -w/2+t/2, 0, t,h,0)
					v.OutlineColor(.9)
					rect(true, 0, -h/2+t/2, w,t,0)

					love.graphics.pop()
				elseif v.OutlineStyle == "Fade" then
					local t = v.OutlineThickness*4-1
					rect(true, x, y, w-v.OutlineThickness,h-v.OutlineThickness,r)
					for i=0,t do
						local p = i/t
						--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
						v.OutlineColor(1,1-p)
						rect(false, x,y, w-i+(i*.5),h-i+(i*.5), r)
					end
				else
					rect(true, x,y, w,h,r)
				end
			elseif v.Shape == "Circle" then
				if v.OutlineStyle == "Fade" then
					local t = v.OutlineThickness
					love.graphics.circle("fill", x, y, w/2-v.OutlineThickness)
					for i=0,t do
						local p = i/t
						--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
						v.OutlineColor(1,1-p)
						love.graphics.circle("line", x,y, w/2-(i))
					end
				else
					love.graphics.circle("fill", x,y,w/2)
				end
			elseif v.Shape == "Wedge" then
				local cf, size = v.CFrame, v.Size
				local topLeft = cf * CFrame.new(-size.X/2, -size.Y/2)
				local bottomLeft = cf * CFrame.new(-size.X/2, size.Y/2)
				local bottomRight = cf * CFrame.new(size.X/2, size.Y/2)
				-- tri(1, topLeft.X * STUDSIZE, topLeft.Y * STUDSIZE, bottomLeft.X * STUDSIZE, bottomLeft.Y * STUDSIZE, bottomRight.X * STUDSIZE, bottomRight.Y * STUDSIZE)
				tri(1, topLeft.X, topLeft.Y, bottomLeft.X, bottomLeft.Y, bottomRight.X, bottomRight.Y)
			end
			
			v.TextColor()
			love.graphics.setLineWidth(v.TextThickness)
			text(v.Text, x,y, v.TextSize)
			love.graphics.setLineWidth(1)
			if v._decal then
				image(v._decal, v.CFrame, v.Size)
			end
			
			love.graphics.pop()
		end
	end
end

function module:getPoints()
	local cf = self.CFrame
	local w,h = self.Size()
	local points = {}
	
	w,h = w/2,h/2

	if self.Shape == "Rectangle" then
		local topLeft = cf * CFrame.new(-w, -h)
		local topRight = cf * CFrame.new(w, -h)
		local bottomLeft = cf * CFrame.new(-w, h)
		local bottomRight = cf * CFrame.new(w, h)
		points[#points+1] = topLeft.Position
		points[#points+1] = topRight.Position
		points[#points+1] = bottomRight.Position
		points[#points+1] = bottomLeft.Position
	elseif self.Shape == "Circle" then
		local sides = Instance.CircleSegments
		local radius = self.Size.X/2

		for i = 1, sides do
			points[#points+1] = (self.CFrame * CFrame.Angles(i/sides * math.pi*2) * CFrame.new(0, radius)).Position
		end
	end

	return points
end

function module:getSurfaces()
	local points = self:getPoints()
	local boundaries = {}
	for i=1, #points do
		local this,next = i, (i % #points) + 1
		local p1,p2 = points[this], points[next]
		boundaries[#boundaries+1] = {a = p1, b = p2}
	end
	return boundaries
end

function module:colliding(pos, other)
	local regionMin = other.Position - other.Size/2 - self.Size/2
	local regionMax = other.Position + other.Size/2 + self.Size/2
	return pos > regionMin and pos < regionMax
end
	
UserInput.InputEnded:Connect(function(input)
	if input.Mouse == Enum.Mouse.LeftMouseButton then
		clickedButton = nil
	end
end)
UserInput.InputBegan:Connect(function(input)
		for i,v in pairs(parts) do
			if v.Clickable then
				local rmx,rmy = love.mouse.position()()
				local mx,my = love.mouse.getPosition()
				local x,y = v.Position()
				local w,h = v.Size()
				local inside = within(rmx,rmy, x,y, w,h)
				if inside then
					if not clickedButton then
						clickedButton = true
						if input.Mouse == Enum.Mouse.LeftMouseButton then
							v.Activated:Run()
						end
						v.InputBegan:Run(input)
					end
				end
			end
		end
end)

updateSignal:Connect(updateParts)
drawSignal:Connect(drawParts)

return module