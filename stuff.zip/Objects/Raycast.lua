local module = {}
module.__index = module

local rays = {}
local serial = 0

module.type = "Raycast"

module.new = function(cf, length, ignoreList, whiteList, showUp)
	local ray = {
		CFrame = cf,
		Length = length or 100,
		_ignore = ignoreList or {},
		_whitelist = whiteList,
	}
	
	if showUp then
		local id = serial+1
		serial = serial + 1
		ray.id = id
		rays[id] = ray
	end

	return setmetatable(ray, module)
end

local cast = function(ray, wall) -- self, {a = Vector, b = Vector}
	local x1, y1 = wall.a()
	local x2, y2 = wall.b()

	local x3, y3 = ray.CFrame.Position()
	local x4, y4 = (ray.CFrame + (ray.CFrame.LookVector.Unit) * ray.Length).Position()

	local den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
	if den == 0 then
		return
	end
	local t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
	local u =-((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den
	
	if t > 0 and t < 1 and u > 0 then
		return Vector.new(
			x1 + t * (x2 - x1),
			y1 + t * (y2 - y1)
		)
	end
end

function module:cast()
	local instance, position, normal
	for id, part in pairs(Instance.Parts) do
		if self._whitelist and mathf.find(self._whitelist, part) or not self._whitelist and not mathf.find(self._ignore or {}, part) and part.CanCollide then
			local boundaries = part:getSurfaces()

			for i,v in pairs(boundaries) do
				local pos = cast(self, v) 
				if pos then
					local distToPos = (pos - self.CFrame.Position).Magnitude
					local distToClosest = position and (position - self.CFrame.Position).Magnitude
					if distToPos <= self.Length then
						if position and distToPos < distToClosest or not position then
							instance, position, normal = part, pos, CFrame.lookAt(v.b, v.a).RightVector
						end
					end
				end
			end
		end
	end
	return instance, position, normal
end

drawRays = function()
	love.graphics.setColor(255,255,255)
	for i,v in pairs(rays) do
		local ox,oy = v.CFrame()
		local dx,dy = (v.CFrame + v.CFrame.LookVector * v.Length)()
		love.graphics.line(ox, oy, dx, dy)
	end
end

return module