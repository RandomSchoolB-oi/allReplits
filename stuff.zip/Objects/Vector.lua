local module = {}
module.__index = module

function module.new(x,y,isUnit)
	local Vector = {
		X = x or 0,
		Y = y or 0,
	}
	Vector.Magnitude = math.sqrt(Vector.X^2 + Vector.Y^2)
	if not isUnit then
		-- Vector.Unit = module.new(-Vector.X/Vector.Magnitude, -Vector.Y/Vector.Magnitude, true)
	
		local r = math.atan2(0 - Vector.Y, 0 - Vector.X)
		local x,y = math.cos(r), math.sin(r)
		Vector.Unit = module.new(-x, -y, true)
	end
	return setmetatable(Vector, module)
end

function module:cross(other)
	return self.X * other.Y + self.Y * other.X
end

function module:reflect(normal)
	return self - (normal * self:dot(normal) * 2)
	-- local r1 = math.atan2(-self.Y, -self.X)
	-- local r2 = math.atan2(-normal.Y, -normal.X)
	-- local r3 = r2 - r1
	-- local r4 = -(r1 + r3)
	-- local x,y = math.cos(r4), math.sin(r4)
	-- local reflected = module.new(x,y) * self.Magnitude
	-- return reflected
end

function module:dot(other)
	return self.X * other.X + self.Y * other.Y--math.atan2(math.abs(cross), dot)
end

function module:angleBetween(normal)
	return math.acos(mathf.clamp(-self.Unit:dot(normal), -1, 1))
end

function module.__unm(self)
	return module.new(-self.X, -self.Y)
end

function module.__mul(self, other)
	if type(other) == "number" then
		return module.new(self.X * other, self.Y * other)
	else
		return module.new(self.X * other.X, self.Y * other.Y)
	end
end
function module.__mod(self, other)
	if type(other) == "number" then
		return module.new(self.X % other, self.Y % other)
	else
		return module.new(self.X % other.X, self.Y % other.Y)
	end
end
function module.__div(self, other)
	if type(other) == "number" then
		return module.new(self.X / other, self.Y / other)
	else
		return module.new(self.X / other.X, self.Y / other.Y)
	end
end

function module.__add(self, other)
	return module.new(self.X + other.X, self.Y + other.Y)
end
function module.__sub(self, other)
	return module.new(self.X - other.X, self.Y - other.Y)
end

function module.__eq(self, other)
	return self.X == other.X and self.Y == other.Y
end
function module.__lt(self, other)
	return self.X < other.X and self.Y < other.Y
end
function module.__le(self, other)
	return self.X <= other.X and self.Y <= other.Y
end


function module:change(new)
	self.X = new.X
	self.Y = new.Y
	self.Magnitude = new.Magnitude
end

function module:add(other)
	self:change(self + other)
end
function module:sub(other)
	self:change(self - other)
end
function module:mul(other)
	self:change(self * other)
end
function module:div(other)
	self:change(self / other)
end
function module:mod(other)
	self:change(self % other)
end

function module:Lerp(to, alpha)
	return module.new(
		lerp(self.X, to.X, alpha),
		lerp(self.Y, to.Y, alpha)
	)
end

function module.__call(self)
	return self.X, self.Y
end

function module.__tostring(self)
	return tostring(self.X)..", "..tostring(self.Y)
end

function module:setMagnitude(magnitude)
	magnitude = magnitude or 1
	self.X = self.Unit.X * magnitude
	self.Y = self.Unit.Y * magnitude
	self.Unit = self.Unit * mathf.sign(magnitude)
	self.Magnitude = magnitude
end

module.type = "Vector"

module.one = module.new(1,1)
module.zero = module.new(0,0)
module.xAxis = module.new(1,0)
module.yAxis = module.new(0,1)

return module