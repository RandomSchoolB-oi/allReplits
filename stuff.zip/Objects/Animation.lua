local module = {}
module.__index = module

module.new = function()
	local animation = setmetatable({
		frames = {},
		fps = 1,	
	}, module)

	updateSignal:Connect(function(dt)
		local frame = animation:_currentFrame()
		if animation.frames[frame] then
			animation.Decal = animation.frames[frame].Decal
		end
	end)
		
	return animation
end

function module:addFrame(imageName)
	self.frames[#self.frames+1] = {
		Decal = love.graphics.newImage("Images/"..imageName),
	}
end

function module:_currentFrame()
	local tim = tick()
	local fps = self.fps
	local timeStep = 1/fps

	local val = ((tim - (tim % timeStep)) / timeStep) % #self.frames + 1
	val = math.floor(val + .5)
	--if val > 2 or val < 1 then
		print(val)
	--end
		
	return val
end

return module