local module = {}
local twopi = math.pi * 2

local letterWidth, letterHeight = 6, 14
local spacing = 6

local line = love.graphics.line

local letters = {
	A = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		line(x - lw/2, y + lh/2, x, y - lh/2)
		line(x + lw/2, y + lh/2, x, y - lh/2)
		line(x-lw/4,y, x+lw/4,y)
	end,
	B = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x+lw/2, y+lh/2, x+lw/2, y+d)
		line(x+lw/2, y-lh/2, x+lw/2, y-d)
		line(x+lw/2-d, y, x+lw/2, y+d)
		line(x+lw/2-d, y, x+lw/2, y-d)
		line(x-lw/2, y, x+lw/2-d, y)
	end,
	C = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
	end,
	D = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2-d, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2-d, y+lh/2)
		line(x+lw/2, y+lh/2-d, x+lw/2, y-lh/2+d)
		line(x+lw/2-d, y-lh/2, x+lw/2, y-lh/2+d)
		line(x+lw/2-d, y+lh/2, x+lw/2, y+lh/2-d)
	end,
	E = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y, x+lw/2-d, y)
	end,
	F = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2-d, y)
	end,
	G = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x+lw/2, y+lh/2, x+lw/2, y+d)
		line(x, y+d, x+lw/2, y+d)
	end,
	H = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y, x+lw/2, y)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
	end,
	I = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x, y-lh/2, x, y+lh/2)
	end,
	J = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x, y+lh/2)
		line(x, y-lh/2, x, y+lh/2)
		line(x-lw/2, y+lh/2, x-lw/2, y+lh/2-d)
	end,
	K = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2, y+lh/2)
	end,
	L = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
	end,
	M = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x, y-lh/2, x, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
	end,
	N = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y+lh/2)
	end,
	O = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
	end,
	P = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2, y)
		line(x+lw/2, y-lh/2, x+lw/2, y)
	end,
	Q = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x, y+lh/2 - d, x+d, y+lh/2+d)
	end,
	R = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2, y)
		line(x+lw/2, y-lh/2, x+lw/2, y)
		line(x-lw/2, y, x+lw/2, y+lh/2)
	end,
	S = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y)
		line(x+lw/2, y+lh/2, x+lw/2, y)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y, x+lw/2, y)
	end,
	T = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x, y-lh/2, x, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
	end,
	U = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
	end,
	V = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x, y+lh/2)
		line(x+lw/2, y-lh/2, x, y+lh/2)
	end,
	W = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x, y-lh/2, x, y+lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
	end,
	X = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x-lw/2, y+lh/2)
	end,
	Y = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x, y)
		line(x+lw/2, y-lh/2, x, y)
		line(x, y, x, y+lh/2)
	end,
	Z = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y-lh/2)
	end,
	["1"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x, y-lh/2, x-lw/2, y-lh/2+d)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x, y-lh/2, x, y+lh/2)
	end,
	["2"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-d, x-lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y)
	end,
	["3"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x+lw/2, y+lh/2, x+lw/2, y+d)
		line(x+lw/2, y-lh/2, x+lw/2, y-d)
		line(x+lw/2-d, y, x+lw/2, y+d)
		line(x+lw/2-d, y, x+lw/2, y-d)
		line(x-lw/2+d, y, x+lw/2-d, y)
	end,
	["4"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		--line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2, y)
		line(x-lw/2, y-lh/2, x-lw/2, y)
	end,
	["5"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y-d)
		line(x+lw/2, y+lh/2, x+lw/2, y-d)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-d, x+lw/2, y-d)
	end,
	["6"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y)
		line(x+lw/2, y+lh/2, x+lw/2, y)
		line(x-lw/2, y+lh/2, x-lw/2, y)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y, x+lw/2, y)
	end,
	["7"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x+lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
	end,
	["8"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		--line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x+lw/2, y+lh/2, x+lw/2, y+d)
		line(x+lw/2, y-lh/2, x+lw/2, y-d)
		line(x-lw/2, y+lh/2, x-lw/2, y+d)
		line(x-lw/2, y-lh/2, x-lw/2, y-d)
		line(x+lw/2-d, y, x+lw/2, y+d)
		line(x+lw/2-d, y, x+lw/2, y-d)
		line(x-lw/2+d, y, x-lw/2, y+d)
		line(x-lw/2+d, y, x-lw/2, y-d)
		line(x-lw/2+d, y, x+lw/2-d, y)
	end,
	["9"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y, x+lw/2, y)
		line(x-lw/2, y-lh/2, x-lw/2, y)
	end,
	["0"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y-lh/2, x-lw/2, y+lh/2)
		line(x+lw/2, y-lh/2, x+lw/2, y+lh/2)
		line(x-lw/2, y-lh/2, x+lw/2, y-lh/2)
		line(x-lw/2, y+lh/2, x+lw/2, y+lh/2)
		line(x, y-d, x, y+d)
	end,
	[" "] = function(x,y,s)

	end,
	["/"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-lw/2, y+lh/2, x+lw/2, y-lh/2)
	end,
	["-"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-d, y, x+d, y)
	end,
	[":"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = love.graphics.getLineWidth() * s * 3
		love.graphics.circle("fill", x,y - lh / 2 + d, d/2)
		love.graphics.circle("fill", x,y + lh / 2 - d, d/2)
	end,
	["+"] = function(x,y,s)
		local lh,lw = letterHeight * s, letterWidth * s
		local d = 3 * s
		line(x-d, y, x+d, y)
		line(x, y-d, x, y+d)
	end,
}

letter = function(char, x,y,scale)
	if letters[char:upper()] then
		letters[char:upper()](x,y,scale)
	end
end

text = function(letters, x,y,scale, allignment)
	letters = tostring(letters)
	local X
	if not allignment or allignment == "m" then
		X = x - ((letters:len() + 1) * letterWidth * scale)
	elseif allignment == "l" then
		X = x + lw/2
	elseif allignment == "r" then
		X = x - ((letters:len() + 1) * letterWidth * scale)*2
	end
	
	for i,v in pairs(split(letters:gsub("","|"),"|")) do
		letter(v, X + i * (letterWidth+spacing) * scale, y, scale)
	end
end

local customImage = function(icon, cf, size)
	local x,y,r = cf()
	local w,h = size()
	local iw, ih = #icon, #icon[1]
	local pw, ph = w/iw, h/ih
		
	love.graphics.push()
	love.graphics.translate(x,y)
	love.graphics.rotate(r)
	for _x,collumn in pairs(icon) do
		for _y,data in pairs(collumn) do
			local x,y = _x - 1, _y - 1
			data.Color(1, data.Transparency)
			love.graphics.rectangle("fill", x*pw - (iw*pw)/2, y*ph - (iw*ph)/2, pw,ph)
		end
	end
	love.graphics.pop()
end
	
image = function(icon, cf, size)
	if type(icon) == "table" then
		customImage(icon, cf, size)
		return
	end
	local x,y,r = cf()
	
	local ow,oh = icon:getDimensions()
	local w,h = size()
	local sx,sy = sign(w), sign(h)

	local xoff, yoff = w/2 * -sx + w * mathf.clamp(sx, -1, 0), h/2 * -sy + h * mathf.clamp(sy, -1, 0)


	love.graphics.push()
	love.graphics.translate(x,y)
	love.graphics.rotate(r)
	love.graphics.draw(icon, xoff, yoff,0, w/ow, h/oh)
	love.graphics.pop()
end

rect = function(fill, x,y,w,h,r)
	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(r or 0)
	love.graphics.rectangle(fill and "fill" or "line", -w/2,-h/2, w,h)
	love.graphics.pop()
end

rectCF = function(fill, cf, size)
	local x,y,r = cf()
	local w,h = size()
	rect(fill, x,y,w,h,r)
end

ellipse = function(fill, x,y,w,h,r)
	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(r or 0)
	love.graphics.ellipse(fill and "fill" or "line", 0,0,w/2,h/2)
	love.graphics.pop()
end

line = function(x1,y1,x2,y2)
	love.graphics.line(x1,y1,x2,y2)
end

lineVec = function(p1,p2)
	local x1,y1 = p1()
	local x2,y2 = p2()
	line(x1,y1,x2,y2)
end

tri = function(fill, x1,y1, x2,y2, x3,y3)
	love.graphics.polygon(fill and 'fill' or 'line', x1,y1, x2,y2, x3,y3)
end

triVec = function(fill, p1,p2,p3)
	local x1,y1 = p1()
	local x2,y2 = p2()
	local x3,y3 = p3()
	tri(fill, x1,y1, x2,y2, x3,y3)
end

lineCircle = function(x,y,r,degs)
	for i=1,degs do
		local rot = (i/degs) *  math.pi *2
		local cf = CFrame.new(x,y,rot)
		local cx,cy = (cf * r)()
		love.graphics.line(x,y,cx,cy)
	end
end

drawShape = function(fill, x,y,r, sideCount, radius)
	local lastPoint
	for i = 0, sideCount do
		local point = CFrame.new(x,y,r + twopi*(i/sideCount))* CFrame.new(0, radius)

		if lastPoint then
			if not fill then
				love.graphics.line(lastPoint.X, lastPoint.Y, point.X, point.Y)
			else
				tri(1, lastPoint.X, lastPoint.Y, point.X, point.Y, x, y)
			end
		end
		lastPoint = point
	end
end

drawPolygon = function(fill, points)
	local coords = {}
	for i,v in pairs(points) do
		coords[#coords+1] = v.X
		coords[#coords+1] = v.Y
	end

	love.graphics.polygon(fill and fill ~= 0 and "fill" or "line", unpack(coords))
end

module.rect = rect
module.ellipse = ellipse
module.line = line
module.tri = tri
module.lineCircle = lineCircle

return module