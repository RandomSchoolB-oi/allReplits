local module = {}

-- newThread = function(callback)
-- 	return coroutine.wrap(callback)
-- end

-- wait = function(time)
-- 	time = time or 0
-- 	local started = os.clock()
-- 	repeat until os.clock() - started >= time
-- 	return os.clock() - started
-- end


-- delay = function(time, callback)
-- 	return newThread(function(...)
-- 		wait(time)
-- 		callback(...)
-- 	end)
-- end

-- module.new = newThread
-- module.wait = wait
-- module.delay = delay

-- return module

return function(updateSignal)
	local waitingThreads = {}
	delay = function(time, callback)
		waitingThreads[#waitingThreads+1] = {timeLeft = time, callback = callback}
	end
	
	updateSignal:Connect(function(dt)
		for i,v in mathf.iipairs(waitingThreads) do
			v.timeLeft = v.timeLeft - dt
			if v.timeLeft <= 0 then
				v.callback()
				table.remove(waitingThreads, i)
			end
		end
	end)
end