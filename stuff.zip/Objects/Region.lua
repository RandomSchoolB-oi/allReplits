local module = {}
module.__index = module

local regions = {}
local serial = 0

module.new = function(min, max, ignoreList)
	assert(min, "has to have a minimum value")
	assert(max, "has to have a maximum value")
	assert(min < max, "the minimum has to be less than the maximum")
	local region = setmetatable({
		_min = min,
		_max = max,
		_ignore = ignoreList or {},
	}, module)
	local id = serial
	serial = serial + 1
	region.id = id
	regions[id] = region
	return region
end

function module:getParts(touching)
	local parts = {}
	for i,v in pairs(Instance.Parts) do
		if not mathf.find(self._ignore, v) then
			local pos = v.Position
			local size = v.Size
			local topLeft = pos - size/2
			local bottomRight = pos + size/2

			local condition = topLeft > self._min and bottomRight < self._max
			if touching then
				condition = 
				topLeft     >= (self._min - size) and 
				bottomRight <= (self._max + size)
			end
			if condition then
				parts[#parts+1] = v
			end
		end
	end
	return parts
end

function module:Destroy()
	regions[self.id] = nil
	for i,v in pairs(self) do
		if i ~= "id" then
			self[i] = nil
		end
	end
end

drawSignal:Connect(function()
	for i,v in pairs(regions) do
		love.graphics.setColor(255,255,255,150)
		local x1,y1 = v._min()
		local x2,y2 = v._max()
		love.graphics.rectangle("fill", x1, y1, x2-x1, y2-y1)
	end
end)

return module