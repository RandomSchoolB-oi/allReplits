return {
	width = {20, 30},
	height = {10, 15},

	branchLength = {15, 20},

	maxSplits = {7, 10},
	splitQuantity = {1, 1},
	splitAngle = {-7,7},
	splitOffset = {-7,7},
	widthDegeneration = 1.5,
	palette = {
		Bark = {
			Color = Color3.new(255, 215, 100),
			OutlineStyle = false,
		},
		Leaves = {
			Color = {
				Color3.new(0, 200, 10),
				Color3.new(0, 165, 10),
				Color3.new(0, 150, 10),
			},
			OutlineStyle = false,	
		},
	},
	
	leafAngle = {-45,45},
	leafQuantity = {3,4},
	leafWidth = {100, 125},
	leafHeight = {10, 25},

	growSpeed = 50,
}