return {
	width = {5, 8},
	height = {60, 150},

	branchLength = {40, 90},

	maxSplits = {2, 2},
	splitQuantity = {2, 3},
	splitAngle = {10, 20},
	splitOffset = {-10,10},
	widthDegeneration = 1,
	palette = {
		Bark = {
			Color = Color3.new(255, 215, 200),
			OutlineStyle = false,
		},
		Leaves = {
			Color = {
				Color3.new(0, 200, 10),
				Color3.new(0, 165, 10),
				Color3.new(0, 150, 10),
			},
			OutlineStyle = false,	
		},
	},
	
	leafAngle = {-15,15},
	leafQuantity = {1,2},
	leafWidth = {30, 45},
	leafHeight = {30, 45},

	growSpeed = 2,
}