return {
	width = {8, 12},
	height = {60, 100},

	branchLength = {50, 75},

	maxSplits = {1, 2},
	splitQuantity = {2, 3},
	splitAngle = {25, 60},
	splitOffset = {-20,20},
	widthDegeneration = 2,
	palette = {
		Bark = {
			Color = Color3.new(150, 75, 25),
			OutlineStyle = false,
		},
		Leaves = {
			Color = {
				Color3.new(0, 200, 10),
				Color3.new(0, 165, 10),
				Color3.new(0, 150, 10),
				Color3.new(0, 100, 10),
			},
			OutlineStyle = false,	
		},
	},
	
	leafAngle = {-25,25},
	leafQuantity = {1,2},
	leafWidth = {75, 125},
	leafHeight = {30, 75},

	growSpeed = 2,
}