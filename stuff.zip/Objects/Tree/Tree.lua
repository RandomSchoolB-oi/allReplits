local module = {}
module.__index = module

treeData = setmetatable({},{
	__index = function(_, index)
		return require("Objects.Tree.Types."..index)
	end,
})

local BranchClass = require("Objects.Tree.Branch")

local randomRange = function(range, decimal)
	decimal = decimal or 1
	return math.random(range[1] * decimal, range[2] * decimal) / decimal
end

local getDepth = function(branch)
	local depth, parent = 0, branch
	repeat
		depth = depth + 1
		parent = parent.Parent
	until not parent
	return depth-1
end

recurseGrow = function(branch, dt, maxSplits)
	if branch.Growing then
		local noMoreSplits = getDepth(branch) >= maxSplits
		branch:Grow(dt, noMoreSplits)
	else
		for i,v in pairs(branch.Branches) do
			recurseGrow(v, dt, maxSplits)
		end
	end
end

function module:Grow(dt)
	if self.Growing then
		recurseGrow(self.Trunk, dt, self.MaxSplits)
	end
end

module.new = function(cf, treeType)
	treeType = treeData[treeType] and treeType or "Oak"
	local tree = setmetatable({
		Style = treeType,
		Growing = true,
		Trunk = BranchClass.new(cf, treeType, randomRange(treeData[treeType].width)),
		MaxSplits = randomRange(treeData[treeType].maxSplits),
	}, module)
	return tree
end

function module:Destroy()
	self.Growing = false
	self.Trunk:Destroy()
end

return module