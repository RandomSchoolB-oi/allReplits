local module = {}
module.__index = module

local randomRange = function(range, decimal)
	decimal = decimal or 1
	return math.random(range[1] * decimal, range[2] * decimal) / decimal
end

local newPart = function(palette)
	local part = Instance.new("Part")
	for i,v in pairs(palette or {}) do
		local value = v
		if type(v) == "table" and v[1] then
			value = v[math.random(1, #v)]
		end
		part[i] = value
	end
	return part
end

local getDepth = function(branch)
	local depth, parent = 0, branch
	repeat
		depth = depth + 1
		parent = parent.Parent
	until not parent
	return depth-1
end

function module:Grow(dt, nosplit)
	local data = treeData[self.Style]

	if self.Growing then
		if self.Length >= self.MaxLength then
			self.Growing = false
			if not nosplit then
				local angle = randomRange(data.splitAngle)
				local offset = randomRange(data.splitOffset)
				local quantity = randomRange(data.splitQuantity)

				for i = 1, quantity do
					local rot = mathf.Lerp(-angle, angle, i/quantity)
					local cf = self.CFrame * CFrame.new(0, -self.Length) * 
					CFrame.Angles(math.rad(offset + rot))
					local branch = module.new(cf, self.Style, self.Width)
					branch.Parent = self
					self.Branches[#self.Branches+1] = branch
				end
				for i,v in pairs(self.Leaves) do
					v.Part:Destroy()
				end
				self.Leaves = {}
			end
		else
			self.Length = mathf.clamp(self.Length + dt * data.growSpeed, 0, self.MaxLength)
			self:Draw()
		end
	end
end

function module:Draw()
	local length, cf = self.Length, self.CFrame
	local depth = getDepth(self)
	self.Part.CFrame = cf * CFrame.new(0, -length/2)
	self.Part.Size = Vector.new(self.Width - depth * treeData[self.Style].widthDegeneration,length)
	for i,v in pairs(self.Leaves) do
		v.Part.Size = v.Size
		v.Part.CFrame = self.CFrame * CFrame.new(0, -self.Length) * v.Offset
	end
end

module.new = function(cf, treeType, width)
	treeType = treeData[treeType] and treeType or "Oak"
	local data = treeData[treeType]
	local branch = setmetatable({
		Style = treeType,
		CFrame = cf,
		Length = 0,
		MaxLength = randomRange(data.branchLength),
		Branches = {},
		Leaves = {},
		Growing = true,
		Part = newPart(data.palette.Bark),
		Width = width,
	}, module)

	for i=1, randomRange(data.leafQuantity) do
		local part = newPart(data.palette.Leaves)
		local w,h,a = randomRange(data.leafWidth), randomRange(data.leafHeight), randomRange(data.leafAngle)
		local leaf = {
			Part = part, 
			Offset = CFrame.new(0, -h/3, math.rad(a)),
			Size = Vector.new(w,h),
		}
		branch.Leaves[#branch.Leaves+1] = leaf
	end

	branch:Draw()
	return branch
end

function module:Destroy()
	self.Part:Destroy()
	for i,v in pairs(self.Leaves) do
		v.Part:Destroy()
	end
	for i,v in pairs(self.Branches) do
		v:Destroy()
	end
end

return module