local module = {}
module.__index = module

local controllers = {}
local serial = 0

module.new = function()
	local controller = {}

	controller._backdrop = Instance.new("Part")
	controller.buttonA = Instance.new("Part")
	controller.buttonB = Instance.new("Part")
	controller.buttonX = Instance.new("Part")
	controller.buttonY = Instance.new("Part")

	controller.leftJoystick = GuiObjects.Joystick.new()
	controller.rightJoystick = GuiObjects.Joystick.new()

	controller.Position = Vector.new(0, 0)
	controller.Size = Vector.new(300, 100)

	local id = serial
	serial = serial + 1
	controller.id = id
	controllers[id] = controller

	return setmetatable(controller, module)
end

function module:Destroy()
	if self.id then
		controllers[self.id] = nil
	end
	for i,v in pairs(self) do
		if type(v) == "table" and v.Destroy then
			v:Destroy()
		end
		self[i] = nil
	end
end

local updateGamepads = function(dt)
	for id, self in pairs(controllers) do

		local origin = self.Position
		local buttonOrigin = origin-- + Vector.new(25, 0)

		local backdrop = self._backdrop

		local a = self.buttonA
		local b = self.buttonB

		local x = self.buttonX
		local y = self.buttonY

		local joystick1 = self.rightJoystick
		local joystick2 = self.leftJoystick

		local w,h = backdrop.Size()

		local buttonSize =  Vector.new(w/10, h * 0.3)

		a.Position = buttonOrigin + Vector.new(0, h*.25)
		a.OutlineStyle = nil
		a.Color = Color3.new(50,200,25)
		a.Shape = "Circle"
		a.Clickable = true
		a.Size = buttonSize

		b.Position = buttonOrigin + Vector.new(w/12, 0)
		b.OutlineStyle = nil
		b.Color = Color3.new(255,25,25)
		b.Shape = "Circle"
		b.Clickable = true
		b.Size = buttonSize


		x.Position = buttonOrigin + Vector.new(-w/12, 0)
		x.OutlineStyle = nil
		x.Color = Color3.new(25,25,255)
		x.Shape = "Circle"
		x.Clickable = true
		x.Size = buttonSize

		y.Position = buttonOrigin + Vector.new(0, -h*.25)
		y.OutlineStyle = nil
		y.Color = Color3.new(255,255,0)
		y.Shape = "Circle"
		y.Clickable = true
		y.Size = buttonSize


		joystick1.origin = origin + Vector.new(w/3, 0)
		joystick1.radius = h*.2
		joystick1.maxDragDistance = mathf.clamp(h/2, 0, w/6)

		joystick2.origin = origin + Vector.new(-w/3, 0)
		joystick2.radius = h*.2
		joystick2.maxDragDistance = mathf.clamp(h/2, 0, w/6)

		backdrop.Position = origin
		backdrop.Size = self.Size
		backdrop.Color = Color3.new(100,100,100)
	end
end

updateSignal:Connect(updateGamepads)


return module