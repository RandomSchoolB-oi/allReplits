local module = {}
module.__index = module

module.new = function()
	return setmetatable({
		Position = Vector.new(0, 0),
		CellPadding = Vector.new(6, 6),
		Allignment = "Middle",
	}, module)
end

function module:allign(frames)
	local max = self.MaxCellCount
	local pos, padding = self.Position, self.CellPadding
	local biggestFrame
	local y = -frames[1].Size.Y/2-padding.Y

	for i, v in pairs(frames) do
		if biggestFrame and v.Size.X > biggestFrame.Size.X or not biggestFrame then
			biggestFrame = v
		end
	end

	local x
	if self.Allignment == "Middle" then
		x = 0
	elseif self.Allignment == "Left" then
		x = -biggestFrame.Size.X/2
	elseif self.Allignment == "Right" then
		x = biggestFrame.Size.X/2
	end

	for index, v in pairs(frames) do
		local i = index - 1
		y = y + v.Size.X + padding.Y
		v.Position = pos + Vector.new(x, y)
	end
	return {
		CellCount = #frames,
		AbsoluteSize = Vector.new(biggestFrame.Size.X, y-padding.Y),
		AbsolutePosition = Vector.new(pos.X + x - biggestFrame.Size.X/2, pos.Y),	
	}
end

return module