local resolution = 100
local w,h = 350, 200
local module
module = {
	Enabled = false,
	init = function()

		local dragging
		local cx,cy = 0, 0
		local color = Color3.new(255, 255, 255)

		module.getColor = function()
			return color
		end
			
		local textColor = function()
			local r,g,b = math.floor(color.R+.5), math.floor(color.G+.5), math.floor(color.B+.5)
			return r..", "..b..", "..b
		end

		local slider = GuiObjects.Slider.new(0, 1, 0.01, h)
		slider.axis = "Y"
		slider.Position = Vector.new(w/2 + 15, -h/2)

		local clickDetector = Instance.new("Part")
		clickDetector.Clickable = true
		clickDetector.Size = Vector.new(w,h) + Vector.new(w/resolution, h/resolution)
		clickDetector.Position = Vector.new(w/resolution, h/resolution)
		clickDetector.Transparency = 1
		clickDetector.Activated:Connect(function()
			if module.Enabled then
				dragging = true
			end
		end)

		local saveButton = Instance.new("Part")
		saveButton.Clickable = true
		saveButton.Size = Vector.new(40, 20)
		saveButton.Position = Vector.new(-30, -h/2 - 10)
		saveButton.Activated:Connect(function()
			if module.Enabled then
				print("Color3.new("..textColor()..")")
			end
		end)

		local dragger = Instance.new("Part")
		dragger.Clickable = true
		dragger.Size = Vector.new(20,20)
		-- dragger.Activated:Connect(function()
		-- 	dragging = true
		-- end)

		UserInput.InputEnded:Connect(function(input)
			if input.Mouse == Enum.Mouse.LeftMouseButton then
				dragging = false
			end
		end)

		local calcColor = function(x,y, fromMouse)
			if fromMouse then
				x = x + w/2
				y = y + h/2
			end
			local hue = (1.425-(x/(w/1.425))) * 255
			local saturation = 1-(y/h)
			local value = 1 - slider.value
			return hue, saturation, value
		end

		slider.Moved:Connect(function(value)
			local hue,sat,val = calcColor(cx, cy, true)
			color = Color3.newHSV(hue, sat,val)
		end)

		updateSignal:Connect(function(dt)
			slider.Enabled = module.Enabled
			dragger.Visible = module.Enabled
			saveButton.Visible = module.Enabled
			clickDetector.Visible = module.Enabled
			if dragging and module.Enabled then
				local x,y = love.mouse.position()()
				cx,cy = mathf.clamp(x, -w/2, w/2), mathf.clamp(y, -h/2, h/2)
				dragger.Position = Vector.new(cx,cy)
				color = Color3.newHSV(calcColor(cx, cy, true))
			--color = Color3.newHSV(hue, sat,val)
			end
		end)
		drawSignal:Connect(function()
			if module.Enabled then
				local px,py = w/resolution, h/resolution
				love.graphics.print(textColor(), 0, -h/2 - 15)
				for x = 0, w, px do
					for y = 0, h, py do
						love.graphics.setColor(hsv(calcColor(x,y)))
						love.graphics.rectangle("fill", x- w/2, y - h/2, px, py)
					end
				end
				color()
				rect(1, 0, -h/2 - 30, 20, 20)
			end
		end, 0)
	end,
}



return module