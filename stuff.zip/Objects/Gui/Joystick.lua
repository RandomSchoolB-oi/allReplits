local module = {}
module.__index = module

local sticks = {}
local serial = 0

module.new = function()
	local joystick = {
		origin = Vector.new(0, 0),
		radius = 50,
		maxDragDistance = 100,
		Moved = Signal.new(),
		dragging = false,
		_stick = Instance.new("Part"),
	}
	joystick._stick.Shape = "Circle"
	joystick._stick.Clickable = true
	joystick._stick.Color = Color3.new(200, 200, 200)
	joystick._stick.Activated:Connect(function()
		joystick._offset = love.mouse.position() - joystick.origin
		joystick.dragging = true
	end)
	local id = serial
	serial = serial + 1
	joystick.id = id
	sticks[id] = joystick
	return setmetatable(joystick, module)
end

function module:Destroy()
	if self.id then
		sticks[self.id] = nil
	end
	for i,v in pairs(self) do
		if i == "_stick" then
			v:Destroy()
		end
		self[i] = nil
	end
end

UserInput.InputEnded:Connect(function(input)
	if input.Mouse == Enum.Mouse.LeftMouseButton then
		for i,v in pairs(sticks) do
			v.dragging = false
		end
	end
end)

local updateJoysticks = function(dt)
	for id, self in pairs(sticks) do
		local joystick = self._stick
		if self.dragging then
			local maxDist = self.maxDragDistance
			local toPos = love.mouse.position() --+ (self._offset or Vector.new(0, 0))
			--toPos = toPos - toPos%100
			local normalized = toPos - self.origin

			local dist = mathf.clamp(normalized.Magnitude, 0, maxDist)
			local unit = normalized.Unit


			joystick.Position = self.origin + unit * dist
			
			self.Moved:Run(unit * (dist/maxDist) * dt)
		else
			joystick.Position = self.origin
		end
	end
end

local drawJoysticks = function()
	for id, self in pairs(sticks) do
		local color = self._stick.Color
		local ox, oy = self.origin()
		local mdd = self.maxDragDistance

		love.graphics.setColor(color.R, color.G, color.B, 50)
		love.graphics.circle("fill", ox, oy, mdd)
	--	love.graphics.setColor(255,255,255, 100)
		love.graphics.line(ox, oy, self._stick.Position.X, self._stick.Position.Y)
		local lineCount = 4
		for i = 1, lineCount do
			local percent = i/lineCount
			local dest = math.pi
			local x1, y1 = math.sin(dest * percent), math.cos(dest * percent)
			local x2, y2 = math.sin(dest * percent + dest), math.cos(dest * percent + dest)
			love.graphics.line(ox + x1 * mdd,oy + y1 * mdd,ox + x2 * mdd,oy + y2 * mdd)
		end
		--love.graphics.line(ox-mdd, oy, ox+mdd, oy)
		--love.graphics.line(ox, oy-mdd, ox, oy+mdd)
		love.graphics.circle("line", ox,oy, mdd-1)
		self._stick.Size = Vector.new(self.radius * 2, self.radius * 2)
	end
end

updateSignal:Connect(updateJoysticks)
drawSignal:Connect(drawJoysticks)


return module