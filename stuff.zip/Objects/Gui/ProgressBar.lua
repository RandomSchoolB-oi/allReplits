local module = {}
module.__index = module

module.new = function(MinimumValue, MaximumValue, Thickness, Length, BorderThickness)
	local radial = {
		MinimumValue = MinimumValue or 0,
		MaximumValue = MaximumValue or 1,
		Thickness = thickness or 20,
		Length = Length or 100,
		BorderThickness = BorderThickness or 1,
	}
	return setmetatable(radial, module)
end

function module:render(value, position)
	local absoluteValue = value - self.MinimumValue
	local absoluteMax = self.MaximumValue - self.MinimumValue
	local percent = absoluteValue / absoluteMax
	percent = mathf.clamp(percent, 0, 1)
	local r,g,b,a = love.graphics.getColor()
	love.graphics.setColor(r - 100, g - 100, b - 100, a)
	local b1, b2 = self.BorderThickness, self.BorderThickness*2
	love.graphics.rectangle("fill", position.X-b1, position.Y-b1, self.Length+b2, self.Thickness+b2)
	love.graphics.setColor(r,g,b,a)
	love.graphics.rectangle("fill", position.X, position.Y, self.Length * percent, self.Thickness)
	love.graphics.setColor(r,g,b,a)
end

return module