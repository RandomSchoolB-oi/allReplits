local module = {}
module.__index = module

module.new = function()
	return setmetatable({
		Position = Vector.new(0, 0),
		MaxCellCount = 5,
		--CellFillDirection = "X",
		CellSize = Vector.new(100, 100),
		CellPadding = Vector.new(6, 6),
	}, module)
end

function module:allign(frames)
	local max = self.MaxCellCount
	local pos, size, padding = self.Position, self.CellSize, self.CellPadding
	local xcount, ycount = 0, 0
	for index, v in pairs(frames) do
		local i = index - 1
		local X = i%(max)
		local Y = (i - X) / max
		if X == 0 then
			ycount = ycount + 1
		end
		if X > xcount-1 then
			xcount = X+1 
		end
		v.Size = size - padding
		v.Position = pos + Vector.new(X * size.X, Y * size.Y)
	end
	return {
		CellCount = Vector.new(xcount, ycount),
		AbsoluteSize = Vector.new(xcount * size.X + (xcount-1) * padding.X, ycount * size.Y + (ycount-1) * padding.Y),
		AbsolutePosition = pos - size/2,
	}
end

return module