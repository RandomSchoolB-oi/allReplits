local module = {}
module.__index = module

module.new = function(MinimumValue, MaximumValue, Thickness, Radius, frameCount)
	local radial = {
		MinimumValue = MinimumValue or 0,
		MaximumValue = MaximumValue or 1,
		Thickness = thickness or 10,
		Radius = Radius or 30,
		FrameCount = frameCount
	}
	return setmetatable(radial, module)
end

function module:render(value, position)
	local twopi = math.pi*2
	local absoluteValue = value - self.MinimumValue
	local absoluteMax = self.MaximumValue - self.MinimumValue
	local percent = absoluteValue / absoluteMax
	percent = mathf.clamp(percent, 0, 1)

	local radianValue = mathf.clamp(twopi * (percent), 0, twopi)
	for i = 0, radianValue, radianValue/self.FrameCount do
		local cf = CFrame.new(position.X, position.Y, i) * CFrame.new(0, -self.Radius)
		rect(1, cf.X, cf.Y, self.Thickness, 10, cf.R)
	end
end

return module