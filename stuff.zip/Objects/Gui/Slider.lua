local module = {}
module.__index = module

local sliders = {}
local serial = 0

module.new = function(from, to, inc, width)
	local slider = {
		from = from or 0,
		to = to or 1,
		increment = inc or 0.1,
		value = from or 0,
		axis = "X",

		Position = Vector.new(0, 0),
		width = width or 150,
		Moved = Signal.new(),
		dragging = false,
		_bar = Instance.new("Part"),
		Enabled = true,
	}
	slider._bar.Clickable = true
	slider._bar.Size = Vector.new(10,20)
	slider._bar.Activated:Connect(function()
		slider.dragging = true
	end)
	local id = serial
	serial = serial + 1
	slider.id = id
	sliders[id] = slider
	return setmetatable(slider, module)
end

function module:Destroy()
	if self.id then
		sticks[self.id] = nil
	end
	for i,v in pairs(self) do
		if i == "_stick" then
			v:Destroy()
		end
		self[i] = nil
	end
end

UserInput.InputEnded:Connect(function(input)
	if input.Mouse == Enum.Mouse.LeftMouseButton then
		for i,v in pairs(sliders) do
			v.dragging = false
		end
	end
end)

local updateSliders = function(dt)
	for id, self in pairs(sliders) do
		self._bar.Visible = self.Enabled
		if self.Enabled then
			local bar = self._bar
			local position, axis = self.Position, self.axis
			local w = self.width
			
			if self.dragging then
				local toPos = love.mouse.position()
				
				local pos = (mathf.clamp(toPos[axis], position[axis], position[axis]+w) - position[axis])
				local value = lerp(self.from, self.to, pos / w)
				value = mathf.clamp(value - (value%self.increment), self.from, self.to)
	
				if self.value ~= value then
					self.value = value
					self.Moved:Run(value)
				end
			end
			local barPos = {X = 0, Y = 0}
			local size = {X = 20, Y = 20}
			size[self.axis] = 10
			bar.Size = Vector.new(size.X, size.Y)
			barPos[axis] = (self.value-self.from) / (self.to-self.from) * self.width
			bar.Position = self.Position + Vector.new(barPos.X, barPos.Y)
		end
	end
end

local drawSliders = function()
	for id, self in pairs(sliders) do
		if self.Enabled then
			local posi = {X = self.Position.X, Y = self.Position.Y}
			local size = {X = 10, Y = 10}
			posi[self.axis] = posi[self.axis] + self.width/2
			size[self.axis] = self.width
			love.graphics.setColor(255,255,255,150)
			rect(1, posi.X, posi.Y, size.X, size.Y)
		end
	end
end


updateSignal:Connect(updateSliders)
drawSignal:Connect(drawSliders)


return module