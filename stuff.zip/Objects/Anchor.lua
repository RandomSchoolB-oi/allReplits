local module = {}
module.__index = module

local anchors = {}
local serial = 0

function module.new(pos, mass)
	local anchor = setmetatable({
		Position = pos or Vector.new(),
		Velocity = Vector.new(0, 0),
		Mass = mass or 10,
		Anchored = false,
		Deceleration = 5,
	}, module)

	local id = serial
	serial = serial + 1
	anchor.id = id
	anchors[id] = anchor
	
	return anchor
end

function module:Update(dt)
	if self.Anchored then
		return
	end
	self.Velocity = self.Velocity + Vector.new(0, self.Mass * dt)
	self.Position = self.Position + self.Velocity * dt
	self.Velocity = self.Velocity * (1-(self.Deceleration * dt))
end

function module:Draw()
	love.graphics.setColor(255,255,255)
	local x,y = self.Position()
	love.graphics.circle("fill",x,y,4)
end


updateSignal:Connect(function(dt)
	for i,v in pairs(anchors) do
		v:Update(dt)
	end
end)

drawSignal:Connect(function()
	for i,v in pairs(anchors) do
		v:Draw()
	end
end)

return module