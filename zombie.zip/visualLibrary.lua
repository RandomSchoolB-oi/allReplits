require("Color3")require("Vector2")require("game")
local gray = Color3.new(.5,.5,.5)
local darkGray = Color3.new(.25,.25,.25)
local brown = Color3.new(.5,.2,0)
local darkBrown = Color3.new(.25,.1,0)
local gold = Color3.fromRGB(255,255,111)
pew = function(pos)
	local x,y = pos()

	love.graphics.setColor(brown())
	love.graphics.rectangle("fill",5,y+5, 10,15)
	love.graphics.setColor(darkBrown())
	love.graphics.rectangle("line",5,y+5, 10,15)

	love.graphics.setColor(gray())
	love.graphics.rectangle("fill",5,y, 30,10)
	love.graphics.setColor(darkGray())
	love.graphics.rectangle("line",5,y, 30,10)

end

maxAmmo = function(pos)
	local x,y = pos()
	
	love.graphics.setColor(1,1,0)
	love.graphics.rectangle("fill", x,y, 10,5)
	love.graphics.setColor(.5,.5,0)
	love.graphics.rectangle("line", x,y, 10,5)
	
	love.graphics.setColor(1,1,0)
	love.graphics.rectangle("fill", x-2.5,y+5, 10,5)
	love.graphics.setColor(.5,.5,0)
	love.graphics.rectangle("line", x-2.5,y+5, 10,5)
	
	love.graphics.setColor(1,1,0)
	love.graphics.rectangle("fill", x+2.5,y+5, 10,5)
	love.graphics.setColor(.5,.5,0)
	love.graphics.rectangle("line", x+2.5,y+5, 10,5)
end

doublePoints = function(pos)
	local x,y = pos()
	love.graphics.setColor(gold())
	love.graphics.print("2X",x,y)
end