require("Color3")require("Vector2")require("game")require("visualLibrary")
local zombieClass = require("zombieClass")
local pewpewClass = require("pewpewClass")

love.window.setMode(400,300)
game.zombies = {}
game.pewpew = pewpewClass.new()
for i=1,10 do
	game.zombies[#game.zombies+1] = zombieClass.new()
end
function love.update(dt)
	if math.random(0,200) == 0 then
		game.zombies[#game.zombies+1] = zombieClass.new()
	end
	for i,v in pairs(game.zombies) do
		v:update(dt)
	end
	game.pewpew:update(dt)
end

function love.draw()
	for i,v in pairs(game.zombies) do
		v:draw()
	end
	game.pewpew:draw()
	pew(Vector2.new(love.mouse.getX(), love.mouse.getY()))
end

function love.keypressed(key)
	if key == "r" then
		game.pewpew:reload()
	end
end