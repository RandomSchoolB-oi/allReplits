require("Color3")require("Vector2")require("game")
local module = {}
module.__index = module

clamp = function(numb, min, max)
	if numb < min then
		return min
	elseif numb > max then
		return max
	else
		return numb
	end
end

function module.new()
	local pewpew = {}
	pewpew.speed = 1/16
	pewpew.shotSpeed = 200
	pewpew.maxClipSize = 8
	pewpew.ammo = 8
	pewpew.totalAmmo = 80
	pewpew.autoFire = {true, true} -- is auto, debounce
	pewpew.lastShoot = 0
	pewpew.bullets = {}

	return setmetatable(pewpew, module)
end

function module:shoot()
	self.lastShoot = os.clock()
	self.ammo = self.ammo - 1
	self.bullets[#self.bullets+1] = {
		position = Vector2.new(20, love.mouse.getY()+2.5),
		color = Color3.new(1,1,0),
		outlineColor = Color3.new(.5,.5,0),
		size = Vector2.new(10,5),
	}
end

function module:reload()
	local neededAmmo = clamp(self.maxClipSize - self.ammo, 0, self.totalAmmo)
	if neededAmmo > 0 then
		self.totalAmmo = self.totalAmmo - neededAmmo
		self.ammo = self.ammo + neededAmmo
	end
end

function module:update(dt)
	if love.mouse.isDown(1) and (self.autoFire[1] or (not self.autoFire[1] and self.autoFire[2])) and os.clock() - self.lastShoot >= self.speed and self.ammo > 0 then
		if not self.autoFire[1] and self.autoFire[2] or self.autoFire[1] then
			self.autoFire[2] = false
			
			self:shoot()
		end
	end
	if not love.mouse.isDown(1) then
		self.autoFire[2] = true
	end
	for i,v in pairs(self.bullets) do
		local hit
		for zi,zombie in pairs(game.zombies) do
			if Vector2.touching(zombie.position, zombie.size, v.position, v.size) then
				self.bullets[i] = nil
				zombie.health = zombie.health - 1
				hit = true
			end
		end
		if not hit then
			v.position = v.position + Vector2.new(self.shotSpeed*dt, 0)
		end
		if v.position.x > 500 then
			self.bullets[i] = nil
		end
	end
end

function module:draw()
	for i,v in pairs(self.bullets) do
		local x,y = v.position()
		local w,h = v.size()
		love.graphics.setColor(v.color())
		love.graphics.rectangle("fill", x,y, w,h)
		love.graphics.setColor(v.outlineColor())
		love.graphics.rectangle("line", x,y, w,h)
	end

	for i=0, self.maxClipSize-1 do
		if i <= self.ammo-1 then
			love.graphics.setColor(1,1,0)
			love.graphics.rectangle("fill", 6, i * 10 + i * 6, 20, 10)
			love.graphics.setColor(.5,.5,0)
			love.graphics.rectangle("line", 6, i * 10 + i * 6, 20, 10)
		end
	end
	
	for i=0, self.totalAmmo-1 do
		love.graphics.setColor(1,1,0)
		love.graphics.rectangle("fill", i*10,280, 10, 20)
		love.graphics.setColor(.5,.5,0)
		love.graphics.rectangle("line", i*10,280, 10, 20)
	end
end

return module