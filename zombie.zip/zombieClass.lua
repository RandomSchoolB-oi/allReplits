require("Color3")require("Vector2")require("game")require("visualLibrary")
local module = {}
module.__index = module

function module.new()
	local zombie = {}
	zombie.size = Vector2.new(50,100)
	zombie.position = Vector2.new(300 + math.random(20, 250), math.random(0, 300 - zombie.size.y))
	zombie.color = Color3.new(0,1,0.1)
	zombie.outlineColor = Color3.new(0,0.5,0.05)
	zombie.maxHealth = math.floor(math.random(2,5)+.5)
	zombie.health = zombie.maxHealth
	zombie.walkSpeed = math.random(10, 50)

	return setmetatable(zombie, module)
end

function module:update(dt,plrPos)
	if self.health <= 0 then
		self:destroy()
	else
		self.position = self.position - Vector2.new(self.walkSpeed*dt,0)--plrPos and math.abs(self.position.y - plrPos)*-0.2 or 0)
	end
end

local red = Color3.new(1,0,0)
local darkerRed = Color3.new(.5,0,0)

function module:draw()
	local x,y = self.position()
	local w,h = self.size()

	love.graphics.setColor(self.color())
	love.graphics.rectangle("fill", x,y, w,h)
	love.graphics.setColor(self.outlineColor())
	love.graphics.rectangle("line", x,y, w,h)
	for i=0, self.health do
		love.graphics.setColor(red())
		love.graphics.rectangle("fill",x+(i/self.maxHealth),y, w*(i/self.maxHealth),5)
	end
	for i=0, self.health do
		love.graphics.setColor(darkerRed())
		love.graphics.rectangle("line",x+(i/self.maxHealth),y, w*(i/self.maxHealth),5)
	end
end
local powerUps = {
	["Max Ammo"] = maxAmmo,
}
function module:destroy()
	for i,v in pairs(game.zombies) do
		if v == self then
			game.zombies[i] = nil
		end
	end
	for i in pairs(self) do
		self[i] = nil
	end
end

return module