local screenW, screenH = 300, 300
local pixelW, pixelH = 10, 10
local pixels = {}

local function GetPixelColor(x,y)
	return {x/screenW*255, y/screenH*255, 255}
end

function love.load()
	love.window.setMode(screenW, screenH)
end

function love.update()
	pixels = {}
	for x = 0, screenW, pixelW do
		pixels[x] = {}
		for y = 0, screenH, pixelH do
			pixels[x][y] = GetPixelColor(x,y)
		end
	end
end

function love.draw()
	for x, row in pairs(pixels) do
		for y, color in pairs(row) do
			love.graphics.setColor(color[1] or 0, color[2] or 0, color[3] or 0)
			love.graphics.rectangle("fill", x, y, pixelW, pixelH)
		end
	end
end