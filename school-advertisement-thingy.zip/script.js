function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

console.log("Hello");

function showPurchaseFrame() {
	var purchaseFrame = document.getElementById("purchase-frame");
	purchaseFrame.innerHTML = "You can't actually buy anything, what did you think?";
	sleep(2000).then(() => { 
		purchaseFrame.innerHTML = "";
	});
}