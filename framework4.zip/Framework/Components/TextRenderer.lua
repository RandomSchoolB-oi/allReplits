local module = {}
module.__index = module

local font = love.graphics.newFont(32, "normal")

module.new = function(this)
	local self = setmetatable({}, module)
	self.Text = ""
	self.Color = Color.new(1,1,1,1)
	self.Stretch = false
	self.this = this
	self.textCache = {
		lastText = nil,
		textObject = nil,
	}
	return self
end

function module:Draw()
	if not self.textCache.textObject or self.textCache.lastText ~= self.Text then
		self.textCache.textObject = love.graphics.newText(font, self.Text)
		self.textCache.lastText = self.Text
	end
	
	local cf = self.this.RenderCFrame
	local size = self.this.RenderSize * UnitSize
	love.graphics.push()
	love.graphics.translate(cf.X * UnitSize, cf.Y * UnitSize)
	love.graphics.rotate(cf.R)
	local textSize = Vector.new(self.textCache.textObject:getDimensions())
	local scale = size / textSize
	if not self.Stretch then
		local normal = math.min(scale.X, scale.Y)
		scale.X, scale.Y = normal, normal
		local stretchOffset = size/2 - (scale*textSize)/2
		love.graphics.translate(stretchOffset.X, stretchOffset.Y)
	end
	love.graphics.setColor(self.Color:RGBA())
	love.graphics.draw(self.textCache.textObject, -size.X/2, -size.Y/2, 0, scale.X, scale.Y)
	love.graphics.pop()
end

return module