local module = {}
module.__index = module

local function Within(this, x,y)
	local size = this.RenderSize
	local min = -size/2
	local max = -min
	local relativePos = (Vector.new(x,y)-this.RenderCFrame.Position) -- this.CFrame:ToObjectSpace(Vector.new(x,y))
	
	return relativePos.X > min.X and relativePos.X < max.X and
		relativePos.Y > min.Y and relativePos.Y < max.Y
end

module.new = function(this)
	local self = setmetatable({}, module)
	self.this = this
	self.Activated = Signal.new()
	self.Connections = {
		MousePressed:Connect(function(button, x,y)
			local scene = Scene.GetSceneById(self.this.Scene)
			if scene and button == 1 and scene.enabled and not scene.paused then
				local polygonCollider = self.this:GetComponent("PolygonCollider")

				if polygonCollider and polygonCollider:TouchingPoint(Vector.new(x,y)) or not polygonCollider and Within(this, x,y) then
					self.Activated:Run(x,y)
				end
			end
		end)
	}
	return self
end

return module