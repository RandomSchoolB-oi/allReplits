local module = {}
module.__index = module

module.new = function(this)
	local self = setmetatable({}, module)
	self.this = this
	-- self.Vertices = {}
	-- local dots = 4
	-- for i = 1, dots do
	-- 	local p = i/dots * math.pi*2
	-- 	local x = math.cos(p)
	-- 	local y = math.sin(p)
	-- 	table.insert(self.Vertices, Vector.new(x, y))
	-- end
	self.Vertices = { -- MUST BE CONVEX
		Vector.new(-1, -1),
		Vector.new(1, -1),
		Vector.new(1, 1),
		Vector.new(-1, 1),
	}
	return self
end

function module:GetDot(index)
	local size = self.this.RenderSize/2
	local rot = self.this.RenderCFrame.R
	return self.this.RenderCFrame.Position + self.Vertices[index]:MatrixMultiply(Vector.GetRotationMatrix(rot)) * size
end

function module:GetMinMax(axis)
	local min = math.huge
	local max = -math.huge

	for i = 1, #self.Vertices do
		local projected = self:GetDot(i):Dot(axis)
		if projected < min then min = projected end
		if projected > max then max = projected end
	end
	
	return min,max
end

function module:GetNormals()
	local normals = {}
	local points = {}
	for i = 1, #self.Vertices do
		local dot = self:GetDot(i)
		table.insert(points, dot)
	end

	for i = 1, #points do
		local dot = points[i]
		local nextDot = points[i % #points + 1]
		local mid = dot:Lerp(nextDot, 0.5)
		local angle = math.atan2(mid.Y-self.this.RenderCFrame.Y, mid.X-self.this.RenderCFrame.X)
	
		local normal = Vector.fromAngle(angle)
		table.insert(normals, normal)
	end
	return normals
end
function module:GetFaces()
	local faces = {}
	local points = {}
	for i = 1, #self.Vertices do
		local dot = self:GetDot(i)
		table.insert(points, dot)
	end

	for i = 1, #points do
		local dot = points[i]
		local nextDot = points[i % #points + 1]
		table.insert(faces, {from = dot, to = nextDot})
	end
	return faces
end

local function Lerp(a,b,alpha)
	return (b-a)*alpha+a
end
local function dist(a,b)
	return math.abs(b-a)
end

local function getDistOnAxis(box1,box2, axis)
	local min_proj_box1, max_proj_box1 = box1:GetMinMax(axis)
	local min_proj_box2, max_proj_box2 = box2:GetMinMax(axis)
	local width1 = dist(min_proj_box1, max_proj_box1)
	local width2 = dist(min_proj_box2, max_proj_box2)
	local origin1 = Lerp(min_proj_box1, max_proj_box1, 1/2)
	local origin2 = Lerp(min_proj_box2, max_proj_box2, 1/2)

	local dist = dist(origin1, origin2)
	local range = (width1+width2)/2

	return dist, range
end

function module:TouchingPoint(point)
	for i, axis in pairs(self:GetNormals()) do
		local min, max = self:GetMinMax(axis)
		local width = dist(min, max)
		local origin = Lerp(min, max, 1/2)
		
		if dist(origin, point) > width/2 then -- if they are far apart enough, then they arent colliding
			return false
		end
	end
	return true
end

function module:AreColliding(other)
	local normals = {}
	for _, v in pairs(self:GetNormals()) do
		table.insert(normals, v)
	end
	for _, v in pairs(other:GetNormals()) do
		table.insert(normals, v)
	end
	
	for i, axis in pairs(normals) do
		-- local axis = Vector.new(1,1).Unit
		local dist, range = getDistOnAxis(self, other, axis)
		if dist > range then -- if they are far apart enough, then they arent colliding
			return false
		end
	end
	
	local normal = (other.this.RenderCFrame.Position - self.this.RenderCFrame.Position).Unit
	local dist, range = getDistOnAxis(self, other, normal)
	
	return true, normal, (range-dist)/2
end

function module:DrawNormals()
	local normals = self:GetNormals()
	local pos, size = self.this.RenderCFrame.Position, self.this.RenderSize
	for _, normal in pairs(normals) do
		local from = (pos+normal*(size/2)) * UnitSize
		local to = (pos+normal*size) * UnitSize
		love.graphics.line(from.X, from.Y, to.X, to.Y)
	end
end

function module:DrawPoints()
	for i = 1, #self.Vertices do
		local pos = self:GetDot(i) * UnitSize
		love.graphics.circle("fill", pos.X, pos.Y, 5)
	end
end

function module:Update(dt)
end

function module:Draw()
	-- self:DrawNormals()
	-- self:DrawPoints()
end

function module:Destroy()
end

return module