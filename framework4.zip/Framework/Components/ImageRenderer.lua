local module = {}
module.__index = module

module.new = function(this)
	local self = setmetatable({}, module)
	self.Image = nil
	self.Color = Color.new(1,1,1,1)
	self.this = this
	self.imageCache = {}
	return self
end

function module:Draw()
	if not self.imageCache.imageObject or self.imageCache.lastImage ~= self.Image then
		self.imageCache.imageObject = love.graphics.newImage(self.Image)
		self.imageCache.lastImage = self.Image
	end
	
	if self.Image and self.imageCache.imageObject then
		local cf, size = self.this.RenderCFrame, self.this.RenderSize * UnitSize
		local imageSize = size/Vector.new(self.imageCache.imageObject:getDimensions())
		love.graphics.push()
		
		love.graphics.translate(cf.X * UnitSize, cf.Y * UnitSize)
		love.graphics.rotate(cf.R)
		love.graphics.setColor(self.Color:RGBA())
		love.graphics.draw(self.imageCache.imageObject, -size.X/2, -size.Y/2, 0, imageSize.X, imageSize.Y)
		
		love.graphics.pop()
	end
end

return module