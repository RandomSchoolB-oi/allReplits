local module = {}
module.__index = module

module.new = function(this)
	local self = setmetatable({}, module)
	self.this = this
	return self
end

function module:Update(dt)
	local collider = self.this:GetComponent("BoxCollider")
	local prevCF = self.this.CFrame
	if collider then
		for i = 1, #AllObjects do
	end
end

function module:Draw()
end

function module:Destroy()
end

return module