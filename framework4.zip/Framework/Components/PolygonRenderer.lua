local module = {}
module.__index = module

module.new = function(this)
	local self = setmetatable({}, module)
	self.Color = Color.new(1,1,1,1)
	self.this = this
	return self
end

function module:Draw()
	local polygonCollider = self.this:GetComponent("PolygonCollider")
	if polygonCollider then
		local vertices = {}
		for i = 1, #polygonCollider.Vertices do
			local v = polygonCollider:GetDot(i)
			table.insert(vertices, v.X*UnitSize)
			table.insert(vertices, v.Y*UnitSize)
		end
		love.graphics.setColor(self.Color:RGBA())
		love.graphics.polygon("fill", vertices)
	else
		local cf, size = self.this.RenderCFrame, self.this.RenderSize * UnitSize
		love.graphics.push()
		
		love.graphics.translate(cf.X * UnitSize, cf.Y * UnitSize)
		love.graphics.rotate(cf.R)
		love.graphics.setColor(self.Color:RGBA())
		love.graphics.rectangle("fill", -size.X/2, -size.Y/2, size.X, size.Y)
		
		love.graphics.pop()
	end
end

return module