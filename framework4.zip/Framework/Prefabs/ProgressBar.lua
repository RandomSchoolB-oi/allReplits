local module = {}
module.__index = module

module.new = function(scene)
	local self = setmetatable({}, module)
	self.objects = {}
	self.lastPercent = nil
	
	local backdropFrame = Empty.new(scene)
	backdropFrame:AddComponent("PolygonRenderer").Color = Color.new255(255, 69, 69)
	backdropFrame.Size = Vector.new(1, 0.15)
	backdropFrame.CFrame = CFrame.new(0.5, 0.2)
	local sliderFrame = Empty.new(scene)
	sliderFrame:SetParent(backdropFrame)
	sliderFrame:AddComponent("PolygonRenderer").Color = Color.new255(170, 255, 0)
	sliderFrame.Size = Vector.new(0.5, 1)
	sliderFrame.CFrame = CFrame.new(0.25,0.5,0)

	self.objects.Backdrop = backdropFrame
	self.objects.Slider = sliderFrame

	self:Scale(1)
	
	return self
end

function module:Scale(percent)
	if self.lastPercent == percent then return end

	self.objects.Slider.Size = Vector.new(percent, 1)
	self.objects.Slider.CFrame = CFrame.new(percent/2, 0.5)
end

function module:SetParent(parent)
	return self.objects.Backdrop:SetParent(parent)
end

function module:Destroy()
	for i,v in pairs(self.objects) do
		v:Destroy()
	end
	self.objects = {}
end
	
return module