local module = {}
local pi = math.pi
local hpi = pi/2
local tpi = pi*2

module.__index = function(self, i)
	local has = rawget(self, i)
	if has then return has end
	local modHas = rawget(module, i)
	if modHas then return modHas end

	if self ~= module then
		if i == "RightVector" then
			return Vector.new(math.cos(self.R), math.sin(self.R))
		elseif i == "UpVector" then
			return Vector.new(math.cos(self.R+hpi), math.sin(self.R+hpi))
		elseif i == "Position" then
			return Vector.new(self.X, self.Y)
		end
	end
end

module.new = function(x,y,r)
	return setmetatable({
		X = x or 0,
		Y = y or 0,
		R = (r or 0) % tpi,
	}, module)
end
module.Angles = function(r)
	return module.new(0, 0, r)
end
module.lookat = function(x1,y1,x2,y2)
	return module.new(x1,y1, math.atan2(y2-y1, x2-x1)+hpi)
end

function module:__add(other)
	return module.new(self.X+other.X, self.Y+other.Y, self.R)
end
function module:__sub(other)
	return module.new(self.X-other.X, self.Y-other.Y, self.R)
end

function module:__mul(other)
	local rotatedCF = module.new(self.X, self.Y, self.R + other.R)
	local movedX = rotatedCF.RightVector * other.X
	local movedY = rotatedCF.UpVector * other.Y
	return module.new(self.X + movedX.X + movedY.X, self.Y + movedX.Y + movedY.Y, rotatedCF.R)
end

function module:ToObjectSpace(vector)
	-- return module.new(vector.X, vector.Y, self.R) * self:Inverse()
end

function module:Inverse()
	return module.new(-self.X, -self.Y, -self.R)
end

return module