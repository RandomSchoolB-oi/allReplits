local module = {}
module.__index = module

local SmallCompList = {
	"Button", 
	"PolygonRenderer", 
	"ImageRenderer", 
	"TextRenderer", 
	"PolygonCollider"
}
local Components = {}
AllObjects = {}
local serial = 0
module.new = function(scene)
	serial = serial + 1
	local self = setmetatable({}, module)
	self.Active = true
	self.CFrame = CFrame.new(0, 0, 0)
	self.Size = Vector.new(1, 1)
	self.RenderCFrame = self.CFrame
	self.RenderSize = self.Size
	self.UniqueId = serial
	self.Name = "Empty"
	
	self.Components = {}
	self.Scene = nil
	self.Connections = {}
	self.SceneConnections = {}
	self.Children = {}
	
	AllObjects[self.UniqueId] = self

	if scene then self:SetScene(scene) end
	self:ChangeRenderProperties()
	return self
end

function module:SetupConnections()
	for i,v in pairs(self.SceneConnections) do v:Disconnect() end self.SceneConnections = {}
	local scene = Scene.GetSceneById(self.Scene)
	if scene then
	    table.insert(self.SceneConnections, scene.OnDraw:Connect(function(...)if self.Parent then return end self:Draw(...)end))
		table.insert(self.SceneConnections, scene.OnUpdate:Connect(function(...)if self.Parent then return end self:Update(...)end))
	end
end

function module:RemoveScene()
	if self.Scene then
        local previousScene = Scene.GetSceneById(self.Scene)
		if previousScene then
            previousScene:RemoveEmpty(self)
		end
		self.Scene = nil
		self:SetupConnections()
	end
end
function module:SetScene(scene)
    self:RemoveScene()
    if scene then
        self.Scene = scene.UniqueId
		scene:AddEmpty(self)
		self:SetupConnections()
	end
end


function module:RemoveParent()
	if self.Parent then
        local previousParent = module.GetEmptyById(self.Parent)
		if previousParent then
            previousParent:RemoveChild(self)
		end
		self.Parent = nil
	end
end

function module:AddChild(child)
	self.Children[child.UniqueId] = true
end
function module:RemoveChild(child)
	self.Children[child.UniqueId] = nil
end
function module:ChangeRenderProperties()
	local parent = self.Parent and module.GetEmptyById(self.Parent)
	if parent then
		if not parent.RenderSize or not parent.RenderCFrame then parent:ChangeRenderProperties() return end
		self.RenderSize = parent.RenderSize * self.Size
		self.RenderCFrame = parent.RenderCFrame * CFrame.new(-parent.RenderSize.X/2,-parent.RenderSize.Y/2) * CFrame.new(self.CFrame.X*parent.RenderSize.X, self.CFrame.Y*parent.RenderSize.Y, self.CFrame.R)
	else
		self.RenderCFrame = self.CFrame
		self.RenderSize = self.Size
	end
end
function module:SetParent(parent)
    self:RemoveParent()
    if parent then
        self.Parent = parent.UniqueId
		parent:AddChild(self)
	end
	self:ChangeRenderProperties()
end

function module.GetEmptyById(id)
	return AllObjects[id]
end

function module:Update(dt)
	if not self.Active then return end
	self:ChangeRenderProperties()
	for _, info in pairs(self.Components) do
		if info.comp.Update then
			info.comp:Update(dt)
		end
	end
	for id in pairs(self.Children) do
		local child = module.GetEmptyById(id)
		if child then
			child:Update(dt)
		end
	end
end

function module:Draw()
	if not self.Active then return end
	for _, info in pairs(self.Components) do
		if info.comp.Draw then
			info.comp:Draw()
		end
	end
	for id in pairs(self.Children) do
		local child = module.GetEmptyById(id)
		if child then
			child:Draw()
		end
	end
end

function module:Destroy()
	for _, info in pairs(self.Components) do
		self:RemoveComponent(info.name)
	end
	for _, conn in pairs(self.SceneConnections) do
		conn:Disconnect()
	end
	for _, conn in pairs(self.Connections) do
		conn:Disconnect()
	end
	for i,v in pairs(AllObjects) do
		if v == self then
			table.remove(AllObjects, i)
			return
		end
	end
end
	
function module:AddComponent(componentName)
	if self:GetComponent(componentName) then return end
	local comp = Components[componentName].new(self)
	table.insert(self.Components, {name = componentName, comp = comp})
	return comp
end

function module:GetComponent(componentName)
	for _, info in pairs(self.Components) do
		if info.name == componentName then
			return info.comp
		end
	end
end

function module:RemoveComponent(componentName)
	local comp = self:GetComponent(componentName)
	if comp and comp.Destroy then
		comp:Destroy()
		for i = #self.Components, 1, -1 do
			if self.Components[i].name == componentName then
				table.remove(self.Components, i)
			end
		end
	end
end

for _, compName in ipairs(SmallCompList) do
	Components[compName] = require("Framework.Components."..compName)
end

return module