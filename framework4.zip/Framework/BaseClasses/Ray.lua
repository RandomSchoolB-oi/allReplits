local module = {}
module.__index = module

module.new = function(origin, direction)
	local ray = setmetatable({
		Origin = origin or Vector.new(0, 0),
		Direction = direction or Vector.new(1,0),
		Result = {},
	}, module)
	ray:Cast()
	return ray
end

local cast = function(ray, wall)
	local x1, y1 = wall.from()
	local x2, y2 = wall.to()

	local x3, y3 = ray.Origin()
	local x4, y4 = (ray.Origin + ray.Direction)()

	local den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
	if den == 0 then
		return
	end
	local t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
	local u =-((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den
	
	if t > 0 and t < 1 and u > 0 then
		return Vector.new(
			x1 + t * (x2 - x1),
			y1 + t * (y2 - y1)
		)
	end
end

function module:Cast()
	local instance, position, normal
	local closest, closestDist = 0, math.huge
	local rayLength = self.Direction.Magnitude
	for _, part in pairs(AllObjects) do
		local collider = part:GetComponent("PolygonCollider")
		if collider then
			local boundaries = collider:GetFaces()
		
			for i,v in pairs(boundaries) do
				local collidingPos = cast(self, v) 
				if collidingPos then
					local dist = (collidingPos - self.Origin).Magnitude
					if dist <= rayLength then
						if position and dist < closestDist or not position then
							closest, closestDist = part, dist
							instance, position, normal = part, collidingPos, CFrame.lookat(v.to.X,v.to.Y, v.from.X,v.from.Y).RightVector
						end
					end
				end
			end
		end
	end
	self.Result = {
		Object = instance,
		Position = position or self.Origin + self.Direction,
		Normal = normal,
	}
	return self.Result
end

function module:Draw()
	local ro = self.Origin * UnitSize
	local rd = self.Direction * UnitSize
	love.graphics.setColor(255,255,255)
	love.graphics.line(ro.X, ro.Y, ro.X+rd.X, ro.Y+rd.Y)

	local rayPart, rayPos, rayNormal = self.Result.Object, self.Result.Position, self.Result.Normal
		
	if rayPos then
		love.graphics.circle("fill", rayPos.X*UnitSize,rayPos.Y*UnitSize, 10)
	
		if rayNormal then
			local p, d = rayPos*UnitSize, (rayPos+rayNormal)*UnitSize
			love.graphics.line(p.X,p.Y, d.X,d.Y)
		end
	end
end

return module