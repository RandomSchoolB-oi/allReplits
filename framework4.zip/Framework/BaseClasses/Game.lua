local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self._maid = Maid.new()
	self.OnDraw = Signal.new()
	self.OnUpdate = Signal.new()
	self.Scenes = {}
	return self
end

function module:GiveScene(name, scene)
	self.Scenes[name] = scene or Scene.new()
end

return module