local module = {}
module.__index = module

local scenes = {}
local serial = 0

module.new = function()
	serial = serial + 1
	local self = setmetatable({}, module)
	-- game loop events
	self.OnUpdate = Signal.new()
	self.OnDraw = Signal.new()
	-- input events
	self.KeyPressed = Signal.new()
	self.KeyReleased = Signal.new()
	self.MousePressed = Signal.new()
	self.MouseReleased = Signal.new()
	self.Time = 0
	self.Objects = {}
	self.enabled = false
	self.paused = false
	self.UniqueId = serial
	
	OnUpdate:Connect(function(dt,...)if not self.enabled or self.paused then return end self.Time = self.Time + dt self.OnUpdate:Run(dt,...) end)
	OnDraw:Connect(function(...)if not self.enabled then return end self.OnDraw:Run(...) end)
	KeyPressed:Connect(function(...)if not self.enabled or self.paused then return end self.KeyPressed:Run(...) end)
	KeyReleased:Connect(function(...)if not self.enabled or self.paused then return end self.KeyReleased:Run(...) end)
	MousePressed:Connect(function(...)if not self.enabled or self.paused then return end self.MousePressed:Run(...) end)
	MouseReleased:Connect(function(...)if not self.enabled or self.paused then return end self.MouseReleased:Run(...) end)
	
    scenes[self.UniqueId] = self
	return self
end

function module:AddEmpty(empty)
	self.Objects[empty.UniqueId] = true
end
function module:RemoveEmpty(empty)
	self.Objects[empty.UniqueId] = nil
end

function module:Pause()
	self.paused = true
end

function module:Unpause()
	self.paused = false
end

function module:Enable()
	self.enabled = true
end

function module:Disable()
	self.enabled = false
end

function module.GetSceneById(id)
	return scenes[id]
end

return module