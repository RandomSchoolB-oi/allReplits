local module = {}
module.__index = module

module.new = function()
	return setmetatable({}, module)
end

function module:Run(...)
	for _, v in pairs(self) do
		coroutine.wrap(v.callback)(...)
	end
end

function module:Connect(callback)
	local connection = {
		Disconnect = function(connection)
			for i,v in pairs(self) do
				if v == connection then
					table.remove(self, i)
					return
				end
			end
		end,
		callback = callback,
	}
	table.insert(self, connection)
	return connection
end

function module:Once(callback)
	local conn conn = self:Connect(function(...)
		conn:Disconnect()
		callback(...)
	end)
	return conn
end

function module:Wait()
	local thread = coroutine.running()
	self:Once(function(...)
		coroutine.resume(thread, ...)
	end)	
	return coroutine.yield(thread)
end

return module