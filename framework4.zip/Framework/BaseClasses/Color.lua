local module = {}
module.__index = module

module.new = function(r,g,b,a)
	return setmetatable({
		R = r or 0,
		G = g or 0,
		B = b or 0,
		A = a or 1,
	}, module)
end

module.new255 = function(r,g,b,a)
	return setmetatable({
		R = (r or 0)/255,
		G = (g or 0)/255,
		B = (b or 0)/255,
		A = (a or 255)/255,
	}, module)
end

function module:__eq(other)
	return self.R == other.R and self.G == other.G and self.B == other.B and self.A == other.A
end

function module:RGB()
	return self.R*255,self.G*255,self.B*255
end

function module:RGBA()
	return self.R*255,self.G*255,self.B*255,self.A*255
end

function module:Lerp(other, a)
	return module.new(
		(other.R - self.R) * a + self.R,
		(other.G - self.G) * a + self.G,
		(other.B - self.B) * a + self.B,
		(other.A - self.A) * a + self.A
	)
end

return module