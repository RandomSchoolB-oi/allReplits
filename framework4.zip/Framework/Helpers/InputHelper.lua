local module = {}
module.GetMoveDirection = function()
	local direction = Vector.new(0, 0)
		
	if IsKeyPressed("w") then
		direction.Y = direction.Y - 1
	end
	if IsKeyPressed("s") then
		direction.Y = direction.Y + 1
	end
	if IsKeyPressed("a") then
		direction.X = direction.X - 1
	end
	if IsKeyPressed("d") then
		direction.X = direction.X + 1
	end

	return direction
end

return module