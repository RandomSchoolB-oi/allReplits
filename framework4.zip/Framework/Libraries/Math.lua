clamp = function(a,b,c)
	return math.min(c,math.max(a,b))
end
Count = function(l)
	local c = 0
	for _ in next, l do
		c = c + 1
	end
	return c
end