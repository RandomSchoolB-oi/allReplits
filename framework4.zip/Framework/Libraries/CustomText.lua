local letters = {
	A = {7,2, 9,2, 4,6},
	B = {},

	[" "] = {},
	
	Unknown = {1,3, 3,9, 9,7, 7,1},
}

local function getLetterInfo(letter)
	return letters[letter] or letters.Unknown
end

local linePoints = {}
for y = 1, 3 do
	for x = 1, 3 do
		table.insert(linePoints, {(x-1)/2, (y-1)/2})
	end
end

local function ln(i1,i2, w,h)
	local p1, p2 = linePoints[i1],linePoints[i2]
	love.graphics.line(p1[1]*w, p1[2]*h, p2[1]*w, p2[2]*h)
end
local function drawLetter(letter, w,h)
	local letterInfo = getLetterInfo(letter)
	for i = 1, #letterInfo, 2 do
		ln(letterInfo[i], letterInfo[i+1], w,h)
	end
end

local methods = {
	drawText = function(text, x,y, letterWidth, letterHeight)
		love.graphics.push()
		love.graphics.translate((x-letterWidth/2)*UnitSize, (y-letterHeight/2)*UnitSize)
		for i = 1, text:len() do
			drawLetter(text:sub(i,i), letterWidth*UnitSize, letterHeight*UnitSize)
			love.graphics.translate(letterWidth*UnitSize, 0)
		end
		love.graphics.pop()
	end
}

return methods