local module = {}

local pi = math.pi
local hpi = pi/2
local tpi = pi*2

module.RadialProgress = function(originX, originY, radius, thickness, percent)
	local radius = radius * UnitSize
	local thickness = thickness * UnitSize
	local originX = originX * UnitSize
	local originY = originY * UnitSize
	
	love.graphics.push()
	love.graphics.translate(originX, originY)

	
	love.graphics.setLineWidth(thickness)
	local prevPos = {0, -radius}
	local smooth = 50
	for i = 0, math.floor(percent*smooth+0.5)/smooth, 1/smooth do
		local x,y = -math.sin(i*tpi) * radius, -math.cos(i*tpi) * radius
		love.graphics.line(prevPos[1], prevPos[2], x,y)
		prevPos = {x,y}
	end
	
	love.graphics.pop()
end

module.HorizontalProgress = function(originX, originY, width, height, percent)
	local width = width * UnitSize
	local height = height * UnitSize
	local originX = originX * UnitSize
	local originY = originY * UnitSize
	
	love.graphics.push()
	love.graphics.translate(originX, originY)

	local calculatedWidth = width * percent
	love.graphics.rectangle("fill", -width/2, -height/2, calculatedWidth, height)
	
	love.graphics.pop()
end

return module