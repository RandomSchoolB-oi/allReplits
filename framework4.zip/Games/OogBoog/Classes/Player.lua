local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.MaxHealth = 100
	self.Health = 100
	self.WalkSpeed = 1
	self.Object = Empty.new(WorldScene)
	self.Object.Size = Vector.new(0.5, 0.5)
	self.Object.CFrame = CFrame.new(ScreenSize.X/2, ScreenSize.Y/2)
	
	self.Object:AddComponent("PolygonCollider")
	self.Object:AddComponent("ImageRenderer").Image = GamePath.."Images/Player.png"
	self.Connections = {
		WorldScene.OnUpdate:Connect(function(dt)
			self:Update(dt)
		end)
	}

	return self
end

function module:Update(dt)
	local moveDir = InputHelper.GetMoveDirection()

	self.Object.CFrame = self.Object.CFrame + moveDir * self.WalkSpeed*dt
	if moveDir.X == 0 then

	elseif moveDir.X > 0 then
		self.Object.Size.X = -math.abs(self.Object.Size.X)
	elseif moveDir.X < 0 then
		self.Object.Size.X = math.abs(self.Object.Size.X)
	end
end

return module