local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.maid = Maid.new()	
	self.Object = Empty.new(WorldScene)
	self.Object:AddComponent("PolygonRenderer")
	self.maid:GiveTask(self.Object)
	return self
end

function module:Destroy()
	self.maid:Destroy()
end

return module