UnitSize = 100
BackgroundColor = Color.new255(10, 50, 0)
Title = "Oog Boog"
ScreenSize = Vector.new(5,5)

WorldScene = Scene.new()
PauseScene = Scene.new()
PlayerClass = require(GamePath.."Classes/Player")
ResourceClass = require(GamePath.."Classes/Resource")
require(GamePath.."Scenes/Pause")

PlayerClass.new()
ResourceClass.new()

function OpenPauseMenu()
	if not WorldScene.enabled then return end
	WorldScene:Pause()
	PauseScene:Enable()
end
KeyPressed:Connect(function(key)
	if WorldScene.paused then return end -- do nothin BOZO
	if key == "p" then
		OpenPauseMenu()
	end
end)

WorldScene:Enable()