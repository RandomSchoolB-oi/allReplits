local order = {
	{"Pistol"},
	{"Pointer","Shotgun"},
	{"Burst","AK47","Thompson"},
}
local ParentFrame = Empty.new(GunSelectScene)
ParentFrame.CFrame = CFrame.new(ScreenSize.X*0.5, ScreenSize.Y * 0.55)
ParentFrame.Size = Vector.new(ScreenSize.X, ScreenSize.Y*0.9)
local Back = Empty.new(GunSelectScene)
Back.CFrame = CFrame.new(0.1, -0.05)
Back.Size = Vector.new(0.2, 0.1)
Back:AddComponent("PolygonRenderer").Color = Color.new(1,0.1,0.1,1)
Back:AddComponent("TextRenderer").Text = "Back"
Back:AddComponent("Button").Activated:Connect(function()
	PauseScene:Enable()
	GunSelectScene:Disable()
end)
Back:SetParent(ParentFrame)
local cellHeight = 1/#order
for y, row in pairs(order) do
	local cellWidth = 1/#row
	local cellSize = Vector.new(cellWidth, cellHeight)
	for x, name in pairs(row) do
		local pewInfo = PewData[name]
		local button = Empty.new(GunSelectScene)
		button.Size = cellSize - Vector.new(0.01, 0.01)
		button.CFrame = CFrame.new(((x-1)+0.5)*cellWidth,((y-1)+0.5)*cellHeight,0)
		button:AddComponent("Button").Activated:Connect(function()
			changeToPew(name)
		end)
		button:AddComponent("PolygonRenderer").Color = Color.new255(255,255,255,100)
		button:AddComponent("ImageRenderer").Image = GamePath..pewInfo.Image
		local tr = button:AddComponent("TextRenderer")
		tr.Text = name
		tr.Color = Color.new(0,0,0,1)
		button:SetParent(ParentFrame)
	end
end

