local backdrop = Empty.new(PauseScene)
backdrop.Size = ScreenSize
backdrop.CFrame = CFrame.new(ScreenSize.X/2, ScreenSize.Y/2)
backdrop:AddComponent("PolygonRenderer").Color = Color.new(0,0,0,0.5)
local title = Empty.new(PauseScene)
title.Size = Vector.new(1, 0.1)
title.CFrame = CFrame.new(0.5, 0.05)
title:AddComponent("TextRenderer").Text = "Menu"
title:SetParent(backdrop)

local menu = Empty.new(PauseScene)
menu.Size = Vector.new(0.5, 0.8)
menu.CFrame = CFrame.new(0.5, 0.5)
menu:AddComponent("PolygonRenderer").Color = Color.new(1,1,1,0.5)
menu:SetParent(backdrop)

local function newButton(text, index, callback)
	local button = Empty.new(PauseScene)
	button.Size = Vector.new(1-0.01, 0.1-0.01)
	button.CFrame = CFrame.new(0.5, 0.05+((index-1)*0.1))
	button:AddComponent("PolygonRenderer").Color = Color.new(1,1,1,0.5)
	button:AddComponent("TextRenderer").Text = text
	button:AddComponent("Button").Activated:Connect(callback)
	button:SetParent(menu)
end

newButton("Resume", 1, function()
	PauseScene:Disable()
	WorldScene:Unpause()
end)
newButton("Gun Select", 2, function()
	GunSelectScene:Enable()	
	PauseScene:Disable()
end)
newButton("Kill", 10, function()
	Kill()
end)