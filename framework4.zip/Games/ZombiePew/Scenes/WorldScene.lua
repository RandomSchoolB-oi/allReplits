function CreatePew(name)
	local pew = PewClass.new()
	local info = PewData[name]
	pew.name = name
	for prop, val in pairs(info) do
		if prop == "Image" then
			pew.Object:GetComponent("ImageRenderer").Image = GamePath..val
		elseif prop == "Size" then
			pew.Object[prop] = val
		end
		pew[prop] = val
	end
	return pew
end
function CreateMelee(name)

end

local Player = PlayerClass.new()

changeToPew = function(n)
	Player:ChangeToPew(n)
end

-- local Wall = Empty.new()
-- Wall.CFrame = CFrame.new(25, 20)
-- Wall.Size = Vector.new(1, 10)
-- Wall:AddComponent("PolygonCollider")
-- Wall:AddComponent("PolygonRenderer")
-- Wall:SetScene(WorldScene)

WorldScene.KeyPressed:Connect(function(button)
	if button == "r" then
		Player:GetPew():Reload()
	end
end)
WorldScene.MousePressed:Connect(function(button, x,y)
	if button == 1 then
		Player:GetPew():Click()
	end
end)
WorldScene.MouseReleased:Connect(function(button)
	if button == 1 then
		for i, pew in pairs(Player.Loadout.pews) do
			pew:Unclick()
		end
	end
end)

WorldScene.OnUpdate:Connect(function(dt)
	local mousePos = GetMousePosition()
	Player:LookAt(mousePos)

	-- if math.random() < 0.01 then
	-- 	ZombieClass.new()
	-- end
end)