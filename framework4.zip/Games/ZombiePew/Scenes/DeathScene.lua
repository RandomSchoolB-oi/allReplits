local deathMessage = Empty.new(DeathScene)
deathMessage.CFrame = CFrame.new(ScreenSize.X*0.5, ScreenSize.Y*0.5)
deathMessage.Size = Vector.new(0.5, 0.3) * ScreenSize

local died = Empty.new(DeathScene)
died:SetParent(deathMessage)
died.CFrame = CFrame.new(0.5, 0.25)
died.Size = Vector.new(1,0.5)
died:AddComponent("TextRenderer").Text = "Game Over!"
local over = Empty.new(DeathScene)
over:SetParent(deathMessage)
over.CFrame = CFrame.new(0.5, 0.666)
over.Size = Vector.new(1,0.25)
over:AddComponent("TextRenderer").Text = "You died"
local frown = Empty.new(DeathScene)
frown:SetParent(deathMessage)
frown.CFrame = CFrame.new(0.5, 1)
frown.Size = Vector.new(.25,0.25)
frown:AddComponent("TextRenderer").Text = ":("
