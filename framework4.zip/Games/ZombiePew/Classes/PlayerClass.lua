local module = {}
module.__index = module

local serial = 0

local Players = {}

module.new = function()
	serial = serial + 1
	local self = setmetatable({}, module)
	self.Object = Empty.new(WorldScene)
	self.Object.Size = Vector.new(1,1)
	self.Object:AddComponent("PolygonRenderer")
	self.Loadout = {
		equippedPew = 1,
		pews = {},
		melee = CreateMelee("Knife"),
	}
	self.MaxHealth = 100
	self.Health = self.MaxHealth
	self.Walkspeed = 10
	self.LastHurt = 0
	self.UniqueId = serial
	self:ChangeToPew("Pistol")
	self:ApplyPew()

	self.Object.CFrame = CFrame.new(ScreenSize.X/2, ScreenSize.Y/2)

	local playerFrame = Empty.new(WorldScene)
	playerFrame.Size = Vector.new(5, 5)
	playerFrame.CFrame = CFrame.new(playerFrame.Size.X/2, ScreenSize.Y-playerFrame.Size.Y/2)
	
	local pewDisplayFrame = Empty.new(WorldScene)
	pewDisplayFrame:SetParent(playerFrame)
	pewDisplayFrame.CFrame = CFrame.new(0.5, 0.5, 0)
	pewDisplayFrame.Size = Vector.new(0.5, 0.5) 
	pewDisplayFrame:AddComponent("ImageRenderer")

	local nameFrame = Empty.new(WorldScene)
	nameFrame:SetParent(playerFrame)
	nameFrame.CFrame = CFrame.new(0.5, 0.9, 0)
	nameFrame.Size = Vector.new(1, 0.2) 
	nameFrame:AddComponent("TextRenderer").Text = "Player "..tostring(serial)

	local healthSlider = Prefab.new("ProgressBar", WorldScene)
	healthSlider:SetParent(playerFrame)

	local ammoCounter = Empty.new(WorldScene)
	ammoCounter:SetParent(playerFrame)
	ammoCounter.Size = Vector.new(1, .5)
	ammoCounter.CFrame = CFrame.new(0.5, -0.125)
	ammoCounter:AddComponent("TextRenderer")
	self.InfoFrames = {
		ammoCounter = ammoCounter:GetComponent("TextRenderer"),
		healthSlider = healthSlider,
		pewDisplay = pewDisplayFrame:GetComponent("ImageRenderer"),
	}
	
	Players[self.UniqueId] = self
	WorldScene.OnUpdate:Connect(function(dt)
		self:Update(dt)
	end)
	return self
end

module.getClosestPlayer = function(pos)
	local closest, closestDist = nil, math.huge
	for _, player in pairs(Players) do
		local dist = (player.Object.CFrame.Position - pos).Magnitude
		if dist < closestDist then
			closest, closestDist = player, dist
		end
	end
	return closest, closestDist
end

function module:ApplyPew()
	for i, pew in pairs(self.Loadout.pews) do
		pew.Object.Active = i == self.Loadout.equippedPew
	end
end

function module:SwapPew()
	self.Loadout.equippedPew = (self.Loadout.equippedPew % #self.Loadout.pews) + 1
	self:ApplyPew()
end

function module:GetPew()
	return self.Loadout.pews[self.Loadout.equippedPew]
end

function module:TakeDamage(damage)
	self.LastHurt = WorldScene.Time
	self.Health = clamp(self.Health - damage, 0, self.MaxHealth)
	self.InfoFrames.healthSlider:Scale(self.Health/self.MaxHealth)
end

function module:ChangeToPew(name)
	for i, pew in pairs(self.Loadout.pews) do
		if pew.name == name then
			self.Loadout.equippedPew = i
			self:ApplyPew()
			return
		end
	end
	local newPew = CreatePew(name)
	table.insert(self.Loadout.pews, newPew)
	self.Loadout.equippedPew = #self.Loadout.pews
	self:ApplyPew()
	newPew.Object:SetParent(self.Object)
end

function module:LookAt(pos)
	self.Object.CFrame = CFrame.lookat(self.Object.CFrame.X, self.Object.CFrame.Y, pos.X,pos.Y) * CFrame.new(0, 0, -math.pi/2)
	local rot = self.Object.CFrame.R
	if rot > math.pi/2 and rot < math.pi * 1.5 then
		self.Object.Size = Vector.new(self.Object.Size.X, -math.abs(self.Object.Size.Y))
	else
		self.Object.Size = Vector.new(self.Object.Size.X, math.abs(self.Object.Size.Y))
	end
end

function module:Update(dt)
	local moveDir = InputHelper.GetMoveDirection()
	local currentPew = self:GetPew()
	self.Object.CFrame = self.Object.CFrame + moveDir * self.Walkspeed * dt
	self.Object.CFrame = CFrame.new(clamp(self.Object.CFrame.X, 0, ScreenSize.X), clamp(self.Object.CFrame.Y, 0, ScreenSize.Y), self.Object.CFrame.R)
	
	self.InfoFrames.healthSlider:Scale(self.Health/self.MaxHealth)
	
	self.InfoFrames.ammoCounter.Text = tostring(currentPew.Mag).."/"..tostring(currentPew.Ammo)
	self.InfoFrames.pewDisplay.Image = GamePath..currentPew.Image

	if self.Health <= 0 then
		Players[self.UniqueId] = nil
		if Count(Players)==0 then
			Kill()
		end
	else
		self.Health = clamp(self.Health + (WorldScene.Time-self.LastHurt)*dt, 0, self.MaxHealth)
	end
end

return module