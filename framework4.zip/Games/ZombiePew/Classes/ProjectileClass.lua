local module = {}
module.__index = module

local checkRate = 1/30

module.new = function(origin, direction, speed)
	local self = setmetatable({}, module)
	self.maid = Maid.new()
	self.Object = Empty.new()
	self.Object:AddComponent("ImageRenderer").Image = GamePath.."Images/Bullet.png"
	self.Object.Size = Vector.new(1.2,1.2)
	self.Object:SetScene(WorldScene)
	-- self.Object.CFrame = CFrame.lookAt(origin.X, origin.Y, origin.X+direction.X, origin.Y+direction.Y)

	self.maid:GiveTask(self.Object)
	
	self.Position = origin
	self.Direction = direction
	self.Speed = speed
	
	self.LastCheckPos = self.Position
	self.LastCheck = WorldScene.Time
	self.LifeTime = 0
	
	self.Hit = Signal.new()
	self.maid:GiveTask(WorldScene.OnUpdate:Connect(function(dt)
		self:Update(dt)	
	end))
	return self
end	

function module:Update(dt)
	local distMoved = self.Direction * self.Speed * dt
	self.Position = self.Position + distMoved

	self.Object.CFrame = CFrame.new(self.Position.X, self.Position.Y, self.Direction:ToAngle()+math.pi/2)
	
	self.LifeTime = self.LifeTime + dt
	if self.LifeTime > 6 then
		self:Destroy()
	end
	local t = WorldScene.Time
	if t - self.LastCheck >= checkRate then
		local ray = Ray.new(self.LastCheckPos, self.Position - self.LastCheckPos)
		if ray.Result.Object then
			self.Hit:Run(ray.Result)
			self:Destroy()
			return
		end
		self.LastCheck = t
		self.LastCheckPos = self.Position
	end
end

function module:Destroy()
	self.maid:Destroy()
end

return module