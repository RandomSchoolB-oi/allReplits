local module = {}
module.__index = module

local serial = 0
local Zombies = {}

module.new = function()
	serial = serial + 1
	local self = setmetatable({}, module)
	self.UniqueId = serial
	self.Health = 100
	self.maid = Maid.new()
	self.Object = Empty.new(WorldScene)
	self.Object.Size = Vector.new(5,5)
	self.Object.CFrame = CFrame.new(0, 0, math.rad(math.random(0, 360))) * CFrame.new(0, math.random(ScreenSize.Magnitude, ScreenSize.Magnitude + 10))
	self.Object:AddComponent("PolygonCollider")
	local renderer = self.Object:AddComponent("PolygonRenderer")
	-- self.HealthSlider = Prefab.new("ProgressBar", WorldScene)
	-- self.HealthSlider:SetParent(self.Object)
	self.Object.Name = "Zombie"
	self.WalkSpeed = 6
	self.LastHit = 0
	self.LastHurt = 0
	self.AttackRange = 3
	self.AttackSpeed = 1
	self.Damage = 33
	self.RegularColor = Color.new255(0,100,25,255)
	self.HurtColor = Color.new(1,1,1,1)
	self.maid:GiveTask(WorldScene.OnUpdate:Connect(function(dt)
		local playerToFollow = PlayerClass.getClosestPlayer(self.Object.CFrame.Position)
		local dir = playerToFollow.Object.CFrame.Position - self.Object.CFrame.Position
		self.Object.CFrame = self.Object.CFrame + (dir.Unit * self.WalkSpeed * dt)
		self.Object.CFrame.R = math.atan2(dir.Y, dir.X)
		self:Hit(playerToFollow)

		renderer.Color =  self.HurtColor:Lerp(self.RegularColor, clamp((WorldScene.Time-self.LastHurt)*10, 0, 1))
	end))
	Zombies[self.UniqueId] = self
	return self
end

function module:Hit(player)
	if not player then return end
	local t = WorldScene.Time
	if t-self.LastHit>self.AttackSpeed and (player.Object.CFrame.Position - self.Object.CFrame.Position).Magnitude < self.AttackRange then
		self.LastHit = t
		player:TakeDamage(self.Damage)
		return true
	end
end

function module:TakeDamage(amount)
	self.Health = self.Health - amount
	self.LastHurt = WorldScene.Time
	-- self.HealthSlider:Scale(self.Health/100)
	if self.Health <= 0 then
		self:Destroy()
	end
end

function module:Destroy()
	self.maid:Destroy()
	Zombies[self.UniqueId] = nil
end

module.getZombieByObject = function(object)
	for i,v in pairs(Zombies) do
		if v.Object == object then
			return v 
		end
	end
end

return module