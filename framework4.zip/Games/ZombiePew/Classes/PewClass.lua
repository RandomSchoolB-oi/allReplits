local module = {}
module.__index = module

local test = Empty.new(WorldScene)
test.CFrame = CFrame.new(ScreenSize.X/2, ScreenSize.Y*0.2)
test.Size = Vector.new(1, 0.2) * ScreenSize
local textBox = test:AddComponent("TextRenderer")

module.new = function()
	local self = setmetatable({}, module)
	self.maid = Maid.new()
	self.lastFire = -1000
	self.lastBurst = -1000
	self.burstLeft = 0
	self.lastReload = -1000
	self.lastUpdate = WorldScene.Time
	self.projectiles = {}
	self.firing = false
	self.Object = Empty.new()
	self.Object.Active = false
	self.Object:SetScene(WorldScene)
	self.Object:AddComponent("ImageRenderer")
	
	-- config
	self.MaxAmmo = 100
	self.MagSize = 10
	
	self.Ammo = 100
	self.Mag = 10

	self.Recoil = {0,0,0}
	self.SpeedRandomness = {-3,3}
	self.ProjectilesPerFire = 1
	self.Burst = 3
	self.BurstRate = 1/25
	self.FireRate = 1/4
	self.ReloadSpeed = 1
	self.Spread = {0, 0}
	self.Automatic = false

	self.ProjectileSpeed = 20
	
	self.maid:GiveTask(self.Object)
	self.maid:GiveTask(WorldScene.OnUpdate:Connect(function()
		if not self.Object.Active then return end
		self:Update()
	end))
	self.maid:GiveTask(WorldScene.OnDraw:Connect(function()
		if not self.Object.Active then return end
		self:Draw()
	end))
	
	return self
end

function module:Click()
	if self.Mag <= 0 then
		self:Reload()
		return
	end
	self.clicked = true
	if not self:CanFire() then return end
	self.clickTime = WorldScene.Time
	self.lastFire = WorldScene.Time
	self.burstLeft = Clamp(self.Burst, 0, self.Mag)
	self:Fire()
end
function module:Unclick()
	self.clicked = false
end

function module:Fire()
	self.Mag = self.Mag - 1
	self.burstLeft = Clamp(self.burstLeft - 1, 0, self.Mag)
	self.lastBurst = WorldScene.Time
	if not self.Automatic then
		self.clicked = false
	end
	local barrelCF = self.Object.RenderCFrame*CFrame.new(self.Object.RenderSize.X/2, 0)
	for i = 1, self.ProjectilesPerFire do
		local spread = math.random(self.Spread[1], self.Spread[2])
		local dir = (barrelCF * CFrame.Angles(math.rad(spread))).RightVector
		local projectile = ProjectileClass.new(barrelCF.Position, dir, self.ProjectileSpeed + math.random(self.SpeedRandomness[1], self.SpeedRandomness[2]))
		projectile.Hit:Once(function(result)
			if result and result.Object then
				local zombieObject = ZombieClass.getZombieByObject(result.Object)
				if zombieObject then
					zombieObject:TakeDamage(self.Damage/self.ProjectilesPerFire)
				end
			end
		end)
	end
end

function module:Reload()
	if not self:CanFire(true) and self.Mag > 0 or self.Mag == self.MagSize then return end
	local amountAdded = Clamp(self.Mag+self.Ammo, 0, self.MagSize)-self.Mag
	self.Mag = self.Mag + amountAdded
	self.Ammo = self.Ammo - amountAdded
	self.lastReload = WorldScene.Time
end

function module:ShouldFireBurstShot()
	return (self.burstLeft > 0 and WorldScene.Time-self.lastBurst > self.BurstRate)
end

function module:CanFire(notForFire)
	local t = WorldScene.Time
	if t-self.lastReload<self.ReloadSpeed then return end
	if self.burstLeft > 0 then return end
	if self.Mag <= 0 then return end
	if self.clicked or notForFire then 
		return t-self.lastFire > self.FireRate
	end
end

function module:Update()
	local t = WorldScene.Time
	local dt = t - self.lastUpdate

	self.Object.CFrame = CFrame.new(0.5, 0.5)
	textBox.Text = tostring(self.Object.RenderSize.X).." "..tostring(self.Object.RenderSize.Y).." "..tostring(dt)
		--recoil
	-- local p = clamp(1-(WorldScene.Time-self.lastBurst)/self.Recoil[3], 0, 1)
	-- if p > 0 then
	-- 	self.Object.CFrame = self.Object.CFrame * CFrame.new(0,0, -math.rad(self.Recoil[2]*p)) --* CFrame.new(-self.Recoil[1]*p, 0)
	-- end
	self.lastUpdate = t
	if self:CanFire() then
		self:Click(GetMousePosition())
	elseif self:ShouldFireBurstShot() then
		self:Fire()
	end
end

function module:Draw()
	local t = WorldScene.Time
	local reloadTimeLeft = t-self.lastReload
	if reloadTimeLeft < self.ReloadSpeed then
		Graphics.RadialProgress(self.Object.RenderCFrame.X, self.Object.RenderCFrame.Y, 3, 2/3, reloadTimeLeft/self.ReloadSpeed)
	end
end

function module:Destroy()
	self.maid:Destroy()
end

return module