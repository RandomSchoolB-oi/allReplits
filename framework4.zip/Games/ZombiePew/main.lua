UnitSize = 10
BackgroundColor = Color.new255(2, 40, 0)
Title = "Zombie Pew"
ScreenSize = Vector.new(40,40)

-- ZombieGame = Game.new()

WorldScene = Scene.new()
GunSelectScene = Scene.new()
DeathScene = Scene.new()
PauseScene = Scene.new()

local function loadScene(name) return RequireGameModule("Scenes."..name) end

PewClass = RequireGameModule("Classes.PewClass")
ProjectileClass = RequireGameModule("Classes.ProjectileClass")
ZombieClass = RequireGameModule("Classes.ZombieClass")
PlayerClass = RequireGameModule("Classes.PlayerClass")
PewData = RequireGameModule("Databanks.PewData")

loadScene("GunSelectScene")
loadScene("WorldScene")
loadScene("DeathScene")
loadScene("PauseScene")

function Kill()
	WorldScene:Disable()
	GunSelectScene:Disable()
	DeathScene:Enable()
	PauseScene:Disable()
end

function OpenPauseMenu()
	if not WorldScene.enabled then return end
	WorldScene:Pause()
	PauseScene:Enable()
end
function ClosePauseMenu()
	if not WorldScene.enabled then return end
	WorldScene:Unpause()
	PauseScene:Disable()
end

KeyPressed:Connect(function(key)
	if DeathScene.enabled then return end -- do nothin BOZO
	if WorldScene.paused then return end -- do nothin BOZO
	if key == "p" then
		OpenPauseMenu()
	end
end)

WorldScene:Enable()
-- DeathScene:Enable()