local module = {}

module.Pistol = {
	MaxAmmo = 80,
	MagSize = 8,

	Ammo = 32,
	Mag = 8,

	Damage = 15,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 35,
	ProjectilesPerFire = 1,
	Burst = 1,
	BurstRate = 0,
	FireRate = 1/60,
	ReloadSpeed = 1/2,
	Spread = {0, 0},
	Automatic = false,
	Image = "Images/Pistol.png",
	Size = Vector.new(8,8)
}
module.Shotgun = {
	MaxAmmo = 80,
	MagSize = 8,

	Ammo = 80,
	Mag = 8,

	Damage = 200,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 20,
	ProjectilesPerFire = 25,
	Burst = 1,
	BurstRate = 0,
	FireRate = 1/3,
	ReloadSpeed = 1/2,
	Spread = {-15, 15},
	Automatic = false,
	Image = "Images/Shotgun.png",
	Size = Vector.new(10,10)
}
module.Burst = {
	MaxAmmo = 150,
	MagSize = 30,

	Ammo = 150,
	Mag = 30,

	Damage = 25,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 30,
	ProjectilesPerFire = 1,
	Burst = 3,
	BurstRate = 1/60,
	FireRate = 1/10,
	ReloadSpeed = 1/2,
	Spread = {-3, 3},
	Automatic = false,
	Image = "Images/Burst.png",
	Size = Vector.new(6,6)
}
module.Pointer = {
	MaxAmmo = 10000,
	MagSize = 1000,

	Ammo = 10000,
	Mag = 1000,

	Damage = 999,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 10,
	ProjectilesPerFire = 1,
	Burst = 1,
	BurstRate = 0,
	FireRate = -10,
	ReloadSpeed = -10,
	Spread = {-7,7},
	Automatic = true,
	Image = "Images/Rifle.png",
	Size = Vector.new(5,5)
}
module.AK47 = {
	MaxAmmo = 150,
	MagSize = 30,

	Ammo = 150,
	Mag = 30,

	Damage = 55,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 45,
	ProjectilesPerFire = 1,
	Burst = 1,
	BurstRate = 0,
	FireRate = 1/20,
	ReloadSpeed = 1/3,
	Spread = {-2,2},
	Automatic = true,
	Image = "Images/Assault Rifle.png",
	Size = Vector.new(13,13)
}
module.Thompson = {
	MaxAmmo = 240,
	MagSize = 30,

	Ammo = 240,
	Mag = 30,

	Recoil = {2,30,1/2},--pos,rot,time
	Damage = 20,
	SpeedRandomness = {-5,5},
	ProjectileSpeed = 30,
	ProjectilesPerFire = 1,
	Burst = 1,
	BurstRate = 0,
	FireRate = 1/40,
	ReloadSpeed = 1/3,
	Spread = {-5,5},
	Automatic = true,
	Image = "Images/SMG.png",
	Size = Vector.new(7,7)
}

return module