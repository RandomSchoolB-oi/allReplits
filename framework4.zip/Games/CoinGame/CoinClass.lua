local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Object = Empty.new(WorldScene)
	self.Object:AddComponent("PolygonRenderer").Color = Color.new255(255, 200, 50)
	self.Collider = self.Object:AddComponent("PolygonCollider")
	self.Object.Size = Vector.new(0.5, 0.5)
	self.Object.CFrame = CFrame.new(randomFloat(0, ScreenSize.X), randomFloat(0, ScreenSize.Y))
	self.Connections = {
		OnUpdate:Connect(function()
			if self.Collider:AreColliding(player.Collider) then
				pickupCoin(self)
			end
		end)
	}
	return self
end

function module:Destroy()
	for i,v in pairs(self.Connections) do
		v:Disconnect()
	end
	self.Object:Destroy()
end

return module