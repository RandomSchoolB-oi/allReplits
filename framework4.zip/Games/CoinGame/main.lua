local Path = "Games/CoinGame/"
function randomFloat(min, max) return math.random()*(max-min)+min end
UnitSize = 100
BackgroundColor = Color.new255(0, 0, 0)
Title = "Coin Game?"
ScreenSize = Vector.new(5,5)
WorldScene = Scene.new()

local InputHelper = require(Path.."InputHelper")
local PlayerClass = require(Path.."PlayerClass")
local CoinClass = require(Path.."CoinClass")

player = PlayerClass.new()
player.Object.Size = Vector.new(0.5, 0.5)

local lastPickup = 0

function pickupCoin(coin)
	local t = WorldScene.Time
	if t - lastPickup < 1/30 then
		return
	end
	lastPickup = t
	
	player.Object.Size = player.Object.Size + Vector.new(0.05, 0.05)
	coin:Destroy()
	
	CoinClass.new()
end

for i = 1, 10 do
	CoinClass.new()
end
	
OnUpdate:Connect(function(dt)
	local mousePos = GetMousePosition()
	player:Move(InputHelper.GetMoveDirection())
	player:LookAt(mousePos)	
end)

WorldScene:Enable()