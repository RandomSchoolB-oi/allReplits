local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.WalkSpeed = 1
	self.Object = Empty.new(WorldScene)
	self.Object:AddComponent("ImageRenderer").Image =  GamePath.."Assets/BadlandsChugs.png"
	self.Collider = self.Object:AddComponent("PolygonCollider")
	local Verified = Empty.new(WorldScene)
	Verified:SetParent(self.Object)
	Verified:AddComponent("ImageRenderer").Image = GamePath.."Assets/Verified.png"
	Verified.Size = Vector.new(0.25, 0.25)
	Verified.CFrame = CFrame.new(0.7, 0.7)
	return self
end

function module:Move(direction)
	if direction and direction.Magnitude > 0 then
		self.Object.CFrame = self.Object.CFrame + direction.Unit * self.WalkSpeed * dt
	end
end

function module:LookAt(position)
	self.Object.CFrame = CFrame.lookat(self.Object.CFrame.X, self.Object.CFrame.Y, position.X, position.Y)
end

return module