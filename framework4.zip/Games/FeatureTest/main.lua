UnitSize = 100
BackgroundColor = Color.new255(0, 0, 0)
Title = "feature test"
ScreenSize = Vector.new(5,5)

WorldScene = Scene.new()

local box = Empty.new()
local collider = box:AddComponent("PolygonCollider")
local renderer = box:AddComponent("PolygonRenderer")
box.CFrame = CFrame.new(2.5, 2.5, math.pi/4)
box:SetScene(WorldScene)
WorldScene:Enable()
WorldScene:Unpause()

local ray = Ray.new(Vector.new(0,0), Vector.new(0, 1))

OnUpdate:Connect(function(dt)
	local rotAmount = 0
	if IsKeyPressed("q") then
		rotAmount = rotAmount - dt * 2
	end
	if IsKeyPressed("r") then
		rotAmount = rotAmount + dt * 2
	end
	local mousePos = GetMousePosition()

	local diff = mousePos - ray.Origin
	ray.Direction = Vector.fromAngle(math.atan2(diff.Y, diff.X)) * diff.Magnitude

	ray:Cast()

	box.CFrame = CFrame.new(box.CFrame.X, box.CFrame.Y, box.CFrame.R+rotAmount)
end)

OnDraw:Connect(function()
	ray:Draw()
end)