-- private variables
local pressedKeys = {}
local pressedMouseButtons = {}

-- public methods
GamePath = "Game/"
function LoadPrefab(name) return require("Framework/Prefabs/"..name) end
function LoadHelper(name) return require("Framework/Helpers/"..name) end
function LoadBaseClass(name) return require("Framework/BaseClasses/"..name) end
function LoadLibrary(name) return require("Framework/Libraries/"..name) end
function LoadGame(name) GamePath = "Games/"..name.."/" return require(GamePath.."main") end
function RequireGameModule(name) return require(GamePath..name) end
function IsKeyPressed(key) return not not pressedKeys[key] end
function IsMouseButtonPressed(key) return not not pressedMouseButtons[key] end
function GetMousePosition() return Vector.new(love.mouse.getPosition())/UnitSize end
function Clamp(x,a,b) return x < a and a or x > b and b or x end

-- initialize the base classes
Vector = LoadBaseClass("Vector")
CFrame = LoadBaseClass("CFrame")
Color = LoadBaseClass("Color")
Signal = LoadBaseClass("Signal")
Empty = LoadBaseClass("Empty")
Ray = LoadBaseClass("Ray")
Scene = LoadBaseClass("Scene")
Spring = LoadBaseClass("Spring")
Maid = LoadBaseClass("Maid")
Promise = LoadBaseClass("Promise")

-- initialize the libraries
Graphics = LoadLibrary("Graphics")
CustomText = LoadLibrary("CustomText")
LoadLibrary("Math")

-- initialize the helpers
InputHelper = LoadHelper("InputHelper")

-- initialize the prefabs
local prefabs = {
	ProgressBar = LoadPrefab("ProgressBar"),
}
Prefab = {new = function(name, ...)
	return prefabs[name].new(...)
end}

-- game loop events
OnUpdate = Signal.new()
OnDraw = Signal.new()
-- input events
KeyPressed = Signal.new()
KeyReleased = Signal.new()
MousePressed = Signal.new()
MouseReleased = Signal.new()

-- constants
UnitSize = 10
DT = 1/60
Title = "Untitled Game"
BackgroundColor = Color.new255(255,255,255)
ScreenSize = Vector.new(200, 200)
DefaultFont = love.graphics.newFont(128, "normal")

-- cached values
local cachedTitle = nil
local cachedBackgroundColor = nil
local cachedScreenSize = nil

-- connect all the signals
love.draw=function()
	if cachedTitle~=Title then love.window.setTitle(Title)cachedTitle=Title end 
	if cachedBackgroundColor~=BackgroundColor then love.graphics.setBackgroundColor(BackgroundColor:RGB())cachedBackgroundColor=BackgroundColor end 
	if cachedScreenSize~=ScreenSize then love.window.setMode(ScreenSize.X*UnitSize,ScreenSize.Y*UnitSize)cachedScreenSize=ScreenSize end
	OnDraw:Run()
end
love.update=function(DT)dt=DT OnUpdate:Run(DT)end
love.keypressed=function(key)pressedKeys[key]=true KeyPressed:Run(key)end
love.keyreleased=function(key)pressedKeys[key]=nil KeyReleased:Run(key)end
love.mousepressed=function(x,y,key)pressedMouseButtons[key]=true MousePressed:Run(key,x/UnitSize,y/UnitSize)end
love.mousereleased=function(x,y,key)pressedMouseButtons[key]=nil MouseReleased:Run(key,x/UnitSize,y/UnitSize)end


-- LoadGame("OogBoog")
-- LoadGame("ZombiePew")
LoadGame("CoinGame")