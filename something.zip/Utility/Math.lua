local newMethods = {}

newMethods.lerp = function(a,b,x)
	return (b-a)*x+a
end
newMethods.clamp = function(x,a,b)
	return math.min(math.max(x,a),b)
end


newMethods.sign = function(x)
	return x < 0 and -1 or 1
end

local regMathLibrary = math

math = setmetatable({}, {
	__index = function(_, i)
		return newMethods[i] or regMathLibrary[i]
	end,

	__newindex = function() end,
})