local module = {}
module.__index = module

local PlayerClass = require("Classes.Entities.Player")

module.new = function()
	local self = setmetatable({}, module)
	self.Player = PlayerClass.new()
	self.Score = 0
	self.InputText = ""

	self.CurrentDungeon = nil
	self.Dungeons = {}

	return self
end

function module:EnterDungeon(dungeon, cell)
	self.CurrentDungeon = dungeon
	self.Player:SetDungeon(dungeon, cell.X, cell.Y)
end

function module:LinkDungeons(dungeon1, dungeon2)
	dungeon1.ExitCell.To = dungeon2.StartCell
	dungeon2.StartCell.To = dungeon1.ExitCell
end

function module:NewDungeon(id, dungeon)
	self.Dungeons[id] = dungeon
end
function module:GetDungeon(id)
	return self.Dungeons[id]
end

function module:Print()
	if DungeonGame.CurrentDungeon then
		DungeonGame.CurrentDungeon:Print()
	end
	print("Move: (W/A/S/D) | Interact: E | Score: "..tostring(DungeonGame.Score))
end

function module:ProcessInput(text, fromInputText)
	text = tostring(text):lower()
	if not fromInputText then
		self.InputText = self.InputText..text
	end

	local input = text:sub(1,1)
	self.InputText = self.InputText:sub(2,-1)

	local interactionHappened = DungeonGame.Player:ParseInput(input)

	if interactionHappened then
		self:Tick()
	end
end

function module:GameLoop()
	self:Print()
	if self.InputText:len() > 0 then
		self:ProcessInput(self.InputText, true)
	else
		self:ProcessInput(io.read())
	end
end

function module:Tick()
	if not self.CurrentDungeon then return end
	for _, entity in pairs(self.CurrentDungeon.Entities) do
		entity:Tick()
	end
end



return module