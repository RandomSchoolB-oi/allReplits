local module = {}
module.__index = module

local Delaunay = require("Classes.DungeonGeneration.DelaunayTriangulation")

local idSerial = 0

module.new = function(x,y,w,h)
	local self = setmetatable({}, module)
	idSerial = idSerial + 1

	self.X = x
	self.Y = y
	self.W = w
	self.H = h
	self.ID = idSerial

	self.CenterX = x + w/2
	self.CenterY = y + h/2

	self.Point = Delaunay.Point(self.CenterX, self.CenterY)
	self.Point.RoomID = self.ID

	return self
end

return module