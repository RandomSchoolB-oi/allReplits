local module = {}
module.__index = module

module.new = function(params)
	local self = setmetatable(params or {}, module)

	self:BulkReconsile({
		Width = 16,
		Height = 16,
		RoomCount = 3,

		MaxRoomWidth = 5,
		MinRoomWidth = 3,

		MaxRoomHeight = 5,
		MinRoomHeight = 3,

		MinRoomSpacing = 1,
		Seed = 0,
	})

	return self
end

function module:Reconsile(index, value)
	if self[index] == nil then
		self[index] = value
	end
end

function module:BulkReconsile(tbl)
	for index, value in pairs(tbl) do
		self:Reconsile(index, value)
	end
end

return module