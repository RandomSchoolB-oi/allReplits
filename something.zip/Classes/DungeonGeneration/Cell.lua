local module = {}
module.__index = module

module.new = function(x,y)
	local self = setmetatable({}, module)
	self.X = x
	self.Y = y

	self.Character = "#"

	return self
end

return module