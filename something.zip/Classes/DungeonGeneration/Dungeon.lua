local module = {}
module.__index = module

local GenerationParameters = require("Classes.DungeonGeneration.GenerationParameters")
local Delaunay = require("Classes.DungeonGeneration.DelaunayTriangulation")
local Cell = require("Classes.DungeonGeneration.Cell")
local Room = require("Classes.DungeonGeneration.Room")

local Random = require("Classes.Random")

local Coin = require("Classes.Entities.Coin")
local Enemy = require("Classes.Entities.Enemy")
local Transition = require("Classes.Entities.Transition")

local Maid = require("Classes.Maid")
local Signal = require("Classes.Signal")

local Characters = {
	RoomBorders = {
		{"+-","--","-+"},
		{"| ","  "," |"},
		{"+-","--","-+"},
	},

	HorizontalHallway = "::",
	VerticalHallway = "::",
	Door = "🚪",
	Stairs = "𓊍 ",

	EmptySpace = "",
}

local function ConnectRooms(connectionMap, from, to, _inverse)
	if not connectionMap[from] then
		connectionMap[from] = {}
	end
	connectionMap[from][to] = true

	if not _inverse then
		ConnectRooms(connectionMap, to, from, true)
	end
end

local function GetDistance(x1, y1, x2, y2)
	return math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

local function Round(number)
	return math.floor(number)
end


local function VisitRoom(roomId, rooms, connectionMap, visited)
	local smallestLength, closestRoom = math.huge, nil

	for connectedRoom in pairs(connectionMap[roomId]) do
		if not visited[connectedRoom] then
			local fromRoom = rooms[roomId]
			local toRoom = rooms[connectedRoom]
			local dist = GetDistance(
				fromRoom.CenterX, fromRoom.CenterY,
				toRoom.CenterX, toRoom.CenterY
			)

			if dist < smallestLength then
				closestRoom = connectedRoom
			end
		end
	end

	if closestRoom then
		visited[closestRoom] = true
	end

	return closestRoom
end

local function AlreadyConnected(lines, room1, room2)
	for _, v in ipairs(lines) do
		if v[1] == room1 and v[2] == room2 or v[1] == room2 and v[2] == room1 then
			return true
		end
	end
	return false
end

local function Triangulate(self) -- Delaunay triangulation
	local allPoints = {}
	for _, room in pairs(self.Rooms) do
		table.insert(allPoints, room.Point)
	end

	local triangles = Delaunay.triangulate(unpack(allPoints))
	local connectionMap = {}
	for _, triangle in pairs(triangles) do
		ConnectRooms(connectionMap, triangle.p1.RoomID, triangle.p2.RoomID)
		ConnectRooms(connectionMap, triangle.p2.RoomID, triangle.p3.RoomID)
		ConnectRooms(connectionMap, triangle.p3.RoomID, triangle.p1.RoomID)
	end

	return connectionMap
end

local function GetMinimumSpanningTree(self, connectionMap) -- Prims algorithm
	local roomIds = {}
	for _, room in pairs(self.Rooms) do
		table.insert(roomIds, room.ID)
	end

	local roomStack = { roomIds[self:GetRandom("startRoom"):NextInteger(1, #roomIds)] }
	local visited = {[roomStack[1]] = true}

	self.StartingRoom = roomIds[1]

	local lines = {}
	while true do
		if #roomStack <= 0 then
			break
		end
		local currentId = roomStack[#roomStack]
		local room = VisitRoom(currentId, self.Rooms, connectionMap, visited)
		if room then
			table.insert(lines, { currentId, room })
			table.insert(roomStack, room)
		else
			table.remove(roomStack)
		end
	end
	return lines
end

module.new = function(parameters)
	if not parameters then
		parameters = GenerationParameters.new()
	end

	local self = setmetatable({}, module)
	self.Parameters = parameters
	self.Randoms = {}
	self.Dungeon = {}

	self.StartingRoom = 0

	self.RoomSerial = 0
	self.Rooms = {}

	self.Entities = {}

	-- fill out empty board
	self:FillBox(1, 1, parameters.Width, parameters.Height, function(x, y)
		local newCell = Cell.new(x, y)
		newCell.Character = Characters.EmptySpace
		newCell.Empty = true
		return newCell
	end)

	-- generate rooms
	for _ = 1, self.Parameters.RoomCount do
		repeat
			local generated = self:GenerateRoom()
		until generated
	end

	-- triangulate the tooms, and generate the minimum spanning tree
	local connectionMap = Triangulate(self)
	local mst = GetMinimumSpanningTree(self, connectionMap)

	for room1, list in pairs(connectionMap) do
		for room2 in pairs(list) do
			if self:GetRandom("redundantLines"):NextInteger(1, 10) == 1 and not AlreadyConnected(mst, room1, room2) then
				table.insert(mst, { room1, room2 })
			end
		end
	end

	for _, line in pairs(mst) do
		self:ConnectRooms(line[1], line[2])
	end

	-- pick random exit room
	do
		local roomIdsForExit = {}
		for id in pairs(self.Rooms) do
			if id ~= self.StartingRoom then
				table.insert(roomIdsForExit, id)
			end
		end
		self.ExitRoom = roomIdsForExit[self:GetRandom("exitRoom"):NextInteger(1, #roomIdsForExit)]
	end

	-- create transition cells
	do
		local startRoomCell = Transition.new(false)
		local startRoom = self.Rooms[self.StartingRoom]
		startRoomCell:SetDungeon(self, Round(startRoom.CenterX), Round(startRoom.CenterY))
		self.StartCell = startRoomCell

		local exitRoomCell = Transition.new(true)
		local exitRoom = self.Rooms[self.ExitRoom]
		exitRoomCell:SetDungeon(self, Round(exitRoom.CenterX), Round(exitRoom.CenterY))
		self.ExitCell = exitRoomCell
	end


	for _, room in pairs(self.Rooms) do
		local roomCoinRandom = self:GetRandom("roomCoins"..tostring(room.ID))
		if room.ID ~= self.ExitRoom and room.ID ~= self.StartingRoom then
			local randomX = roomCoinRandom:NextInteger(room.X+1, (room.X + room.W)-2)
			local randomY = roomCoinRandom:NextInteger(room.Y+1, (room.Y + room.H)-2)

			-- if roomCoinRandom:NextInteger(1,2) == 1 then
				local coinCell = Coin.new()
				coinCell:SetDungeon(self, randomX, randomY)
			-- else
			-- 	local enemyCell = Enemy.new()
			-- 	enemyCell:SetDungeon(self, randomX, randomY)
			-- end
		end
	end

	return self
end

function module:CanRoomFit(_x, _y, w, h)
	for x = (_x - self.Parameters.MinRoomSpacing), (_x + w + self.Parameters.MinRoomSpacing) - 1 do
		for y = (_y - self.Parameters.MinRoomSpacing), (_y + h + self.Parameters.MinRoomSpacing) - 1 do
			local cell = self:GetCell(x, y)
			if (cell and not cell.Empty) then
				return false
			end
		end
	end

	return true
end

function module:GenerateRoom()
	local roomRandom = self:GetRandom("room")
	local randomWidth = roomRandom:NextInteger(self.Parameters.MinRoomWidth, self.Parameters.MaxRoomWidth)
	local randomHeight = roomRandom:NextInteger(self.Parameters.MinRoomHeight, self.Parameters.MaxRoomHeight)

	local randomX = roomRandom:NextInteger(1, self.Parameters.Width - randomWidth)
	local randomY = roomRandom:NextInteger(1, self.Parameters.Height - randomHeight)

	if self:CanRoomFit(randomX, randomY, randomWidth, randomHeight) then
		self.RoomSerial = self.RoomSerial + 1

		local newRoom = Room.new(randomX, randomY, randomWidth, randomHeight)

		self.Rooms[newRoom.ID] = newRoom

		self:FillBox(randomX, randomY, randomWidth, randomHeight, function(x, y)
			local newCell = Cell.new(x, y)

			local xChar = x == randomX and 1 or x == (randomX + randomWidth-1) and 3 or 2
			local yChar = y == randomY and 1 or y == (randomY + randomHeight-1) and 3 or 2
			newCell.Character = Characters.RoomBorders[yChar][xChar]
			newCell.RoomID = newRoom.ID

			return newCell
		end)
		return true
	end
end

function module:GetCell(x, y)
	return self.Dungeon[x] and self.Dungeon[x][y]
end

function module:FillBox(_x, _y, _w, _h, getValue)
	_x, _y = math.max(_x, 1), math.max(_y, 1)
	_w, _h = math.min(_w, self.Parameters.Width - (_x - 1)), math.min(_h, self.Parameters.Height - (_y - 1))

	for x = _x, (_x + _w) - 1 do
		self.Dungeon[x] = self.Dungeon[x] or {}
		for y = _y, (_y + _h) - 1 do
			self.Dungeon[x][y] = getValue(x, y)
		end
	end
end


local function DogLeg(x1, y1, x2, y2, horizontal)
	local currentPos = {X = x1, Y = y1}

	local cells = {}

	local i1Min, i1Max = (horizontal and x1 or y1), (horizontal and x2 or y2)
	for i = i1Min, i1Max, math.sign(i1Max-i1Min) do
		currentPos[horizontal and "X" or "Y"] = i
		table.insert(cells, {currentPos.X, currentPos.Y, horizontal})
	end

	local i2Min, i2Max = (horizontal and y1 or x1), (horizontal and y2 or x2)
	for i = i2Min, i2Max, math.sign(i2Max-i2Min) do
		currentPos[horizontal and "Y" or "X"] = i
		table.insert(cells, {currentPos.X, currentPos.Y, not horizontal})
	end

	return cells
end

function module:ConnectRooms(roomId1, roomId2)
	local room1, room2 = self.Rooms[roomId1], self.Rooms[roomId2]

	if room1 and room2 then
		local roundedCenterX1, roundedCenterY1 = Round(room1.CenterX), Round(room1.CenterY)
		local roundedCenterX2, roundedCenterY2 = Round(room2.CenterX), Round(room2.CenterY)

		local horizontalDogLeg = DogLeg(roundedCenterX1, roundedCenterY1, roundedCenterX2, roundedCenterY2, true)
		for _, cellPos in ipairs(horizontalDogLeg) do
			local cell = self:GetCell(cellPos[1], cellPos[2])
			if not (cell and cell.Empty) then
				break
			end
		end

		local verticalDogLeg = DogLeg(roundedCenterX1, roundedCenterY1, roundedCenterX2, roundedCenterY2, false)
		for _, cellPos in ipairs(verticalDogLeg) do
			local cell = self:GetCell(cellPos[1], cellPos[2])
			if not (cell and cell.Empty) then
				break
			end
		end


		local distances = {
			Horizontal = 0,
			Vertical = 0,
		}

		for i, list in ipairs({horizontalDogLeg, verticalDogLeg}) do
			for _, cellPos in ipairs(list) do
				local distanceFromClosestRoom = math.huge
				for _, room in pairs(self.Rooms) do
					if room.ID ~= roomId1 and room.ID ~= roomId2 then
						local dist = GetDistance(cellPos[1], cellPos[2], room.CenterX, room.CenterY)
						if dist < distanceFromClosestRoom then
							distanceFromClosestRoom = dist
						end
					end
				end

				local key = i == 1 and "Horizontal" or "Vertical"
				distances[key] = distances[key] + distanceFromClosestRoom
			end
		end

		local chosenDogLeg
		if distances.Horizontal < distances.Vertical then
			chosenDogLeg = verticalDogLeg
		elseif distances.Horizontal > distances.Vertical then
			chosenDogLeg = horizontalDogLeg
		else
			chosenDogLeg = self:GetRandom("dogleg"):NextInteger(1, 2) == 1 and horizontalDogLeg or verticalDogLeg
		end

		for _, cellPos in ipairs(chosenDogLeg) do
			local cell = self:GetCell(cellPos[1], cellPos[2])
			if (cell) then
				local char = cellPos[3] and Characters.HorizontalHallway or Characters.VerticalHallway
				if cell.Empty then
					local newCell = Cell.new(cellPos.X)
					newCell.Character = char
					newCell.Hallway = true
					newCell.Rooms = {room1, room2}
					self.Dungeon[cell.X][cell.Y] = newCell
				else
					-- if cell.Character == "" and (cell.RoomID == roomId1 or cell.RoomID == roomId2) then
					-- 	cell.Character = char
					-- end
				end
			end
		end
	end
end

function module:GetRandom(title)
	if self.Randoms[title] then
		return self.Randoms[title]
	end

	local newRandom = Random.new(self.Parameters.Seed + Random.StrToSeed(title))
	self.Randoms[title] = newRandom

	return self.Randoms[title]
end

function module:Print()
	local stuffToPrint = {}
	for y = 1, self.Parameters.Height do
		local str = ""
		for x = 1, self.Parameters.Width do
			local cell = self.Dungeon[x][y]

			local entitiesOnCell = {}
			for _, entity in pairs(self.Entities) do
				if entity.Cell.X == x and entity.Cell.Y == y then
					table.insert(entitiesOnCell, entity)
				end
			end
			if #entitiesOnCell > 0 then
				local did = false
				for _, entity in pairs(entitiesOnCell) do
					if entity.Name == "Player" then
						did = true
						cell = entity.Cell
						break
					end
				end

				if not did then
					cell = entitiesOnCell[1].Cell
				end
			end

			str = str .. cell.Character .. string.rep(" ", 2 - cell.Character:len())
		end
		table.insert(stuffToPrint, str)
	end
	os.execute("clear")
	for _, v in ipairs(stuffToPrint) do
		print(v)
	end
end

return module
