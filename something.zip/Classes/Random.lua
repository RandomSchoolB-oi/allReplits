local module = {}
module.__index = module

module.StrToSeed = function(str)
	local seed = 0
	for i = 1, str:len() do
		seed = seed + str:sub(i, i):byte() ^ 3
	end
	return seed
end

module.new = function(seed)
	local self = setmetatable({}, module)
	self.Seed = seed
	self.Serial = 0

	return self
end

function module:_incSeed()
	self.Serial = self.Serial + 1
	math.randomseed(self.Seed + self.Serial)
end

function module:NextInteger(min, max)
	self:_incSeed()
	return math.random(min, max)
end

function module:NextNumber(min, max)
	self:_incSeed()
	return math.lerp(min, max, math.random())
end

return module