local module = {}
module.__index = module
local ParentClass = require("Classes.Entities.Entity")
setmetatable(module, ParentClass)

module.new = function()
	local self = setmetatable(ParentClass.new(), module)
	self.Cell.Character = "👤"
	self.Name = "Player"

	return self
end

return module