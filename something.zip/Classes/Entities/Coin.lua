local module = {}
module.__index = module
local ParentClass = require("Classes.Entities.Entity")
setmetatable(module, ParentClass)

module.new = function()
	local self = setmetatable(ParentClass.new(), module)
	self.Cell.Character = "🪙 "
	self.Name = "Coin"

	return self
end

function module:Interact(player)
	DungeonGame.Score = DungeonGame.Score + 1
	self:Destroy()
end

return module