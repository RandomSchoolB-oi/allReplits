local module = {}
module.__index = module
local ParentClass = require("Classes.Entities.Entity")
setmetatable(module, ParentClass)

module.new = function()
	local self = setmetatable(ParentClass.new(), module)
	self.Cell.Character = "🧟"
	self.Name = "Enemy"

	return self
end

function module:Tick()
	local randomMovement = self.Dungeon:GetRandom("enemy_"..tostring(self.ID))
	local directions = {"w","a","s","d"}
	self:ParseInput(directions[randomMovement:NextInteger(1, 4)])
end

return module