local module = {}
module.__index = module
local ParentClass = require("Classes.Entities.Entity")
setmetatable(module, ParentClass)

module.new = function(stairs)
	local self = setmetatable(ParentClass.new(), module)
	self.Cell.Character = stairs and "𓊍 " or "🚪"
	self.Name = "Transition"

	return self
end

function module:Interact(player)
	if self.To then
		for _, entity in pairs(self.Dungeon.Entities) do
			if entity.Name == "Key" then
				print("Requires a key")
				return
			end
		end
		DungeonGame:EnterDungeon(self.To.Dungeon, self.To.Cell)
	end
end

return module