local module = {}
module.__index = module

local Cell = require("Classes.DungeonGeneration.Cell")
local Maid = require("Classes.Maid")

module.All = {}

local IDSerial = 0

module.new = function()
	local self = setmetatable({}, module)
	self.Maid = Maid.new()
	self.Name = "Entity"

	IDSerial = IDSerial + 1
	self.ID = IDSerial
	module.All[self.ID] = self

	self.Cell = Cell.new(0, 0)
	self.Cell.Character = "👤"

	self.Maid:GiveTask(function()
		module.All[self.ID] = nil
		self:SetDungeon()
	end)

	return self
end

function module:SetDungeon(dungeon, roomId, y)
	if self.Dungeon then
		self.Dungeon.Entities[self.ID] = nil
	end

	self.Dungeon = dungeon
	if dungeon then
		self.Dungeon.Entities[self.ID] = self

		if roomId and y then
			self.Cell.X, self.Cell.Y = roomId, y
		else
			local startingRoom = dungeon.Rooms[roomId]
			self.Cell.X, self.Cell.Y = math.floor(startingRoom.CenterX), math.floor(startingRoom.CenterY)
		end
	end
end

function module:GetRoomAtCoords(x, y)
	for _, room in pairs(self.Dungeon.Rooms) do
		if x >= room.X and x <= room.X + room.W - 1 and y >= room.Y and y <= room.Y + room.H - 1 then
			return room.ID
		end
	end
end

function module:CanMoveTo(x, y)
	if not self.Dungeon then return false end

	local cell = self.Dungeon:GetCell(x, y)
	if (cell and cell.Empty) or not cell then return false end

	if cell and (cell.RoomID or cell.Hallway) then
		return true
	end

	return true
end

function module:ParseInput(input, tickWorld)
	input = tostring(input):sub(1, 1):lower()
	local shouldTick = false

	local newX, newY = self.Cell.X, self.Cell.Y
	if input == "w" then
		newY = newY - 1
	elseif input == "s" then
		newY = newY + 1
	elseif input == "a" then
		newX = newX - 1
	elseif input == "d" then
		newX = newX + 1
	end

	if input == "e" then
		if self.Dungeon then
			local entityCell
			do
				for _, entity in pairs(self.Dungeon.Entities) do
					if entity ~= self and entity.Cell.X == self.Cell.X and entity.Cell.Y == self.Cell.Y then
						entityCell = entity
						break
					end
				end
			end

			if entityCell then
				entityCell:Interact(self)
				shouldTick = true
			end
		end
	end

	if (newX ~= self.Cell.X or newY ~= self.Cell.Y) and self:CanMoveTo(newX, newY) then
		self.Cell.X = newX
		self.Cell.Y = newY
		shouldTick = true
	end

	return shouldTick
end

function module:Interact(player)
end

function module:Tick()
end

function module:Destroy()
	self.Maid:Destroy()
end

return module
