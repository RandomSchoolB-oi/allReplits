require("Utility.Math")

local Dungeon = require("Classes.DungeonGeneration.Dungeon")
local GenerationParameters = require("Classes.DungeonGeneration.GenerationParameters")

local GameClass = require("Classes.Game")
DungeonGame = GameClass.new()

--wwwwwwwwwesssssssssdddddddewwedddddddddddwwwwwwwwwesssssssssaaaaaaaaaawwwwwwwaaaaaaaawwwwwddddddwewwwwdddddddssssssssssssaedwwwwwwwwwwwwae
DungeonGame:NewDungeon(1, Dungeon.new(GenerationParameters.new({
	Width = 24,
	Height = 24,
	RoomCount = 7,

	MaxRoomWidth = 5,
	MinRoomWidth = 3,

	MaxRoomHeight = 5,
	MinRoomHeight = 3,

	MinRoomSpacing = 2,
	Seed = 10,
})))
DungeonGame:NewDungeon(2, Dungeon.new(GenerationParameters.new({
	Width = 12,
	Height = 12,
	RoomCount = 4,

	MaxRoomWidth = 4,
	MinRoomWidth = 3,

	MaxRoomHeight = 4,
	MinRoomHeight = 3,

	MinRoomSpacing = 1,
	Seed = 4325657,
})))
DungeonGame:LinkDungeons(DungeonGame:GetDungeon(1), DungeonGame:GetDungeon(2))
DungeonGame:NewDungeon(3, Dungeon.new(GenerationParameters.new({
	Width = 32,
	Height = 32,
	RoomCount = 10,

	MaxRoomWidth = 5,
	MinRoomWidth = 3,

	MaxRoomHeight = 5,
	MinRoomHeight = 3,

	MinRoomSpacing = 1,
	Seed = 1234,
})))
DungeonGame:LinkDungeons(DungeonGame:GetDungeon(2), DungeonGame:GetDungeon(3))

local startingDungeon = DungeonGame:GetDungeon(1)
DungeonGame:EnterDungeon(startingDungeon, startingDungeon.StartCell.Cell)

local lastTick = -1
local tickSpeed = 1/60

while true do
	if os.clock()-lastTick > tickSpeed then
		lastTick = os.clock()
		DungeonGame:GameLoop()
	end
end