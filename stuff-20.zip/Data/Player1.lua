return {
["Position"] = {
  ["X"] = 194.79373177311,
  ["Y"] = 319.66112422796,
},
["Data"] = {
  ["back"] = "Iron Sword",
  ["inventory"] = {
    [1] = {
    },
    [2] = {
    },
    [3] = {
    },
    [4] = {
    },
    [5] = {
    },
    [6] = {
    },
    [7] = {
    },
    [8] = {
    },
    [9] = {
    },
  },
  ["toolbar"] = {
    [1] = {
      ["name"] = "Iron Sword",
      ["quantity"] = 1,
    },
  },
  ["hand"] = "Iron Pickaxe",
},
}