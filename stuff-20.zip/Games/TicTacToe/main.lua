game = Instance.new("Game")

game:setScreenSize(Vector2.new(600, 400))
game:setBackground(Color.black)
game:setTitle("Tic-Tac-Toe")

local size = Vector2.new(3,3)
local players = {"X","O"}
local score = {}
local currentPlayer = 1

local board = {}

local scoreFrames = {}
local function drawScore()
	for i, val in ipairs(score) do
		local frame = scoreFrames[i]
		if not frame then
			local plrAmt = #score
			frame = Instance.new("Frame")
			frame.Size = Udim2.new(1/plrAmt, -6, 1/(size.Y+1), -6)
			frame.Position = Udim2.new((i-1)/plrAmt, 3, 1, -3)
			frame.AnchorPoint = Vector2.new(0, 1)
			frame.BackgroundColor = Color.white
			scoreFrames[i] = frame
		end
		frame.Text = players[i]..": "..tostring(val)
		frame.TextScale = 128
	end
end

local function getCheckIndices()
	local indices = {}

	if size.X == size.Y and size.X % 2 == 1 then
		local diag1 = {}
		local diag2 = {}
		for i = 1, size.X do
			diag1[#diag1+1] = {i, i}
			diag2[#diag2+1] = {size.X - i + 1, i}
		end
		indices[#indices+1] = diag1
		indices[#indices+1] = diag2
	end
	
	for x = 1, size.X do
		local vertical = {}
		for y = 1, size.Y do
			vertical[#vertical+1] = {x,y}
		end
		indices[#indices+1] = vertical
	end
	for y = 1, size.Y do
		local horizontal = {}
		for x = 1, size.X do
			horizontal[#horizontal+1] = {x,y}
		end
		indices[#indices+1] = horizontal
	end

	return indices
end

local function checkBoard()
	local indices = getCheckIndices()
	for _, list in pairs(indices) do
		local p1 = board[list[1][1]][list[1][2]].player
		if p1 then
			local wins = true
			for _, cellPos in ipairs(list) do
				local p2 = board[cellPos[1]][cellPos[2]].player
				if p1 ~= p2 then
					wins = false
					break
				end
			end
			if wins then
				return p1
			end
		end
	end

	local scratch = true
	for x = 1, size.X do
		for y = 1, size.Y do
			if not board[x][y].player then
				scratch = false
				break
			end
		end
		if not scratch then break end
	end
	if scratch then
		return 0
	end
end

local function wipeBoard()
	drawScore()
	for _, v in ipairs(board) do
		for _, j in ipairs(v) do
			j.frame:destroy()
		end
	end
	
	for x = 1, size.X do
		board[x] = {}
		for y = 1, size.Y do
			local cell = {
				player = nil,
			}
			
			local frame = Instance.new("Frame")
			frame.Size = Udim2.new(1/size.X, -6, 1/(size.Y+1), -6)
			frame.Position = Udim2.new((x-1) / size.X, 3, (y-1) / (size.Y+1), 3)
			frame.BackgroundColor = Color.white
			frame.Selectable = true
			frame.AutoColor = true
			frame.TextScale = 128
			frame.Activated:Connect(function()
				if cell.player then
					return
				end
				frame.Selectable = false
				frame.AutoColor = false
					local o = frame.BackgroundColor
				frame.BackgroundColor = o:Lerp(Color.black, 0.25)
				cell.player = currentPlayer
				frame.Text = players[currentPlayer]
				currentPlayer = currentPlayer % #players + 1
				
				local winner = checkBoard()
				if winner then
					if winner == 0 then
						print("It's a draw")
							
						currentPlayer = 1
					else
						currentPlayer = winner
						score[winner] = score[winner] + 1
						print("player"..tostring(winner).." ("..players[winner]..") wins")
					end
					wipeBoard()
				end
			end)
			
			cell.frame = frame
			board[x][y] = cell
		end
	end
end


for _ in ipairs(players) do
	score[#score+1] = 0
end
wipeBoard()

return game