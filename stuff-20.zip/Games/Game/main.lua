game = Instance.new("Game")


local function expoGD()
	pcall(function()
		print("a:")
		local a = tonumber(io.read())
		print("rate:")
		local r = tonumber(io.read())
		print("t:")
		local t = tonumber(io.read())
	
		print("is rate in percent? (y/n)")
		local isPercent = io.read() == "y"
		print("decay? (y/n)")
		local d = io.read() == "y"
		
		if isPercent then
			r = r / 100
		end
		if d == "d" then
			r = -r
		end
	end)
			
	print("ans: ".. a*(1+r)^t)
end


game.onUpdate:Connect(function(dt)
	-- game:setTitle("FPS: "..tostring(math.floor(1/dt+0.5)))
	expoGD()
end)

game.onDraw:Connect(function()
	
end)

game.onLoad:Connect(function()
	game:setScreenSize(Vector2.new(300, 300))
	game:setBackground(Color.black)
	game:setTitle(" ")
end)

return game