local function createStats(self)
	local l = Instance.new("Frame")
	l.BackgroundColor = Color.blank

	local i = 0
	for statName in pairs(self.Data.temporaryData.stats) do
		local f = Instance.new("Frame")
		f.BackgroundColor = Color.new(1,1,1, 0.5)
		f.Name = statName
		-- f.Padding = Udim2.new(0,6,0,6)
		f.Parent = l
		local s = Instance.new("Frame")
		s.Size = Udim2.new(1, 0, 1, 0)
		s.Position = Udim2.new(0, 0, 0, 0)
		s.BackgroundColor = Color.new(1,1,1, 1)
		s.Name = "Slider"
		s.Parent = f
		local t = Instance.new("Frame")
		t.Size = Udim2.new(1,0,1,0)
		t.Text = statName
		t.TextScale = 16
		t.TextColor = Color.new(0,0,0,0.4)
		t.BackgroundColor = Color.none
		t.Name = "Title"
		t.Parent = f

		if statName == "health" then
            s.BackgroundColor = Color.fromRGB(170, 255, 0, 255)
		elseif statName == "food" then
			s.BackgroundColor = Color.fromRGB(255, 170, 0, 255)
		elseif statName == "water" then
			s.BackgroundColor = Color.fromRGB(150, 175, 255, 255)
		end
		i = i + 1
	end
	self.StatsGui = l
	return l
end

local function updateStatsFrames(self, gui)
	for stat, amount in pairs(self.Data.temporaryData.stats) do
		gui[stat].Slider.Size = Udim2.new(amount/100, 0, 1, 0)
	end
end

local function makeInventory(player)
	local f = Instance.new("Frame")
	f.Size = Udim2.new(0.5, 0, 0.5, 0)
	f.Position = Udim2.new(0.5, 0, 0.5, 0)
	f.AnchorPoint = Vector2.new(0.5, 0.5)
	f.BackgroundColor = Color.none
	f.Name = "Inventory"

	local title = Instance.new("Frame")
	title.Size = Udim2.new(1, 0, 0.1, 0)
	title.Position = Udim2.new(0.5, 0, 0, 0)
	title.AnchorPoint = Vector2.new(0.5, 0)
	title.BackgroundColor = Color.new(0, 0, 0, 0.75)
	title.TextColor = Color.white
	title.Text = "Inventory"
	title.Name = "Title"
	title.Parent = f
	
	local list = Instance.new("Frame")
	list.Size = Udim2.new(1, 0, 0.9, 0)
	list.Position = Udim2.new(0.5, 0, 1, 0)
	list.AnchorPoint = Vector2.new(0.5, 1)
	list.BackgroundColor = Color.new(0, 0, 0, 0.5)
	list.Name = "List"
	list.Parent = f

	f:draw()
	local containerName = "inventory"
	local containerGuiObject = player.Data[containerName]:createGui(list, Vector2.new(3,3))
	for index, frame in ipairs(list:getChildren()) do
		frame.Activated:Connect(function()
			if player.dragInfo then
				player.Data[containerName]:swap(index, player.Data[player.dragInfo.container], player.dragInfo.index)
				player.dragInfo = nil
			else
				if not player.Data[containerName][index].name then return end
				player.dragInfo = {
					index = index,
					container = containerName
				}	
			end
			containerGuiObject.updateFrames()
		end)
	end
	containerGuiObject.updateFrames()
	
	return f
end

newMobileController = function(player)
	local leftJoystick = Instance.new("Joystick")
	leftJoystick.Radius = 50
	leftJoystick.Position = Udim2.new(0,75,1,-75):Calculate()
	leftJoystick.Moved:Connect(function(dir)
		player.ignoreSwing = true
		player.MoveDirection = dir

		if dir.Magnitude > 0.01 then
			player.CFrame.Rotation = dir:ToAngle() + math.pi/2
		end
	end)

	local inventoryGui = makeInventory(player)
	local statList = createStats(player)
	statList.Size = Udim2.new(0.5, 0, 0, 25)
	statList.Position = Udim2.new(0.5,0, 0,0)
	statList.AnchorPoint = Vector2.new(0.5, 0)
	statList:draw()
	
	local statGrid = Instance.new("GridLayout")
	statGrid.CellSize = Udim2.new(1/3, -6, 1, -6)
	statGrid.CellPadding = Udim2.new(0, 6, 0, 6)
	statGrid:apply(statList)
	
	local buttonsFrame = Instance.new("Frame")
	buttonsFrame.Position = Udim2.new(0.5,0, 1,-36)
	buttonsFrame.Size = Udim2.new(0,150,0,30)
	buttonsFrame.AnchorPoint = Vector2.new(0.5,1)
	buttonsFrame.BackgroundColor = Color.none
	buttonsFrame.Padding = Udim2.new(0, 6, 0, 6)
	
	local swapButton = Instance.new("Button")
	swapButton.Size = Udim2.new(0.5, -3, 1, 0)
	swapButton.Position = Udim2.new(1,0,0,0)
	swapButton.AnchorPoint = Vector2.new(1,0)
	swapButton.Name = "Swap"
	swapButton.Text = "Swap"
	swapButton.Parent = buttonsFrame
	swapButton.Activated:Connect(function()
		player.ignoreSwing = true
		player:swap()
	end)
	
	local dropButton = Instance.new("Button")
	dropButton.Size = Udim2.new(0.5, -3, 1, 0)
	dropButton.Position = Udim2.new(0,0,0,0)
	dropButton.AnchorPoint = Vector2.new(0,0)
	dropButton.Name = "Drop"
	dropButton.Text = "Drop"
	dropButton.Parent = buttonsFrame
	dropButton.Activated:Connect(function()
		player.ignoreSwing = true
		player:drop()
	end)
	
	local swingButton = Instance.new("Button")
	swingButton.Size = Udim2.new(0,100,0,100)
	swingButton.Position = Udim2.new(1,-75,1,-75)
	swingButton.AnchorPoint = Vector2.new(1,1)
	swingButton.Shape = Enum.FrameShape.Circle
	swingButton.Name = "Swing"
	swingButton.BackgroundColor = Color.new(1,1,1,0.5)
	-- swingButton.Text = "Swing"
	-- swingButton.Parent = nil
	swingButton.Activated:Connect(function()
		player.ignoreGrab = true
		player:use()
	end)
	
	game.inputBegan:Connect(function(key)
		if key.KeyCode == Enum.KeyCode.MouseButton1 then
			if player.ignoreGrab then
				player.ignoreGrab = false
				return
			end
			local worldPos = love.mouse.worldPosition()
			local item = itemClass.getItemAtPosition(worldPos)
			if item then
				player:grab(item)
			-- else
			-- 	player:use()
			end
		end
	end)
	game.onUpdate:Connect(function(dt)
		player:update(dt)
		updateStatsFrames(player, statList)

		dropButton.Visible = not not (player.Data.hand)
		swapButton.Visible = not not (player.Data.hand or player.Data.back)
	end)
end
newPCController = function(player)
	local statList = createStats(player)
	statList.Size = Udim2.new(0.2,0, 0.2,0)
	statList.Position = Udim2.new(0,0, 0,0)
	statList.AnchorPoint = Vector2.new(0, 0)
	statList:draw()
	
	local statGrid = Instance.new("GridLayout")
	statGrid.CellSize = Udim2.new(1, -6, 1/3, -6)
	statGrid.CellPadding = Udim2.new(0, 6, 0, 6)
	statGrid:apply(statList)
	
	game.inputBegan:Connect(function(key)
		if key.KeyCode == Enum.KeyCode.Q then
			player:swap()
		end
		if key.KeyCode == Enum.KeyCode.MouseButton1 then
			player:use()
		end
		if key.KeyCode == Enum.KeyCode.E then
			player:drop()
		end
				
		if key.KeyCode == Enum.KeyCode.F then
			local worldPos = love.mouse.worldPosition()
			local item = itemClass.getItemAtPosition(worldPos)
			if item then
				player:grab(item)
			end
		end
	end)
	
	game.onUpdate:Connect(function(dt)
		player:handleUserInput()
		
		player:update(dt)
		updateStatsFrames(player, statList)
		
		local mousePos = love.mouse.worldPosition()
		player.CFrame = CFrame.lookAt(player.CFrame.X, player.CFrame.Y, mousePos.X, mousePos.Y)
	end)
end