game = Instance.new("Game")

-- local itemData, renderData = nil, nil
-- local itemClass, resourceClass, playerClass = nil,nil,nil

local player
local swapButton



function saveWorld()
	local dataToSave = {
		resources = {},
		items = {},
	}

	for _, reso in pairs(resourceClass.getItems()) do
		dataToSave.resources[#dataToSave.resources+1] = {
			Name = reso.Name,
			Health = reso.Health,
			X = reso.Position.X,
			Y = reso.Position.Y,
		}
	end
	for _, item in pairs(itemClass.getItems():collect()) do
		dataToSave.items[#dataToSave.items+1] = {
			Name = item.Name,
			X = item.Position.X,
			Y = item.Position.Y,
		}
	end
	Datastore:SetAsync("World1", dataToSave)
end

function loadWorld()
	local worldData = Datastore:GetAsync("World1")
	if worldData then
		for _, v in ipairs(worldData.resources) do
			local tree = resourceClass.new(v.Name, v.X, v.Y)
			tree.Health = v.Health
			tree:showHealth()
		end
		for _, v in ipairs(worldData.items) do
			local item = itemClass.new(v.Name, v.X, v.Y)
		end
	end
end

game.onLoad:Connect(function()
	containerClass = require(path.."ContainerClass")
	itemData = require(path.."ItemData/main")
	renderData = require(path.."Drawing")
	itemClass = require(path.."ItemClass")
	resourceClass = require(path.."ResourceClass")
	playerClass = require(path.."PlayerClass")
	physics = require(path.."Physics")
	defaultData = require(path.."DefaultData")
		require(path.."PlayerController")
	-- playerStore = Datastore:GetDataStore("BoogaPlayerData")
	-- worldStore = Datastore:GetDataStore("BoogaWorldData")
	game.Camera.CFrame = CFrame.new(200,200)
	game:setTitle("Booga")
	game:setSize(Vector2.new(400,400))
	game:setBackgroundColor(Color.new(0.05,0.25,0))

	loadWorld()
		
	player = playerClass.new(--[["Player1"]])
	physics:addObject(player, player.Size, false)
		
	newMobileController(player)
	-- newPCController(player)
	spawnableResources = {"Rock", "Tree"}
end)

game.onClose:Connect(function()
	saveWorld()
end)

game.onUpdate:Connect(function(dt)
	-- if math.random() < 0.1 then
	-- 	local point = player.CFrame.Position+Vector2.new(math.random(-game.Size.X/2,game.Size.X/2),math.random(-game.Size.Y/2,game.Size.Y/2))
	-- 	local resourceName = spawnableResources[math.random(1,#spawnableResources)]
	-- 	local can = true
	-- 	if AABB(point,itemData[resourceName].hitbox, player.CFrame.Position, player.Size) then
	-- 		can = false
	-- 	end
	-- 	if can then
	-- 		for _, v in ipairs(resourceClass.getItems()) do
	-- 			if AABB(point,itemData[resourceName].hitbox,v.Position,itemData[v.Name].hitbox) then
	-- 				can = false
	-- 				break
	-- 			end
	-- 		end
	-- 	end
	-- 	if can then
	-- 		resourceClass.new(resourceName, point.X, point.Y)
	-- 	end
	-- end
	physics:physicsStep(dt)
	game.Camera.CFrame = CFrame.new(player.CFrame.X, player.CFrame.Y)
end,10)

game.onDraw:Connect(function(dt)
	local renderPoint,renderSize = game.Camera.CFrame.Position, game.Size
	for _, item in ipairs(resourceClass.getItems()) do
		if AABB(item.Position, itemData[item.Name].hitbox, renderPoint,renderSize) then
			item:draw()
		end
	end
	for _, item in ipairs(itemClass.getItems():collect()) do
		if AABB(item.Position, itemData[item.Name].hitbox, renderPoint,renderSize) then
			item:draw()
		end
	end
	player:draw()
end)

return game