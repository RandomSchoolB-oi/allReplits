local Melee = {}
Melee.__index = Melee

Melee.new = function(core)
	local self = setmetatable({}, module)

	self.core = core
	
	return self
end

function Melee:input(inputName)
	if inputName == "begin" then
		
	elseif inputName == "end" then
		
	end
end

function Melee:step(dt)

end

return Melee