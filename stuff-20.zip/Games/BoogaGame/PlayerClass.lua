
local module = {}

module.__index = function(self, i)
	if i == "Position" then
		return rawget(self,"CFrame").Position
	end

	local moduleHas = rawget(module, i)
	if moduleHas then return moduleHas end
	
	return rawget(self,i)
end
module.__newindex = function(self, i,v)
	if i == "Position" then
		rawset(self, "CFrame", CFrame.new(v.X, v.Y, self.CFrame.Rotation))
		return
	end
	
	rawset(self, i, v)
end

module.new = function(saveFile)
	local self = setmetatable({}, module)

	self.CFrame = CFrame.new(100,300)
	self.Size = Vector2.new(100,100)
	self.Data = defaultData.new()
	
	self.SwingOffset = math.pi/4
	
	self.BackOffset = CFrame.new(0,50,math.pi/2)
	self.HandOffset = CFrame.new(0, 0, math.pi/4)

	self.Walkspeed = 100
	self.MoveDirection = Vector2.new(0,0)

	self._normalSwingOffset = self.SwingOffset

	if saveFile then
		self.canSave = true
		self.saveFile = saveFile

		self:loadData()
	else
		self.canSave = false
	end

	game.onClose:Connect(function()
		self:saveData()
	end)
		
	return self
end

function module:saveData()
	if not self.canSave then return end
	local dataToSave = {
		Data = table.copy(self.Data),
		Position = self.CFrame.Position,
	}

	dataToSave.Data.temporaryData = nil
	
	Datastore:SetAsync(self.saveFile, dataToSave)
end

function module:loadData()
	if not self.canSave then return end
	local savedData = Datastore:GetAsync(self.saveFile)
	if savedData then
		setmetatable(savedData.Data.inventory, containerClass)
		setmetatable(savedData.Data.toolbar, containerClass)
		
		savedData.Data.temporaryData = defaultData.new().temporaryData
		self.Data = savedData.Data
		self.CFrame = CFrame.new(savedData.Position.X, savedData.Position.Y, 0)
	end
end

function module:drop()
	if self.Data.hand then
		local pos = self.CFrame * CFrame.new(0, -100)

		itemClass.new(self.Data.hand, pos.X,pos.Y)
		self.Data.hand = nil
		self:resetToolData()
	end
end

function module:grab(item)
	self:drop()
	
	self.Data.hand = item.Name
	self:resetToolData()
	item:destroy()
end

function module:resetToolData()
	self.SwingOffset = self._normalSwingOffset
	self.HandOffset.Rotation = self.SwingOffset
	self.Data.temporaryData.lastSwing = -999
end

function module:swap()
	self:resetToolData()
	self.Data.back, self.Data.hand = self.Data.hand, self.Data.back
end

function module:canSwing()
	local tool, toolInfo = self:getTool()
	if toolInfo and toolInfo.swingSpeed then
		if et - self.Data.temporaryData.lastSwing < toolInfo.swingSpeed then 
			return false
		end
		return true
	end
	return false
end

function module:getDamageToResource(resourceName)
	local resourceInfo = itemData[resourceName]
	local tool, toolInfo = self:getTool()

	return resourceInfo.damageType and toolInfo.damages[resourceInfo.damageType] or 0
end

function module:use()
	local tool, toolInfo = self:getTool()
	if not toolInfo then return end
	if not self:canSwing() then return end
	if self.ignoreSwing then self.ignoreSwing = nil return end
	local itemType = toolInfo.itemType
	
	self.Data.temporaryData.lastSwing = et

	if itemType == "food" then
		self.Data.hand = nil
		for stat, amount in pairs(toolInfo.nourishment) do
			self:changeStat(stat, amount)
		end
		self:resetToolData()
	elseif itemType == "tool" then
		self.SwingOffset = -self.SwingOffset
		self.immunityTime = 0
	end
end

function module:degradeStats(dt)
	self:changeStat("food", -dt)
	self:changeStat("water", -dt)
	
	if self.Data.temporaryData.stats.food <= 0 then
		self:changeStat("health",-dt)
	end
	if self.Data.temporaryData.stats.water <= 0 then
		self:changeStat("health",-dt)
	end

	-- if self.Data.temporaryData.stats.health <= 0 then
	-- 	love.window.close()
	-- end
end

function module:getTool()
    local tool = self.Data.hand
	local toolInfo = tool and itemData[tool]
	return tool, toolInfo
end

function module:update(dt)
	self:degradeStats(dt)
	self.CFrame = self.CFrame + self.MoveDirection * self.Walkspeed * dt

	local swinging = not self:canSwing()
	local tool, toolInfo = self:getTool()

	if swinging and toolInfo and toolInfo.hitbox then
		local cf = self:getHandCFrame()
		local scaledBox = self:getHitboxScaled(cf)
		local center = (cf * CFrame.new(0,-toolInfo.hitbox.Y/2)).Position
		if not toolInfo.immunityTime then return end
		for _, reso in pairs(resourceClass.getItems()) do
			local resoSize = itemData[reso.Name].hitbox
			local resoPos = reso.Position

			local isIntersecting, normal, depth = AABB(center, scaledBox, resoPos, resoSize)
			
			if isIntersecting then
				if et - reso.lastHurt > toolInfo.immunityTime then
					reso:damage(self:getDamageToResource(reso.Name))
				end
			end
		end
	end
	
	self.HandOffset.Rotation = lerp(self.HandOffset.Rotation, self.SwingOffset, clamp(dt * 15, 0, 1))
end

function module:changeStat(statName, amount, max)
	self.Data.temporaryData.stats[statName] = clamp(self.Data.temporaryData.stats[statName] + amount, 0, max or 100)
end

function module:getHandCFrame()
	return (self.CFrame * self.HandOffset) * CFrame.new(0, -100/2, 0)
end

function module:getHitboxScaled(from)
	local tool, toolInfo = self:getTool()
	if not from then
		from = self:getHandCFrame()
	end

	if tool and toolInfo.hitbox and from then
		local hb = toolInfo.hitbox
		local cf = from * CFrame.new(0, -hb.Y/2)

		local tl = cf.Position - Vector2.one
		local br = cf.Position + Vector2.one
		
		local points = {
			cf * CFrame.new(hb.X/2, hb.Y/2),
			cf * CFrame.new(-hb.X/2, hb.Y/2),
			cf * CFrame.new(hb.X/2, -hb.Y/2),
			cf * CFrame.new(-hb.X/2, -hb.Y/2),
		}

		for _, point in pairs(points) do
			if point.X < tl.X then
				tl.X = point.X
			end
			if point.Y < tl.Y then
				tl.Y = point.Y
			end
			
			if point.X > br.X then
				br.X = point.X
			end
			if point.Y > br.Y then
				br.Y = point.Y
			end
		end
		
		return br-tl
	end
end

function module:draw()
	local offset = -self.CFrame.Position
	Color.white:apply(0.75)
	ellipse(self.CFrame.Position, self.Size, Vector2.new(0.5, 0.5), self.CFrame.R)

	local tool, toolInfo = self:getTool()
	
	if tool then
		local hb = itemData[self.Data.hand].hitbox
		local cf = self:getHandCFrame() * CFrame.new(0, -hb.Y/2)
		renderData[toolInfo.image or tool](cf, hb)

		-- Color.new(1,1,1,0.5):apply()
		-- rectCF(cf, toolInfo.hitbox, Vector2.new(0.5, 1))
		
		-- local scaledBox = self:getHitboxScaled(cf)
		-- local center = cf * CFrame.new(0,-toolInfo.hitbox.Y/2)
		-- rectCF(CFrame.new(center.X, center.Y), scaledBox, Vector2.mid)
		
	end
	if self.Data.back then
		local info = itemData[self.Data.back]
		local cf = (self.CFrame * self.BackOffset)
		renderData[info.image or self.Data.back](cf, itemData[self.Data.back].hitbox)
	end
end

-- player player functions

function module:handleUserInput()
	local dir = Vector2.new(0, 0)
	if game:isKeyDown(Enum.KeyCode.W) then
		dir.Y = dir.Y - 1
	end
	if game:isKeyDown(Enum.KeyCode.S) then
		dir.Y = dir.Y + 1
	end
	if game:isKeyDown(Enum.KeyCode.A) then
		dir.X = dir.X - 1
	end
	if game:isKeyDown(Enum.KeyCode.D) then
		dir.X = dir.X + 1
	end
	if dir.Magnitude > 0.01 then
		self.MoveDirection = dir.Unit
	else
		self.MoveDirection = Vector2.new(0, 0)
	end
	dir = nil
end

return module