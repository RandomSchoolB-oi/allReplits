local module = {}

local images = {}
for _, file in ipairs(love.filesystem.getDirectoryItems(path.."Images")) do
	images[file] = love.graphics.newImage(path.."Images/"..file)
end

local imageDrawing = {}

setmetatable(module, {__index = function(_, i)
	if imageDrawing[i] then
		return imageDrawing[i]
	end

	local f
			
	if not images[i] then
		f = function(cf,size)
			Color.white:apply()
			rectCF(cf,size,Vector2.mid)
		end
	else		
		f = function(cf, size)
			Color.white:apply()
			imageCF(cf, size, Vector2.mid, images[i])
		end
	end
	imageDrawing[i] = f

	return f
end})

return module