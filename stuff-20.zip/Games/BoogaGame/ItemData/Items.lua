local module = {
	["Stone"] = {
		image = "Rock.png",
		itemType = "object",
		hitbox = Vector2.new(30,30),
	},
}

return module