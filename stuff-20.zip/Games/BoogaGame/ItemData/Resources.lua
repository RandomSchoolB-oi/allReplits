local module = {
	["Tree"] = {
		image = "Tree.png",
		itemType = "resource",
		health = 15,
		hitbox = Vector2.new(100, 100),
		damageType = "wood",
		drops = {
			["Apple"] = 3,
		},
	},
	["Rock"] = {
		image = "Rock.png",
		itemType = "resource",
		health = 30,
		hitbox = Vector2.new(100, 100),
		damageType = "stone",
		drops = {
			["Stone"] = 3,
		},
	},
}

return module