local module = {
	["Iron Pickaxe"] = {
		image = "Iron Pickaxe.png",
		itemType = "tool",
		swingSpeed = 1/2,
		immunityTime = 1/3,
		swingLevel = 1,
		damages = {stone = 5},
		hitbox = Vector2.new(80,80),
	},
	["Iron Axe"] = {
		image = "Iron Axe.png",
		itemType = "tool",
		swingSpeed = 1/2,
		immunityTime = 1/3,
		swingLevel = 1,
		damages = {wood = 5},
		hitbox = Vector2.new(80,80),
	},
	["Iron Sword"] = {
		image = "Iron Sword.png",
		itemType = "tool",
		swingSpeed = 1/2,
		immunityTime = 1/3,
		damages = {flesh = 7},
		hitbox = Vector2.new(30,100),
	},
}

return module