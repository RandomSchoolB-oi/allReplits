local module = {
	["Apple"] = {
		itemType = "food",
		swingSpeed = 1/3,
		hitbox = Vector2.new(30,30),
		nourishment = {
			water = 2,
			health = 3,
			food = 5,
		},
		image = "Apple.png",
	},
}

return module