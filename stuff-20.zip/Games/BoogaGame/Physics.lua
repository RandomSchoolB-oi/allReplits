local module = {}

local objects = {}

function module:addObject(reference, size, anchored)
	objects[#objects+1] = {object = reference, size = size, anchored = anchored}
end

function module:removeObject(reference)
	for i, part in pairs(objects) do
		if part.object == reference then
			table.remove(objects, i)
			break
		end
	end
end

function module:physicsStep(dt)
	for i = 1, #objects do
		for j = i+1, #objects do
			local this,next = objects[i], objects[j]
			if not (this.anchored and next.anchored) then
				--RCD, AABB
				local colliding, dir, depth = AABB(
					this.object.Position, this.size, 
					next.object.Position, next.size)
				if colliding then
					-- depth = depth * dt
					-- depth = depth/2
					if this.anchored then
						next.object.Position = next.object.Position + dir * depth
					elseif next.anchored then
						this.object.Position = this.object.Position + dir * depth
					else
						this.object.Position = this.object.Position + dir * -depth/2
						next.object.Position = next.object.Position + dir * depth/2
					end
				end
			end
		end
	end
end

return module