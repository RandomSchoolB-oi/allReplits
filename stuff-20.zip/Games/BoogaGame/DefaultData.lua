local module = {}

module.new = function()
	local blankData = {
		back = "Iron Sword",
		hand = "Iron Pickaxe",
		toolbar = {
			{name = "Iron Sword", quantity = 1}
		},
		inventory = containerClass.new(3^2),

		temporaryData = {
			lastSwing = -1000,
			lastHurt = -1000,
			stats = {
				food = 100,
				health = 100,
				water = 100,
			},
		},
	}

	blankData.inventory[1] = {name = "Apple",quantity = 16}
	blankData.inventory[2] = {name = "Apple",quantity = 16}
	return blankData
end

return module