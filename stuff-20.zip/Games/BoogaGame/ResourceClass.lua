local module = {}
module.__index = module

local resources = {}

module.new = function(itemName, x,y)
	local self = setmetatable({}, module)
	local info = itemData[itemName]

	self.Name = itemName
	self.Position = Vector2.new(x,y)
	self.Health = info.health
	self.lastHurt = -10
	self.Damaged = Instance.new("Signal")
	self.Mined = Instance.new("Signal")

	local healthbar = Instance.new("Frame", true)
	local slider = Instance.new("Frame")

	healthbar.Size = Udim2.new(0, 100, 0, 15)
	healthbar.BackgroundColor = Color.new(1, 0.2, 0.2, 1)
	healthbar.AnchorPoint = Vector2.new(0.5, 1)
	healthbar.Position = Udim2.new(0.5, 0, 1, 20)
	slider.Parent = healthbar
	slider.Size = Udim2.new(0.5, 0, 1, 0)
	slider.Name = "Slider"
	slider.NormalColor = Color.fromRGB(170,255,0)
	slider.HurtColor = Color.white
	slider.BackgroundColor = slider.NormalColor
	self.gui = healthbar
	game:removeObject(healthbar)
	
	resources[#resources+1] = self
	
	physics:addObject(self, itemData[itemName].hitbox, true)

	self:showHealth()

	local c c = self.Mined:Connect(function()
		for dropName, dropAmount in pairs(itemData[self.Name].drops) do
			for _ = 1, dropAmount do
				itemClass.new(dropName, self.Position.X, self.Position.Y, 60*5, true)
			end
		end
		c:Disconnect()
		c = nil
	end)
	
	return self
end

function module:remove()
	self.gui:destroy()
	table.remove(resources, table.find(resources, self))
	physics:removeObject(self)
end

function module:damage(amount)
	if self.Health <= 0 then return end
	if amount <= 0 then return end
	
	self.Health = self.Health - amount
	self.lastHurt = et
	self:showHealth()
	self.Damaged:Run(amount)
	
	if self.Health <= 0 then
		self.Mined:Run()
		self:remove()
	end
end

function module:showHealth()
	local info = itemData[self.Name]
	self.gui.Slider.Size = Udim2.new(self.Health/info.health, 0, 1, 0)
end

function module:draw()
	local info = itemData[self.Name]
	local hb = info.hitbox
	local cf = CFrame.new(self.Position.X, self.Position.Y, 0)
	renderData[info.image or self.Name](cf, hb)

	if et-self.lastHurt < 1.5 then
		local a = clamp((et - self.lastHurt)*4, 0, 1)
		local slider = self.gui.Slider
		local nc,hc = slider.NormalColor, slider.HurtColor
		
		self.gui.Slider.BackgroundColor = hc:Lerp(nc, a)
		self.gui:draw(cf.Position, hb, Vector2.mid)
	end
end

function module.getItems()
	return resources
end

return module