local module = {}
module.__index = module

module.new = function(slots)
	local self = setmetatable({}, module)
	for i = 1, slots do
		self[i] = {}
	end
	return self
end

function module:swap(index, otherContainer, otherIndex)
	self[index], otherContainer[otherIndex] = otherContainer[otherIndex], self[index]
end

function module:createGui(list, dimentions)
	local function updateFrames()
		for _, frame in ipairs(list:getChildren()) do
			local i = tonumber(frame.Name)
			if i then
				local item = self[i]
				local itemInfo = item and item.name and itemData[item.name]

				if itemInfo then
					-- frame.Text = item.name
					frame.Image = path.."Images/"..itemInfo.image
				else
					-- frame.Text = ""
					frame.Image = nil
				end
			end
		end
	end
	
	for index, item in ipairs(self) do
		local itemFrame = Instance.new("Button")
		itemFrame.Name = tostring(index)
		itemFrame.Parent = list
	end
	
	local grid = Instance.new("GridLayout")
	grid.CellSize = Udim2.new(1/dimentions.X, -6, 1/dimentions.Y, -6)
	grid.CellPadding = Udim2.new(0, 6, 0, 6)
	grid:apply(list)

	updateFrames()

	return {
		updateFrames = updateFrames,
	}
end

function module:drop(index, amount, position)
	local item = self[index]
	local itemQuantity = item.quantity or 1
	for i = 1, math.clamp(amount or itemQuantity, 0, itemQuantity) do
		itemClass.new(item.name, position.X, position.Y)
	end
	self[index] = {}
end

function module:getAmount(itemName)
	local quantity = 0
	for index, item in ipairs(self) do
		if item.name == itemName then
			quantity = quantity + (item.quantity or 1)
		end
	end
	return quantity
end

function module:takeItem(itemName, amount)
	for index, item in ipairs(self) do
		if item.name == itemName and amount > 0 then
			local a = clamp(amount, 0, item.quantity)
			item.quantity = item.quantity - a
			amount = amount - a
		end
	end
end

return module