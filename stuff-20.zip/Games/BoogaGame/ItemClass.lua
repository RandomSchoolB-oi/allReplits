local module = {}
module.__index = module

local items = Instance.new("Stack")

module.new = function(itemName, x,y, gc, variation)
	local self = setmetatable({}, module)

	if variation then
		x = x + math.random(-50, 50)
		y = y + math.random(-50, 50)
	end
	
	self.Name = itemName
	self.Position = Vector2.new(x,y)

	items:push(self, gc or 60*5)
	
	return self
end

function module:destroy()
	items:pop(self,true)
end

function module.getItemAtPosition(pos)
	local closest, closestDist = nil, 30
	for _, item in ipairs(items:collect()) do
		local dist = (pos - item.Position).Magnitude
		if dist < closestDist then
			closest, closestDist = item, dist
		end
	end
	return closest, closestDist
end

function module:draw()
	local info = itemData[self.Name]
	renderData[info.image or self.Name](CFrame.new(self.Position.X, self.Position.Y, 0), itemData[self.Name].hitbox)
end

function module.getItems()
	return items
end


return module