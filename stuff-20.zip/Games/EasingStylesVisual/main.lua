game = Instance.new("Game")

local frame
local points = {}

local maxStyles = 0
local maxDirections = 0

local cellSize
local padding = Vector2.new(25,75)
local offset = Vector2.new(0, 0)
game.onLoad:Connect(function()
	game:setTitle("Test")
	game:setSize(Vector2.new(100*8,100*3))
	game:setBackgroundColor(Color.black)

		
	local steps = 20
	for _directionName, dir in pairs(Enum.EasingDirection) do
		points[dir] = {}
		maxDirections = maxDirections + 1
		for _styleName, style in pairs(Enum.EasingStyle) do
			points[dir][style] = {}
			maxStyles = maxStyles + 1
			for i = 0, 1, 1/steps do
				local x = i
				local y = flip(CalcEasing(i, style, dir) or 0)

				points[dir][style][#points[dir][style]+1] = {x,y}
			end
			points[dir][style].style = love.graphics.newText(love.graphics.newFont(32, "normal"), _styleName)
			points[dir][style].dir = love.graphics.newText(love.graphics.newFont(32, "normal"), _directionName)
		end
	end

	cellSize = Vector2.new(1/(maxStyles/maxDirections) * game.Size.X, 1/maxDirections * game.Size.Y)
end)

game.onUpdate:Connect(function(dt)
	local speed = 100 * dt
		
	-- if game:isKeyDown(Enum.KeyCode.W) then
	-- 	offset.Y = offset.Y + speed
	-- elseif game:isKeyDown(Enum.KeyCode.S) then
	-- 	offset.Y = offset.Y - speed
	-- end
		
	if game:isKeyDown(Enum.KeyCode.A) then
		offset.X = offset.X + speed
	elseif game:isKeyDown(Enum.KeyCode.D) then
		offset.X = offset.X - speed
	end
end)

game.onDraw:Connect(function()
	love.graphics.push()
	love.graphics.translate(-game.Size.X/2 + offset.X, -game.Size.Y/2 + offset.Y)
	local a = et/2 % 1
		
	local w,h = cellSize()
	local yi = 0
	for dir, list in pairs(points) do
		local xi = 0
		for style, pointsList in pairs(list) do
			Color.red:apply()
			love.graphics.rectangle("line",xi,yi,w,h)
			Color.white:apply()
			text(Vector2.new(xi,yi), Vector2.new(w, 25), Vector2.new(0,0), 0, pointsList.style, false)
			text(Vector2.new(xi,yi+h), Vector2.new(w, 25), Vector2.new(0,1), 0, pointsList.dir, false)
			for i = 1, #pointsList-1 do
				local this,next = pointsList[i], pointsList[i+1]
				love.graphics.line(
					xi + padding.X/2 + (w - padding.X) * this[1], 
					yi + padding.Y/2 + (h - padding.Y) * this[2], 
					
					xi + padding.X/2 + (w - padding.X) * next[1], 
					yi + padding.Y/2 + (h - padding.Y) * next[2]
				)		
			end
			love.graphics.circle("fill", 
				xi + padding.X/2 + a * (w - padding.X),
				yi + padding.Y/2 + flip(CalcEasing(a, style, dir)) * (h - padding.Y), 
				5)
			xi = xi + w
		end
		yi = yi + h
	end
	love.graphics.pop()
end)

return game