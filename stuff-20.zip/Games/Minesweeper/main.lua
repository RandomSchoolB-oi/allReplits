game = Instance.new("Game")

local board = {}
local size = Vector2.new(6,6)

local lastLose = -10
local cellClass = {}
function cellClass:forNeighbors(callback)
	for _x = -1,1,1 do
		local x = _x + self.x
		if board[x] then
			for _y = -1,1,1 do
				local y = _y + self.y
				local cell = board[x][y]
				if cell then
					callback(x,y,cell)
				end
			end
		end
	end
end

function cellClass:calcBombs()
	local bombCount = 0
	self:forNeighbors(function(x,y, cell)
		if cell.bomb then 
			bombCount = bombCount + 1 
		end
	end)
	return bombCount
end

function cellClass:click()
	if self.clicked then return end
	self.clicked = true
	if self.bomb then
		print("you lose")
		lastLose = et
		self.frame.BackgroundColor = Color.red
	else
		local has = self:calcBombs()
		if has > 0 then
			self.frame.Text = tostring(has)
		end
		self.frame.BackgroundColor = Color.new(0.5, 0.5, 0.5)
		self:forNeighbors(function(x,y,cell)
			if cell:calcBombs() <= 0 or has <= 0 then
				cell:click()
			end
		end)
	end
end

local function generateBoard()
	for _, r in pairs(board) do
		for _, cell in pairs(r) do
			cell.frame:destroy()
		end
	end
	for x = 1, size.X do
		board[x] = {}
		for y = 1, size.Y do
			local frame = Instance.new("Button")
			frame.Size = Udim2.new(1/size.X, 0, 1/size.Y, 0)
			frame.Position = Udim2.new((x-1)/size.X, 0, (y-1)/size.Y), 0
			
			local isBomb = math.random() < 0.1
			
			local cell = setmetatable({
				frame = frame,
				bomb = isBomb,
				x = x,
				y = y,
				clicked = false,
			}, {__index = cellClass})
			
			frame.Activated:Connect(function()
				if lastLose then return end
				cell:click()
				for _, r in pairs(board) do
					for _ , cell in pairs(r) do
						if not cell.bomb then
							if not cell.clicked then return end
						end
					end
				end
				-- all non bombs clicked
				print("you won")
				lastLose = et - 2
			end)
			
			board[x][y] = cell
		end
	end
end

game.onUpdate:Connect(function(dt)
	if lastLose then
		if et - lastLose > 1 then
			generateBoard()
			lastLose = nil
		end
	end
end)

game.onLoad:Connect(function()
	math.randomseed(os.time())
	game:setScreenSize(Vector2.new(400, 400))
	game:setBackground(Color.black)
	game:setTitle("Minesweeper")
end)


return game