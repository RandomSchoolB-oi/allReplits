local module = {}

local objects = {}

local angle = 0
local rot = math.rad(-angle)
local magnitude = 200
module.Gravity = Vector2.new(math.sin(rot), math.cos(rot)) * magnitude

function module:addObject(reference)
	objects[#objects+1] = reference
end

function module:removeObject(reference)
	for i, part in pairs(objects) do
		if part == reference then
			table.remove(objects, i)
			break
		end
	end
end

function module:physicsStep(dt)
	for i = 1, #objects do
		for j = i+1, #objects do
			local this,next = objects[i], objects[j]
			if (this.CanCollide and next.CanCollide) then
				--RCD, AABB
				local colliding, dir, depth = AABB(
					this.Position, this.Size, 
					next.Position, next.Size)
				if colliding then
					local add = dir * depth
					if this.Anchored and next.Anchored then
						-- dont move
						this.Velocity.X = 0
						this.Velocity.Y = 0
						next.Velocity.X = 0
						next.Velocity.Y = 0
					elseif this.Anchored then
						this.Velocity.X = 0
						this.Velocity.Y = 0
						next.Position = next.Position - add
					elseif next.Anchored then
						next.Velocity.X = 0
						next.Velocity.Y = 0
						this.Position = this.Position - add
					else
						add = add/2
						this.Position = this.Position - add
						next.Position = next.Position + add
					end
				end
			end
		end
	end
end

return module