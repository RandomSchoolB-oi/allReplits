local PVObject = {}
PVObject.__index = PVObject

local physics = require(path.."Physics")

local physicObjects = {}

local serial = 0

PVObject.new = function()
	local self = setmetatable({}, PVObject)
	self.Size = Vector2.new(25, 25)
	self.Position = Vector2.new(0, 0)
	self.Color = Color.new(0.5, 0.5, 0.5)
	self.Velocity = Vector2.new(0, 0)
	self.ID = serial

	self.Bounce = 0.25 -- % of -(velocity) to keep when hitting another physicsObject
	self.Drag = Vector2.new(0.05, 0.05)

	self.Anchored = false
	self.CanCollide = true

	self.Touching = {}
	self.Touched = Instance.new("Signal")
	self.TouchEnded = Instance.new("Signal")
	
	physicObjects[#physicObjects+1] = self
	physics:addObject(self)

	serial = serial + 1
	
	return self
end

function PVObject:IsGrounded()
	local grounded = false
	local downPos = self.Position + physics.Gravity.Unit
	
	for i, v in ipairs(physicObjects) do
		if v ~= self then
			if AABB(v.Position, v.Size, downPos, self.Size) then
				grounded = true
				break
			end
		end
	end
	
	return grounded
end

function PVObject:Colliding(dir)
	local newX = self.Position + Vector2.new(dir.X, 0)
	local newY = self.Position + Vector2.new(0, dir.Y)
	if self.CanCollide then
		for i, v in ipairs(physicObjects) do
			if v ~= self and v.CanCollide then
				local intersectingX, normX, depthX = AABB(v.Position, v.Size, newX, self.Size)
				local intersectingY, normY, depthY = AABB(v.Position, v.Size, newY, self.Size)
				if intersectingX or intersectingY then
					return true, intersectingX, intersectingY
				end
			end
		end
	end
end

function PVObject:Update(dt)
	-- do collision stuff
	if not self.Anchored then
		self.Velocity = self.Velocity + physics.Gravity * dt

		local newX = self.Position + Vector2.new(self.Velocity.X * dt, 0)
		local newY = self.Position + Vector2.new(0, self.Velocity.Y * dt)
		if self.CanCollide then
			for i, v in ipairs(physicObjects) do
				if v ~= self and v.CanCollide then
					local intersectingX, normX, depthX = AABB(v.Position, v.Size, newX, self.Size)
					local intersectingY, normY, depthY = AABB(v.Position, v.Size, newY, self.Size)
					local touching = intersectingX or intersectingY
					if not self.Anchored then
						if intersectingX then
							local velX = self.Velocity.X
							
							self.Velocity.X =-(velX * self.Bounce)
							v.Velocity.X	= (velX * v.Bounce)
						end
						if intersectingY then
							local velY = self.Velocity.Y
							
							self.Velocity.Y =-(velY * self.Bounce)
							v.Velocity.Y	= (velY * v.Bounce)
						end
					end
					if not touching and self.Touching[v.ID] then
						self.Touching[v.ID] = nil
						self.TouchEnded:Run(v)
					elseif touching and not self.Touching[v.ID] then
						self.Touching[v.ID] = true
						self.Touched:Run(v)
					end
					if touching then
						-- break
					end
				end
			end
			
			self.Position = self.Position + self.Velocity * dt
		end

		local vel = self.Velocity
		local drag = self.Drag
		-- clamp and apply drag
		vel.X = clamp(vel.X - (sign(vel.X) * drag.X), -1000, 1000)
		vel.Y = clamp(vel.Y - (sign(vel.Y) * drag.Y), -1000, 1000)
	end
end

function PVObject:Draw()
	self.Color:apply()
	rect(self.Position, self.Size, Vector2.mid, 0)
	
	-- Color.white:apply()
	-- local p1 = self.Position
	-- local p2 = p1 + self.Velocity
	-- love.graphics.line(p1.X, p1.Y, p2.X, p2.Y)
end

game.onUpdate:Connect(function(dt)
	for _, object in ipairs(physicObjects) do
		object:Update(dt)
	end
	physics:physicsStep(dt)
end)

game.onDraw:Connect(function()
	for _, object in ipairs(physicObjects) do
		object:Draw()
	end
end)

return PVObject