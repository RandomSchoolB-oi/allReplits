game = Instance.new("Game")




game.onLoad:Connect(function()
	game:setScreenSize(Vector2.new(500, 400))
	game:setBackground(Color.black)
	game:setTitle(" ")
		
	local partClass = require(path.."PhysicsObject")
	local playerClass = require(path.."Player")
	local physics = require(path.."Physics")

	local keys = {
		["Player1"] = {
			Left = Enum.KeyCode.A,
			Right = Enum.KeyCode.D,
			Jump = Enum.KeyCode.Space,
		},
		-- ["Player2"] = {
		-- 	Left = Enum.KeyCode.D,
		-- 	Right = Enum.KeyCode.A,
		-- 	Jump = Enum.KeyCode.S,
		-- },
	}
	local player = playerClass.new(keys.Player1)
		player.Position = Vector2.new(-25, -100)
		player.Drag = Vector2.new(0.25, 0.05)
		player.Bounce = 0
		
	local box = partClass.new()
		box.Position = Vector2.new(-25, -100)
		box.Drag = Vector2.new(0.25, 0.05)
		box.Bounce = 1
		
	local wallWidth = 1000

	local pad = wallWidth/2 - 25
	local wallCorner = wallWidth*2
	local floor = partClass.new()
		floor.Position = Vector2.new(0, game.Size.Y/2+pad)
		floor.Size = Vector2.new(game.Size.X+wallCorner,wallWidth)
		floor.Color = Color.red
		floor.Anchored = true
		
	local roof = partClass.new()
		roof.Position = Vector2.new(0, -game.Size.Y/2-pad)
		roof.Size = Vector2.new(game.Size.X+wallCorner,wallWidth)
		roof.Color = Color.blue
		roof.Anchored = true

	local lw = partClass.new()
		lw.Position = Vector2.new(-game.Size.X/2-pad, 0)
		lw.Size = Vector2.new(wallWidth, game.Size.Y+wallCorner)
		lw.Anchored = true
	local rw = partClass.new()
		rw.Position = Vector2.new(game.Size.X/2+pad, 0)
		rw.Size = Vector2.new(wallWidth, game.Size.Y+wallCorner)
		rw.Anchored = true

		local newPlatform = function(position)
			local platform = partClass.new()
				platform.Position = position
				platform.Size = Vector2.new(99.5, 25)
				platform.Anchored = true
			return platform
		end

	-- newPlatform(Vector2.new(-150, 100))
	-- newPlatform(Vector2.new(150, 100))
	-- newPlatform(Vector2.new(150, -100))
	-- newPlatform(Vector2.new(-150, -100))
	-- newPlatform(Vector2.new(0, 0))


	game.inputBegan:Connect(function(input)
		if input.KeyCode == Enum.KeyCode.W then
			physics.Gravity = -physics.Gravity
			game.Camera.CFrame = game.Camera.CFrame * CFrame.new(0, 0, math.pi)
			player.WalkSpeed = -player.WalkSpeed
			player.JumpPower = -player.JumpPower
		end
	end)

	-- game.inputEnded:Connect(function(input)
	-- end)

	-- game.onClose:Connect(function()
	-- end)
		
	-- game.onUpdate:Connect(function(dt)
		-- game.Camera.CFrame = CFrame.new(player.Position.X, player.Position.Y, game.Camera.CFrame.R)
	-- end)

	-- game.onDraw:Connect(function()
	-- end)
end)

return game