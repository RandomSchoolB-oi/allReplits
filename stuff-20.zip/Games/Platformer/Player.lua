local Player = {}
Player.__index = Player
local BaseClass = require(path.."PhysicsObject")
setmetatable(Player, BaseClass)
local physics = require(path.."Physics")

Player.new = function(keybinds)
	local self = setmetatable(BaseClass.new(), Player)

	self.Bounce = 0
	self.Drag = Vector2.new(0.25, 0)
	self.LastJump = 0
	self.JumpPower = 215
	self.WalkSpeed = 200
	self.Keybinds = keybinds or {
		Left = Enum.KeyCode.A,
		Right = Enum.KeyCode.D,
		Jump = Enum.KeyCode.Space,
	}
	self.MoveDirection = 0
	
	return self
end

function Player:Move(dir, dt)
	-- if not self:IsGrounded() then return end
	self.MoveDirection = clamp(dir, -1, 1)
end
function Player:Jump(bypass, percent)
	local t = os.clock()
	if (t - self.LastJump > 1/10 and self:IsGrounded()) or bypass then
		self.LastJump = t

		self.Velocity = self.Velocity + physics.Gravity.Unit * -(self.JumpPower * clamp(percent or 1,-1,1))
		-- self.Velocity.Y = -self.JumpPower 
	end
end

function Player:HandleUserInput(dt)
	if game:isKeyDown(self.Keybinds.Left) then
		self:Move(-1)
	elseif game:isKeyDown(self.Keybinds.Right) then
		self:Move(1)
	else
		self:Move(0)
	end
	
	if game:isKeyDown(self.Keybinds.Jump) then
		self:Jump()
	end
	
	-- local mouseWorldPos = love.mouse.worldPosition()
	-- local dir = mouseWorldPos - self.Position
	-- self:Move(dir.X/self.WalkSpeed*2)

	-- local mouseSpeed = self.lastMouseY and (self.lastMouseY - dir.Y)/dt
	-- -- print(mouseSpeed)
	-- if self.lastMouseY and mouseSpeed > 2000 then
	-- 	self:Jump(false, mouseSpeed / 8000)
	-- end
	
	-- self.lastMouseY = dir.Y
	
end

function Player:Update(dt)
	local dir = Vector2.new(self.MoveDirection * self.WalkSpeed * dt, 0)
	if not self:Colliding(dir) then
		self.Position = self.Position + dir
	end

	self:HandleUserInput(dt)
	BaseClass.Update(self, dt)
end

return Player