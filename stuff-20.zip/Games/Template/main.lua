game = Instance.new("Game")




game.onLoad:Connect(function()
	game:setScreenSize(Vector2.new(300, 300))
	game:setBackground(Color.black)
	game:setTitle(" ")

	game.inputBegan:Connect(function(input)
	end)

	game.inputEnded:Connect(function(input)
	end)

	game.onClose:Connect(function()
	end)
		
	game.onUpdate:Connect(function(dt)
	end)

	game.onDraw:Connect(function()
	end)
end)

return game