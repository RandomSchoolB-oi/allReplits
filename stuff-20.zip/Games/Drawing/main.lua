game = Instance.new("Game")
local points = {}
local was = false
game.onUpdate:Connect(function(dt)
	local down = game:isKeyDown(Enum.KeyCode.MouseButton1)
	if down or was then
		was = down
		points[#points+1] = love.mouse.position()
	end
end)

game.onDraw:Connect(function()
	Color.white:apply()
	local amt = #points
	if amt > 1 then
		for i = 1, amt - 1 do
			local this, next = points[i], points[i+1]
			love.graphics.line(this.X, this.Y, next.X, next.Y)
		end
	end
end)

game.onLoad:Connect(function()
	game:setScreenSize(Vector2.new(300, 300))
	game:setBackground(Color.black)
	game:setTitle(" ")

	local f = Instance.new("Frame")
	f.Selectable = true
		f.AutoColor = true
	f.Activated:Connect(function()
		f.BackgroundColor = Color.random()
	end)
end)

return game