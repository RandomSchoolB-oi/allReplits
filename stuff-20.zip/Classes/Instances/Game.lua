local module = {}
module.__index = module
local inputObjectClass = require("Classes/Instances/InputObject")



module.new = function ()
    local self = setmetatable({}, module)

	self.onLoad = Instance.new("Signal")
	self.onUpdate = Instance.new("Signal", true)
	self.onDraw = Instance.new("Signal", true)
	self.onClose = Instance.new("Signal")
	self.inputBegan = Instance.new("Signal", true)
	self.inputEnded = Instance.new("Signal", true)
	self.BackgroundColor = Color.black
	self.Size = Vector2.new(400, 400)
	self.Objects = setmetatable({}, indexByName)
	self.Camera = Instance.new("Camera")

	self.Pressing = {}
	
	self.onDraw:Connect(function()
		self.Camera:pop()
		for _, object in ipairs(self.Objects) do
			object:draw()
		end
		self.Camera:push()
	end, 10)
	
    return self
end

function module:setBackground(color)
	if color then
		self.BackgroundColor = color
	end
    love.graphics.setBackgroundColor(self.BackgroundColor())
end
function module:setTitle(title)
	if title then
		self.Title = title
	end
	love.window.setTitle(self.Title or "Untitled Game")
end
function module:setScreenSize(size)
	if size then
		self.Size = size
	end
    love.window.setMode(self.Size())
end
module.setSize = module.setScreenSize
module.setBackgroundColor = module.setBackground

function module:hasObject(object)
	-- for i, v in ipairs(self.Objects) do
	-- 	if v == object then
	-- 		return i,v
	-- 	end
	-- end
	return table.find(self.Objects, object)
end

function module:removeObject(object)
	local hasIndex = self:hasObject(object)
	if hasIndex then
		table.remove(self.Objects, hasIndex)
	end
end

function module:addObject(object)
	local hasIndex = self:hasObject(object)
	if hasIndex then return end
	self.Objects[#self.Objects+1] = object
end

function module:input(key, inputType, x, y)
	local index = inputObjectClass.getIndex(key, inputType)
	if not index or not Enum.KeyCode[index] then return end
	self.Pressing[Enum.KeyCode[index]] = true
	local object = inputObjectClass.create(key, inputType, x,y)
	self.inputBegan:Run(object)
end
function module:releaseKey(key, inputType, x, y)
	local index = inputObjectClass.getIndex(key, inputType)
	if not index or not Enum.KeyCode[index] then return end
	self.Pressing[Enum.KeyCode[index]] = nil
	local object = inputObjectClass.create(key, inputType, x,y)
	self.inputEnded:Run(object)
end
function module:isKeyDown(key)
	return not not self.Pressing[key]
end

function module:set()
	self.onLoad:Run()
	self:setBackground()
	self:setScreenSize()
	self:setTitle()
	et = 0

	love.mouse.screenPosition = function()
		return love.mouse.position()
	end
	love.mouse.worldPosition = function()
		return love.mouse.position() + self.Camera.CFrame.Position - self.Size/2
	end
	
	function love.quit()
		self.onClose:Run()
	end
	
	function love.update(dt)
		et = et + dt
		self.onUpdate:Run(dt)
	end
	function love.draw()
		self.Camera:push()
		self.onDraw:Run()
		self.Camera:pop()
	end

	function love.keypressed(key)
		self:input(key, Enum.UserInputType.Keyboard, 0, 0)
	end
	function love.mousepressed(x,y,key)
		self:input(key, Enum.UserInputType.Mouse, x, y)
	end
	
	function love.keyreleased(key)
		self:releaseKey(key, Enum.UserInputType.Keyboard, 0, 0)
	end
	function love.mousereleased(x,y,key)
		self:releaseKey(key, Enum.UserInputType.Mouse, x, y)
	end
end

return module