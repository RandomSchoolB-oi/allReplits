local module = {}
module.__index = function(self, i)
	local rawm = rawget(module, i)
	if rawm then return rawm end
	
	local raws = rawget(self,i)
	if raws then return raws end
	
	local fromName = self.Children and findFromName(self.Children,i)
	if fromName then return fromName end
end

local fonts = {}

module.new = function(noGameSet)
    local self = setmetatable({}, module)

    self.Position = Udim2.new(0, 0, 0, 0)
	self.RelativePosition = Udim2.new(0, 0, 0, 0)
    self.Size = Udim2.new(0, 100, 0, 100)
	self.Padding = Udim2.new(0, 0, 0, 0)
	self.RelativeSize = Udim2.new(0, 100, 0, 100)
    self.AnchorPoint = Vector2.new(0, 0)
    self.Rotation = 0
    self.BackgroundColor = Color.new(1,1,1,1)
	self.Parent = nil
	self.TextStretch = false
	self.Children = {}
	self.Shape = Enum.FrameShape.Square
	self.Name = "Frame"
	self.Visible = true
	-- self.OutlineSize = 1
	
	self.Selectable = false
	self.AutoColor = false
	self.Activated = Instance.new("Signal")
	self.Deactivated = Instance.new("Signal")
	self.TextScale = 32
	
    self.TextColor = Color.new(0, 0, 0, 1)

	self.Image = ""
	self.ImageColor = Color.white
	
    self.Changed = Instance.new("Signal")

	
    local changable changable = Instance.new("Changable", self, {
        Image = function(newVal)
			if not newVal or newVal == "" then
				changable.ImageObject = nil
				return ""
			end

			local s,e = pcall(function()
				changable.ImageObject = love.graphics.newImage(newVal)
			end)
			if s then
            	return newVal
			else
				changable.Image = nil
			end
        end,
			
		Text = function(newVal)
			if not newVal then
				return newVal
			end

			self.TextObject = love.graphics.newText(fonts[self.TextScale], newVal)
			
            return newVal
        end,
		TextScale = function(newVal)
			if not fonts[newVal] then
				fonts[newVal] = love.graphics.newFont(newVal, "normal")
			end
			self.TextScale = newVal
			if self.Text then
				changable.Text = self.Text -- refresh the font size
			end
			return newVal
		end,
		Parent = function(val)
			if self.Parent then
				for i, o in ipairs(self.Parent:getChildren()) do
					if o == self then
						table.remove(self.Parent:getChildren(), i)
					end
				end
			end
			if val then
				val.Children[#val.Children+1] = changable
			end
			if not val then
				game:addObject(changable)
			else
				game:removeObject(changable)
			end
				changable:setConnectionTo(game)
			return val
		end,

		-- Size = function(v)
		-- 	self:draw()
		-- 	return v
		-- end,
		-- Position = function(v)
		-- 	self:draw()
		-- 	return v
		-- end,
		-- AnchorPoint = function(v)
		-- 	self:draw()
		-- 	return v
		-- end,
    })
	changable.TextScale = self.TextScale

	if not noGameSet then
		self:setConnectionTo(game)
		game:addObject(changable)
	end
	
	return changable
end

-- function module:clone()
-- 	local newFrame = module.new()
-- 	for prop, val in pairs(self) do
-- 		if prop == "Children" then
-- 	end
-- end

function module:setConnectionTo(game)
	if self._inpBgnConn then
		self._inpBgnConn:Disconnect()
		self._inpBgnConn = nil
	end
	if self._inpEndConn then
		self._inpEndConn:Disconnect()
		self._inpEndConn = nil
	end
		
	if not game then return end
	self._inpBgnConn = game.inputBegan:Connect(function(input)
		if input.UserInputType ~= Enum.UserInputType.Mouse then return end
		if input.KeyCode ~= Enum.KeyCode.MouseButton1 then return end
		if self.Selectable and self:hovering() then
			self.Clicked = true
			self.Activated:Run()	
		end
	end)
	self._inpEndConn = game.inputEnded:Connect(function(input)
		if input.UserInputType ~= Enum.UserInputType.Mouse then return end
		if input.KeyCode ~= Enum.KeyCode.MouseButton1 then return end
		if self.Selectable and self.Clicked then
			self.Clicked = false
			self.Deactivated:Run()	
		end
	end)
end

function module:destroy()
	self.Parent = nil
	game:removeObject(self)
	for _, frame in ipairs(self:getChildren()) do
		frame:destroy()
	end
end

function module:getChildren()
	return self.Children
end
function module:getDescendants()
	local list = {}
	
	local function recurse(button)
		for _, other in ipairs(button:getChildren()) do
			list[#list+1] = other
			recurse(other)
		end
	end
	recurse(self)
	
	return list
end

function module:draw(previousOrigin, previousSize, previousAnchor)
    if not self.Visible then return end
	local pos = self.Position
    local size = self.Size
    local anchor = self.AnchorPoint
    local rot = math.rad(self.Rotation)

	local relativePos = pos:Calculate(previousSize)

	if previousOrigin then
		relativePos = relativePos + previousOrigin - previousSize * previousAnchor
	end
	local relativeSize = size:Calculate(previousSize)

	self.Relative = {
		Position = relativePos,
		Size = relativeSize,
		Anchor = anchor,
	}

	local brightness = 1
	if self.AutoColor and self:hovering() then
		brightness = 0.75
	end
	
    self.BackgroundColor:apply(brightness)
	if self.Shape == Enum.FrameShape.Circle then
		ellipse(relativePos, relativeSize, anchor, rot)
	elseif self.Shape == Enum.FrameShape.Square then
	    rect(relativePos, relativeSize, anchor, rot)
	end

	
	if self.TextObject then
	    self.TextColor:apply()
	    text(relativePos, relativeSize, anchor, rot, self.TextObject, self.TextStretch)
	end
	if self.ImageObject then
	    self.ImageColor:apply()
		image(relativePos, relativeSize, anchor, rot, self.ImageObject)
	end
	local inset = self.Padding:Calculate(relativeSize)
	local childPos = relativePos + inset/2
	local childSize = relativeSize - inset/2
	for _, child in ipairs(self.Children) do
		child:draw(relativePos, childSize, anchor)
	end
end

function module:hovering()
	if not self.Relative then return false end
	
	local mousePos = love.mouse.position()
	local size = self.Relative.Size

	if self.Shape == Enum.FrameShape.Circle and size.X == size.Y then
		return (mousePos - self.Relative.Position).Magnitude < size.X / 2
	elseif self.Shape == Enum.FrameShape.Square then
		local minPos = self.Relative.Position - size * self.Relative.Anchor
		local maxPos = minPos + size
	
		return mousePos > minPos and mousePos < maxPos
	end
end

function module:ScaleByTextBounds(scaleFactor)
	local textSize = Vector2.new(self.Text:getDimensions()) * scaleFactor
	self.Size = Udim2.fromOffset(textSize())
end

return module