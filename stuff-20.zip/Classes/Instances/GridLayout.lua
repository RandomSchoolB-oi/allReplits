local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.CellSize = Udim2.new(0, 100, 0, 100)
	self.CellPadding = Udim2.new(0, 5, 0, 5)

	return self
end

function module:apply(frame)
	local x,y = 0, 0
	local size = frame.Relative.Size
	local cSize = self.CellSize:Calculate(size)
	local cPadding = self.CellPadding:Calculate(size)
	for i, v in ipairs(frame.Children) do
		v.Size = Udim2.new(0, cSize.X, 0, cSize.Y)
		v.Position = Udim2.new(0, x, 0, y)
		v.AnchorPoint = Vector2.new(0, 0)
		if fuzzyEQ(x + cSize.X + cPadding.X, size.X) then
			x = 0
			if i ~= 1 then
				y = y + cSize.Y + cPadding.Y
			end
		else
			x = x + cSize.X + cPadding.X
		end
	end
end

return module