local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.CellPadding = Udim2.new(0, 5, 0, 5)
	-- self.FillDirection = Enum.FillDirection.Down

	return self
end

function module:apply(frame)
	local y = 0
	local size = frame.Relative.Size
	local cSize = self.CellSize:Calculate(size)
	local cPadding = self.CellPadding:Calculate(size)
	for i, v in ipairs(frame.Children) do
		v.Position = Udim2.new(0, frame.Relative.Position.X, 0, y)
		v.AnchorPoint = Vector2.new(0, 0)
		y = y + v.Relative.Size.Y
	end
end

return module