local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.CFrame = CFrame.new(0,0, 0)

	return self
end

function module:push()
	love.graphics.push()
	love.graphics.translate((game.Size/2)())
	love.graphics.rotate(-self.CFrame.R)
	love.graphics.translate((-self.CFrame.Position)())
end

function module:pop()
	love.graphics.pop()
end

return module