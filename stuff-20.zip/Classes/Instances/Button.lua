local module = {}
module.__index = module
local parentClass = require("Classes.Instances.Frame")
setmetatable(module, parentClass)

module.new = function()
	local f = parentClass.new()
	setmetatable(f, module)

	f.Selectable = true
	f.AutoColor = true
	
	return f
end

return module