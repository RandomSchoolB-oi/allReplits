local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	
	self.KeyCode = Enum.UserInputType.Unknown
	self.UserInputType = Enum.UserInputType.Unknown
	self.Position = Vector2.new(0, 0)

	return self
end

module.getIndex = function(key, inputType)
	local index = tostring(key)
	index = index:sub(1,1):upper()..index:sub(2, index:len())

	if inputType == Enum.UserInputType.Mouse then
		index = "MouseButton"..index
	end
	
	return index
end

module.create = function(key,inputType,x,y)
	local object = Instance.new("InputObject")
	local index = module.getIndex(key, inputType)
	
	local code = Enum.KeyCode[index]
	
	if code then
		object.KeyCode = code
	end
	if x then
		object.Position.X = x
	end
	if y then
		object.Position.Y = y
	end
	
	object.UserInputType = inputType

	return object
end

return module