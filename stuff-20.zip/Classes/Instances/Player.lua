local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)

	self.Walkspeed = 160
	self.Size = Vector2.new(100,100)
	self.CFrame = CFrame.new(0, 0, 0)
	self.MoveDirection = Vector2.new(0,0)
	-- self.MoveTo = Vector2.new(0,0) -- set to nil when destination reached

	self.DestinationReached = Instance.new("Signal")

	self.IsPlayer = false
	
	return self
end

function module:update(dt)
	if self.IsPlayer then
		local dir, moved = Vector2.new(), false
		if game:isKeyDown(Enum.KeyCode.W) then
			dir.Y = dir.Y - 1
			moved = true
		end
		if game:isKeyDown(Enum.KeyCode.A) then
			dir.X = dir.X - 1
			moved = true
		end
		if game:isKeyDown(Enum.KeyCode.S) then
			dir.Y = dir.Y + 1
			moved = true
		end
		if game:isKeyDown(Enum.KeyCode.D) then
			dir.X = dir.X + 1
			moved = true
		end
		if moved then
			self.MoveDirection = dir.Unit
		else
			self.MoveDirection = Vector2.zero
		end
	end
	
	if self.MoveTo then
		local normalized = (self.MoveTo - self.CFrame.Position)
		if normalized.Magnitude <= 1 then
			self.DestinationReached:Run(self.MoveTo)
			self.MoveDirection = Vector2.zero
			self.MoveTo = nil
		else
			self.MoveDirection = normalized.Unit
		end
	end
	
	self.CFrame = self.CFrame + self.MoveDirection * self.Walkspeed * dt

	if self.IsPlayer then
		game.Camera.CFrame = CFrame.new(self.CFrame.X, self.CFrame.Y, 0)
	end
end

function module:draw()
	Color.white:apply()
	ellipseCF(self.CFrame, self.Size, Vector2.mid)
end

return module