local module = {}
module.__index = module

module.new = function(shouldCoroutine)
    local self = setmetatable({}, module)

	self.connections = {}
	self.shouldCoroutine = not not shouldCoroutine
	
    return self
end

function module:Once(callback)
	local c c = self:Connect(function(...)
		callback(...)
		c:Disconnect()
		c = nil
	end)

	return c
end

function module:Wait()
	local thread = coroutine.running()
	local params
	self:Once(function(...)
		params = {...}
		coroutine.resume(thread)
	end)
	coroutine.yield(thread)
	return unpack(params)
end

function module:Connect(callback, setIndex)
	if not setIndex then
		setIndex = 0
		while true do
			if not self.connections[setIndex] then break end
			setIndex = setIndex + 1
		end
	end
	local signal = {callback = callback, Disconnect = function(connection)
        table.remove(self.connections, table.find(self.connections, connection))
    end}
    self.connections[setIndex] = signal

	return signal
end

function module:Run(...)
	local args = {...}
    for _, connection in pairs(self.connections) do
		if self.shouldCoroutine then
			coroutine.wrap(function()
				connection.callback(table.unpack(args))
			end)()
		else
			connection.callback(table.unpack(args))
		end
    end
end

return module