local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	
	self.objects = {}

	game.onUpdate:Connect(function(dt)
		for i = #self.objects, 1, -1 do
			local v = self.objects[i]
			if et - v.When > v.Duration then
				self:pop(i)
			end
		end
	end)
	
	return self
end

function module:push(info,duration)
	for i = #self.objects, 1, -1 do
		self.objects[i+1] = self.objects[i]
	end
	self.objects[1] = {
		Data = info, 
		Duration = duration, 
		When = et
	}
end
function module:pop(index,isAValue)
	if not index then
		index = 1
	end

	if isAValue then
		for i, v in ipairs(self.objects) do
			if v.Data == index then
				index = i
				break
			end
		end
	end
	
	if self.objects[index] then
		table.remove(self.objects, index)
	end
end

function module:collect(amount)
	local list = {}
	if not amount then amount = #self.objects end
	for i = 1, amount do
		if not self.objects[i] then break end
		list[i] = self.objects[i].Data
	end
	return list
end

return module