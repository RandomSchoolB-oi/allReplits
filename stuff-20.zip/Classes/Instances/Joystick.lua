local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Frame = Instance.new("Frame")
	self.Moved = Instance.new("Signal")
	self.Radius = 50
	self.Position = Vector2.new(0,0)
	self.BackgroundColor = Color.new(1,1,1,0.5)

	self.Dragging = false

	self.Frame.Selectable = true
	self.Frame.AutoColor = true
	self.Frame.Activated:Connect(function()
		self.Dragging = true
	end)
	self.Frame.Deactivated:Connect(function()
		self.Dragging = false
	end)

	self.Frame.AnchorPoint = Vector2.new(0.5, 0.5)
	self.Frame.Shape = Enum.FrameShape.Circle
	self.Frame.Size = Udim2.new(0,50,0,50)
	self.Value = Vector2.new(0,0)
	
	game.onUpdate:Connect(function(dt)
		local value = Vector2.new(0, 0)
		if self.Dragging then
			local maxDist = self.Radius
			local toPos = love.mouse.position()
			local normalized = toPos - self.Position

			local dist = clamp(normalized.Magnitude, 0, maxDist)
			local unit = normalized.Unit

			local p = self.Position + unit * dist
			self.Frame.Position = Udim2.new(0, p.X, 0, p.Y)
			
			value = unit * (dist/maxDist)
		else
			local p = self.Position
			self.Frame.Position = Udim2.new(0, p.X, 0, p.Y)
		end
		if value ~= self.Value then
			self.Value = value
			self.Moved:Run(self.Value)
		end
	end)
	game.onDraw:Connect(function()
		game.Camera:pop()
		self.BackgroundColor:apply()
		ellipse(self.Position, Vector2.one * self.Radius*2, Vector2.mid, 0)
		game.Camera:push()
	end)
	
	return self
end


return module