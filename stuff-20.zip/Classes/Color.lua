local module = {}
module.__index = module

module.new = function(r,g,b, a)
    local self = setmetatable({
            R = r or 0,
            G = g or 0,
            B = b or 0,
            A = a or 1
    }, module)

    return self
end

module.random = function(randA)
	return module.new(math.random(), math.random(), math.random(), randA and math.random())
end

module.fromRGB = function(r,g,b, a)
	local r = r or 255
	local g = g or 255
	local b = b or 255
	local a = a or 255
    return module.new(r/255,g/255,b/255,a/255)
end

function module:Lerp(to, a)
    return module.new(
        lerp(self.R, to.R, a),
        lerp(self.G, to.G, a),
        lerp(self.B, to.B, a),
        lerp(self.A, to.A, a)
    )
end

function module:apply(brightness)
	local brightness = brightness or 1
    love.graphics.setColor(
        self.R * 255 * brightness,
        self.G * 255 * brightness,
        self.B * 255 * brightness,
        self.A * 255
    )
end

function module:__call()
    return self.R*255, self.G*255, self.B*255, self.A*255
end

module.red = module.new(1, 0, 0, 1)
module.green = module.new(0, 1, 0, 1)
module.blue = module.new(0, 0, 1, 1)

module.white = module.new(1, 1, 1, 1)
module.black = module.new(0, 0, 0, 1)

module.none = module.new(0, 0, 0, 0)
module.blank = module.none
module.nothing = module.none
module.empty = module.none

return module