local Vector2 = {}
Vector2.__index = function(self, index)
    if Vector2[index] then return Vector2[index] end

    if index == "Magnitude" then
        return math.sqrt(self.X ^ 2 + self.Y ^ 2)
    end
    if index == "Unit" then
        local mag = self.Magnitude
        return Vector2.new(self.X / mag, self.Y / mag)
    end
end

Vector2.new = function(x,y)
    local self = setmetatable({}, Vector2)
    self.X = x or 0
    self.Y = y or 0
    
    return self
end
function Vector2.FromAngle(angle)
	local x, y = math.sin(angle), math.cos(angle)

	return Vector2.new(x,y)
end

function Vector2:__add(other)
	local t = type(other)
	assert(t == "table", "Attempted arithmatic \"add\" on a "..type(self).." and a "..t)
    return Vector2.new(self.X + other.X, self.Y + other.Y)
end
function Vector2:__sub(other)
	local t = type(other)
	assert(t == "table", "Attempted arithmatic \"sub\" on a "..type(self).." and a "..t)
    return Vector2.new(self.X - other.X, self.Y - other.Y)
end
function Vector2:__mul(other)
	local t = type(other)
	assert(t == "table" or t == "number", "Attempted arithmatic \"mul\" on a "..type(self).." and a "..t)
    if t == "number" then
        return Vector2.new(self.X * other, self.Y * other)
    end
    return Vector2.new(self.X * other.X, self.Y * other.Y)
end
function Vector2:__div(other)
	local t = type(other)
	assert(t == "table" or t == "number", "Attempted arithmatic \"mul\" on a "..type(self).." and a "..t)
    if t == "number" then
        return Vector2.new(self.X / other, self.Y / other)
    end
    return Vector2.new(self.X / other.X, self.Y / other.Y)
end
function Vector2:__unm()
    return Vector2.new(-self.X, -self.Y)
end
function Vector2:__lt(other)
	local t = type(other)
	assert(t == "table", "Attempted comparison \"<\" on a "..type(self).." and a "..t)
    return self.X < other.X and self.Y < other.Y
end
function Vector2:__le(other)
	local t = type(other)
	assert(t == "table", "Attempted comparison \"<=\" on a "..type(self).." and a "..t)
    return self.X <= other.X and self.Y <= other.Y
end
function Vector2:__eq(other)
	local t = type(other)
	assert(t == "table", "Attempted comparison == on a "..type(self).." and a "..t)
    return self.X == other.X and self.Y == other.Y
end

function Vector2:ToAngle()
	return math.atan2(self.Y, self.X)
end

function Vector2:Cross(other)
	local t = type(other)
	assert(t == "table", "Attempted operation \"cross\" on a "..type(self).." and a "..t)
	return self.X * other.Y + self.Y * other.X
end

function Vector2:Rotate(rot)
	local r  = self:ToAngle() + rot
	local s,c = math.sin(r), math.cos(r)

	return Vector2.new(s,c)
end

function Vector2:Reflect(normal)
	local t = type(other)
	assert(t == "table", "Attempted operation \"reflect\" on a "..type(self).." and a "..t)
	return self - (normal * self:Dot(normal) * 2)
end

function Vector2:Dot(other)
	local t = type(other)
	assert(t == "table", "Attempted operation \"dot\" on a "..type(self).." and a "..t)
	return self.X * other.X + self.Y * other.Y
end

function Vector2:AngleBetween(normal)
	local t = type(other)
	assert(t == "table", "Attempted operation \"angleBetween\" on a "..type(self).." and a "..t)
	return math.deg(math.acos(clamp(-self.Unit:Dot(normal), -1, 1)))
end

function Vector2:Copy()
	return Vector2.new(self())
end

function Vector2:__call()
    return self.X, self.Y
end

function Vector2:Lerp(to, a)
    return lerp(self, to, a)
end

Vector2.zero = Vector2.new(0,0)
Vector2.one = Vector2.new(1,1)
Vector2.xAxis = Vector2.new(1,0)
Vector2.yAxis = Vector2.new(0,1)
Vector2.mid = Vector2.new(0.5, 0.5)

return Vector2