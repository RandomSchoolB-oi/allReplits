local module = {}
module.__index = function(self, i)
	if module[i] then
		return module[i]
	end
	if i == "LookVector" then
		local r = -self.Rotation
		local s,c = math.sin(r), math.cos(r)

		return Vector2.new(s,c)
	end
	if i == "RightVector" then
		local r = -(self.Rotation + math.pi/2)
		local s,c = math.sin(r), math.cos(r)

		return Vector2.new(s,c)
	end
	if i == "X" then
		return self.Position.X
	end
	if i == "Y" then
		return self.Position.Y
	end
	if i == "R" then
		return self.Rotation
	end
end

module.new = function(x, y, r)
	local self = setmetatable({}, module)
	self.Position = Vector2.new(x,y)
	self.Rotation = r or 0
	return self
end

module.lookAt = function(x1,y1,x2,y2)
	local a = math.atan2(y2-y1, x2-x1)
	return module.new(x1,y1, a + math.pi/2)
end

function module:Lerp(other,a)
	local lerpedR = lerp(self.R, other.R, a)
	-- local diff = other.R - self.R
	-- local dir = sign(diff)
	-- local dist = math.abs(diff)
	-- if dist > math.pi then
	-- 	lerpedR = lerp((self.R + tpi*dir) % tpi, other.R, a)
	-- else
	-- 	lerpedR = lerp(self.R, other.R, a)
	-- end
	return CFrame.new(
		lerp(self.X, other.X, a),
		lerp(self.Y, other.Y, a),
		lerpedR
	)
end

function module:__mul(cf)
	local movedX = self.RightVector * -cf.X
	local movedY = self.LookVector * cf.Y
	local r = cf.Rotation + self.Rotation

	return module.new(
		self.X + movedX.X + movedY.X, 
		self.Y + movedX.Y + movedY.Y, 
	r)
end

function module:__add(vec)
	return module.new(self.X + vec.X, self.Y + vec.Y, self.Rotation)
end
function module:__sub(vec)
	return module.new(self.X - vec.X, self.Y - vec.Y, self.Rotation)
end

function module:__call()
	return self.X, self.Y, self.Rotation
end

return module