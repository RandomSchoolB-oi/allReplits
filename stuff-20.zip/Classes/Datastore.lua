local module = {}
module.__index = module

-- local stores = {}

-- function module:GetDataStore(name)
-- 	if stores[name] then
-- 		return stores[name]
-- 	end

-- 	local store = setmetatable({}, module)
-- 	store.Name = name
-- 	store.Path = "Data/"..name..".lua"

-- 	return store
-- end

-- function module:GetAsync(index)
-- 	local file = io.open(self.Path, "r")
-- 	local text = file and file:read("*all")
-- 	if text then
-- 		local data = loadstring(text)()
-- 		if data then
-- 			return data[index]
-- 		end
-- 	end
-- 	if file then
-- 		file:close()
-- 	end
-- end

-- function module:SetAsync(index, newData)
-- 	local file = io.open(self.Path, "w")
-- 	local text = file:read() and file:read("*all")

-- 	local data
-- 	if text then
-- 		data = loadstring(text)()
-- 	end
-- 	if not data then data = {} end
	
-- 	data[index] = newData

-- 	file:write("return ",toStr(data))

-- 	file:close()
-- end
local _p = "Data/{FN}.lua"
function module:SetAsync(index, newData)
	local filePath = _p:gsub("{FN}", index)
	local file = io.open(filePath, "w")
	file:write("return ", toStr(newData))
	file:close()
end
function module:GetAsync(index)
	local filePath = _p:gsub("{FN}", index)
	local file = io.open(filePath, "r")
	if file then
		local text = file and file:read("*all")
		file:close()
		return text and loadstring(text)()
	end
end

function module:UpdateAsync(index, transform)
	module:SetAsync(index, transform(module:GetAsync(index)))
end

return module