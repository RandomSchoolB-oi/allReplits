-- Imports
Enum = require("Libraries.Enum")
require("Libraries.Math")
require("Libraries.Graphics")
require("Libraries.String")
require("Libraries.Table")
Vector2 = require("Classes.Vector2")
CFrame = require("Classes.CFrame")
Udim2 = require("Classes.Udim2")
Color = require("Classes.Color")
Instance = require("Classes.Instance")
Datastore = require("Classes.Datastore")
-- http = require("socket.http")

local regPrint = print
function print(...)
	local str = ""
	local args = {...}
	for i, v in ipairs(args) do
		str = str..toStr(v, 0)
		if i ~= #args then
			str = str.." "
		end
	end
	regPrint(str)
end
findFromName = function(self, index)
	for _, object in ipairs(self) do
		if object.Name == index then
			return object
		end
	end
end
indexByName = {
	__index = function(self, index)
		local child = findFromName(self,index)
		if child then return child end
		local has = rawget(self, index)
		if has then return has end
	end,
}
et = 0
time = function()
	return et
end

function recurseRequire(pathy, values)
	local values = values or {}
	local files = love.filesystem.getDirectoryItems(pathy)
	for _, fileName in ipairs(files) do
		if fileName ~= "main.lua" then
			local filePath = pathy.."/"..fileName:gsub(".lua","")
			if fileName:find(".lua") then -- a module to require
				for item, info in pairs(require(filePath)) do
					values[item] = info
				end
			else
				recurse(filePath,values)
			end
		end
	end
	return values
end

-- easy mouse
love.mouse.position = function()
	return Vector2.new(love.mouse.getPosition())
end
love.mouse.udim = function()
	return Udim2.new(0, love.mouse.getX(), 0, love.mouse.getY())
end

-- game loader
-- print(REPLIT_DB_URL,password)

-- if true then return end

local preDetermined = "EasingStylesVisual"

local dir = "Games"
local games = love.filesystem.getDirectoryItems(dir)

local gameIndex
if not preDetermined then
	print("Choose a game")
	print(games)
	gameIndex = tonumber(io.read())
else
	gameIndex = table.find(games, preDetermined)
end

local gameName = games[gameIndex]

path = dir.."/"..gameName.."/"
game = require(path.."main")

love.load = function()
	game:set()
end