function toStr(val, tabs)
	local t = type(val)
	local text
	if t == "string" then
		text = "\""..val.."\""
	elseif t == "number" or t == "boolean" then
		text = tostring(val)
	elseif t == "table" then
		local spacing1 = ""
		local spacing2 = ""
		if tabs and tabs > 0 then
			spacing1 = string.rep("  ", tabs)
			spacing2 = string.rep("  ", tabs-1)
		end
		text = "{\n"
		for i, v in pairs(val) do
			local indexStr = "["..toStr(i).."]"
			text = text .. spacing1 .. indexStr .. " = "..toStr(v,(tabs or 0)+1)..",\n"
		end
		text = text..spacing2.."}"
	elseif t == "function" then
		text = "_function_"
	end
	return text
end