lerp = function(x,y,a)
    return (y-x)*a + x
end
clamp = function(num, min, max)
	return math.max(math.min(num, max), min)
end
rad2deg = -180/math.pi
deg2rad = -math.pi/180

tpi = math.pi * 2

flip = function(a)
	return 1 - a
end


local i, o = Enum.EasingDirection.In, Enum.EasingDirection.Out
local ino = Enum.EasingDirection.InOut

local lin = Enum.EasingStyle.Linear
local quad = Enum.EasingStyle.Quad
local cubic = Enum.EasingStyle.Cubic
local quart = Enum.EasingStyle.Quart
local quint = Enum.EasingStyle.Quint
local sine = Enum.EasingStyle.Sine
local elastic = Enum.EasingStyle.Elastic
local bounce = Enum.EasingStyle.Bounce
local back = Enum.EasingStyle.Back

local pi = math.pi
local sin, cos, pow = math.sin, math.cos, math.pow
local hpi = pi/2


local c1 = 1.70158;
local c2 = c1 * 1.525;
local c3 = c1 + 1;
local c4 = (2 * pi) / 3
local c5 = (2 * pi) / 4.5

local n1 = 7.5625
local d1 = 2.75

calc_styles = {
	[lin] = {
		[o] = function(x)
			return x
		end,
		[ino] = function(x)
			return x
		end,
	},
	
	[quad] = {
		[o] = function(x)
			return x^2
		end,
		[ino] = function(x)
			return x < 0.5 and 2 * x * x or 1 - pow(-2 * x + 2, 2) / 2
		end,
	},

	[cubic] = {
		[o] = function(x)
			return x^3
		end,
		[ino] = function(x)
			return x < 0.5 and 4 * x * x * x or 1 - pow(-2 * x + 2, 3) / 2
		end,
	},

	[quart] = {
		[o] = function(x)
			return x^4
		end,
		[ino] = function(x)
			return x < 0.5 and 8 * x * x * x * x or 1 - pow(-2 * x + 2, 4) / 2
		end,
	},
	[quint] = {
		[o] = function(x)
			return x^5
		end,
		
		[ino] = function(x)
			return x < 0.5 and 16 * x * x * x * x * x or 1 - pow(-2 * x + 2, 5) / 2
		end,
	},

	[elastic] = {
		[o] = function(x)
			return pow(2, -10 * x) * sin((x * 10 - 0.75) * c4) + 1
		end,
		[ino] = function(x)
			return x == 0
			  and 0
			  or x == 1
			  and 1
			  or x < 0.5
			  and -(pow(2, 20 * x - 10) * sin((20 * x - 11.125) * c5)) / 2
			  or (pow(2, -20 * x + 10) * sin((20 * x - 11.125) * c5)) / 2 + 1
		end,
	},

	[sine] = {
		[o] = function(x)
			return sin((x * pi) / 2)
		end,
		[ino] = function(x)
			return -(cos(pi * x) - 1) / 2
		end,
	},

	[bounce] = {
		[o] = function(x)
 			if (x < (1/2.75)) then
		        return (7.5625*x*x);
		    elseif (x < (2/2.75)) then
		        x = x - 1.5/2.75
		        return (7.5625*(x)*x + 0.75);
		    elseif (x < (2.5/2.75)) then
		        x = x - 2.25/2.75
		        return (7.5625*(x)*x + 0.9375);
		    else 
		        x = x - 2.625/2.75
		        return (7.5625*(x)*x + 0.984375);
		    end
		end,
		
		[ino] = function(x)
			return x < 0.5
			  and (1 - CalcEasing(1 - 2 * x, bounce, o)) / 2
			  or (1 + CalcEasing(2 * x - 1, bounce, o)) / 2
		end,
	},

	[back] = {
		[o] = function(x)
			return 1 + c3 * math.pow(x - 1, 3) + c1 * math.pow(x - 1, 2);
		end,
		[ino] = function(x)
			return x < 0.5 and (math.pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2)) / 2
  			or (math.pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
		end,
	},
}

for _, style in pairs(Enum.EasingStyle) do
	calc_styles[style][i] = function(x)
		return flip(CalcEasing(flip(x), style, o))
	end
end

CalcEasing = function(a, style, direction)
	local x = clamp(a, 0, 1)

	if not style then print("no style") return end
	if not direction then print("no dir") return end
	if not calc_styles[style] then print("no list") return end
	
	return calc_styles[style][direction](x)
end

fuzzyEQ = function(a,b)
	return math.abs(a-b)<0.1
end

sign = function(x)
	return x > 0 and 1 or x < 0 and -1 or 0
end

--Radius Collision Detection
RCD = function(p1,s1,p2,s2) -- isIntersecting, normal, depth
	local bigSize = s1.X/2 + s2.X/2
	local normalized = p2 - p1
	if normalized.Magnitude < bigSize then
		return true, normalized.Unit, bigSize - normalized.Magnitude
	end
end

-- AABB = function(p1,s1,p2,s2) -- isIntersecting, normal, depth
-- 	local bigSize = s2 + s1w
-- 	local diff = p2 - p1

-- local isIntersecting = 
-- 	p1.X < p2.X + s2.X and
--     p1.X + s1.X > p2.X and
--     p1.Y < p2.Y + s2.Y and
--     p1.Y + s1.Y > p2.Y
	
-- 	if isIntersecting then
-- 		return true, diff.Unit, bigSize.Magnitude - diff.Magnitude
-- 	end
-- end

AABB = function(p1,s1,p2,s2) -- isIntersecting, normal, depth
	local bigSize = (s2 + s1)/2
	local diff = p2 - p1
	diff = Vector2.new(math.abs(diff.X), math.abs(diff.Y))

	local chosenAxis = diff.X > diff.Y and "X" or "Y"
	
	if diff <= bigSize then
		local diff = p2 - p1
		local dir = Vector2.new()
		local length = bigSize[chosenAxis] - math.abs(diff[chosenAxis])
		dir[chosenAxis] = sign(diff[chosenAxis])
		
		return true, dir.Unit, length
	end
	return false
end