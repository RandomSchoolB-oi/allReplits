rect = function(pos, size, anchor, r)
    _drawTranslated(pos, size, anchor, r, function(offset)
        love.graphics.rectangle("fill", offset.X, offset.Y, size.X, size.Y)
    end)   
end
ellipse = function(pos, size, anchor, r)
    _drawTranslated(pos, size, anchor, r, function(offset)
        love.graphics.ellipse("fill", 0, 0, size.X/2, size.Y/2)
    end)   
end
image = function(pos, size, anchor, r, object)
	if not object or not object.getDimensions then return end
	_drawTranslated(pos, size, anchor, r, function(offset)
		local ox,oy = object:getDimensions()
		love.graphics.draw(object, offset.X, offset.Y, 0, size.X/ox, size.Y/oy)	
	end)
end

rectCF = function(cf,size,anchor)
	return rect(cf.Position, size, anchor, cf.R)
end
ellipseCF = function(cf,size,anchor)
	return ellipse(cf.Position, size, anchor, cf.R)
end
imageCF = function(cf,size,anchor,object)
	return image(cf.Position, size, anchor, cf.R, object)
end

text = function(pos, size, anchor, r, text, stretch)
    _drawTranslated(pos, size, anchor, r, function(offset)
        local textSize = Vector2.new(text:getDimensions())
        local scale = size / textSize
            -- print(scale())
			if not stretch then
				local normal = math.min(scale.X, scale.Y)
				scale.X, scale.Y = normal, normal
			end
        love.graphics.draw(text, offset.X, offset.Y, 0, scale.X, scale.Y)
    end)
end

line = function(pos1, pos2)
	local x1,y1 = pos1()
	local x2,y2 = pos2()

	love.graphics.line(x1,y1,x2,y2)
end


_drawTranslated = function(pos, size, anchor, r, f)
    love.graphics.push()

    local off = size * anchor
    
    love.graphics.translate(pos.X, pos.Y)
    love.graphics.rotate(r)
    f(-off)
    
    love.graphics.pop()
end