local module = {}

module.EasingStyle = {
	Linear = "lin",
	Quad = "quad",
	Cubic = "cubic",
	Quart = "quart",
	Quint = "quint",
	Sine = "sine",
	Elastic = "elastic",
	Bounce = "bounce",
	Back = "back",
}
module.EasingDirection = {
	Out = "out",
	In = "in",
	InOut = "inout",
}
module.FrameShape = {
	Circle = 0,
	Square = 1,
}
module.KeyCode = {
	A = 0,
	B = 1,
	C = 2,
	D = 3,
	E = 4,
	F = 5,
	G = 6,
	H = 7,
	I = 8,
	J = 9,
	K = 10,
	L = 11,
	M = 12,
	N = 13,
	O = 14,
	P = 15,
	Q = 16,
	R = 17,
	S = 18,
	T = 19,
	U = 20,
	V = 21,
	W = 22,
	X = 23,
	Y = 24,
	Z = 25,
	Space = 26,
	
	["0"] = 27,
	["1"] = 28,
	["2"] = 29,
	["3"] = 30,
	["4"] = 31,
	["5"] = 32,
	["6"] = 33,
	["7"] = 34,
	["8"] = 35,
	["9"] = 36,
	
	MouseButton1 = 37,
	MouseButton2 = 38,
	MouseButton3 = 39,

	Unknown = 1000,
}
module.UserInputType = {
	Keyboard = 0,
	Mouse = 1,
	
	Unknown = 1000,
}
module.Types = {
	Changable = 0,
	Decor = 1,
	Frame = 2,
	Game = 3,
	InputObject = 4,
	Signal = 5,
	Stack = 6,
}

return module