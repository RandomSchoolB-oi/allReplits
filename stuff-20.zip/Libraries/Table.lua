table.find = function(tbl, val)
	for i, v in pairs(tbl) do
		if v == val then
			return i,v
		end
	end
end
table.unpack = function(tbl, i)
	local i = i or 1
	local j = i+1
	return tbl[i], tbl[j] and table.unpack(j)
end
table.copy = function(tbl)
	local new = {}
	for i,v in pairs(tbl) do
		if type(v) == "table" then v = table.copy(v) end
		new[i] = v
	end
	return new
end