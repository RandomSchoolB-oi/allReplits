function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

var debounce = false;

function FlashText(text, duration) {
	if (debounce == false) {
		debounce = true;
		var purchaseFrame = document.getElementById("purchase-frame");
		purchaseFrame.innerHTML = text;
		sleep(duration).then(() => { 
			purchaseFrame.innerHTML = "";
			debounce = false;
		});
	}
}