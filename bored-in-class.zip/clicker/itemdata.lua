local module = {
	["Cursors"] = {
		White = {
			multiplier = 1,
		},
	},
	["Cookies"] = {
		Plain = {
			gives = 1
		},
	}
}

return module