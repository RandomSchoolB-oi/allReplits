local module = {}
local color = require("clicker.color")

function module.getInput(outputText)
	if outputText then
		local out = print(outputText)
	end

	return io.read()
end

function module.color(text, g, color)
	g = g:lower()
	return color[g][(g=="fg" and color:upper()) or color:lower()].. text..color.reset
end

function module.wait(delay)
	local start = os.clock()
	repeat until os.clock() - start >= delay
	return true
end

function module.spawn(callback)
	coroutine.wrap(callback)()
end

function module.delay(delay, callback)
	module.spawn(function()
		module.wait(delay)
		callback()
	end)
end

function module.clamp(number, min, max)
	--return math.min(math.max(number, min), max) -- forgot how to do this
	if number > max then
		return max
	elseif number < min then
		return min
	else
		return number
	end
end

return module
