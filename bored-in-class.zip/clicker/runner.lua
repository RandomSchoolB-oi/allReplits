print("big boi")
local playerclass = require("clicker.playerclass")
local fl = require("clicker.functionlibrary")
local itemdata = require("clicker.itemdata")

local player = playerclass.new()


