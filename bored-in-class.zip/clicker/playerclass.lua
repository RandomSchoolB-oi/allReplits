local module = {}
module.__index = module

function module.new()
	local player = {}
	player.score = 0
	player.ownedItems = {}
	player.equipment = {
		cookie = "Plain",
		cursor = "White",
	}

	return setmetatable(player, module)
end

function module:click()
	self.score = self.score + (itemData[self.equipment.cursor].multiplier * itemData[self.equipment.cookie].gives)
end

return module