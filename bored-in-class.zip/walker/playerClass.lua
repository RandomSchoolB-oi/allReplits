local itemdata = require("walker.ItemData")
local FL = require("walker.FunctionLibrary")
local color = require("walker.color")

local module = {}
module.__index = module

function module.new()
	local player = {
		x = 0,
		y = 0,
		score = 0,
		moves = 0,
		collectedPrizes = {},
	}
	return setmetatable(player, module)
end

local moveDirections = {
	w = {x = 0, y =-1},
	a = {x =-1, y = 0},
	s = {x = 0, y = 1},
	d = {x = 1, y = 0},
}

function canMove(self, futurePosition, board)
	return board[futurePosition.y] and board[futurePosition.y][futurePosition.x] and not itemdata[board[futurePosition.y][futurePosition.x]].canCollide
end

local decisions = {
	r = function(self, board)
		self:reset(board)
	end,
	c = function(self, board)
		_G.currentMap = _G.currentMap + 0.1
	end,
	l = function(self, board)
		_G.gameRunning = false
		_G.currentMap = _G.currentMap + 0.1
		return true
	end,
}

function module:reset(board)
	self.x = board.startPos.x
	self.y = board.startPos.y
	self.moves = 0

	FL.drawBoard(board, self)
end

function module:move(board)
	local raw = FL.getInput()
	local direction = raw:sub(1,1):lower()
	if moveDirections[direction] then
		local futurePosition = {
			x = FL.clamp(self.x + moveDirections[direction].x, 1, #board.board[self.x]),
			y = FL.clamp(self.y + moveDirections[direction].y, 1, #board.board),
		}
		if canMove(self, futurePosition, board.board) then
			self.x = futurePosition.x
			self.y = futurePosition.y

			self.moves = self.moves + 1

			if board.board[self.y][self.x] == 3 then
				FL.drawBoard(board, self)
				local decision
				repeat
					local raw = FL.getInput(color.fg.YELLOW.."You Won"..color.reset.."!!!\nretry(r) leave(l) continue(c)") -- prompt all questions
					decision = raw:sub(1,1):lower()
					if decision == "r" or decision == "l" or decision == "c" then
						local decisionFunc = decisions[decision]							local endGame = decisionFunc(self, board)
						if endGame then
							return endGame
						end
					end
				until decision == "r" or decision == "c" or decision == "l"
			elseif self.moves >= board.maxMoves then
				FL.drawBoard(board, self)
				local decision
				repeat
					local raw = FL.getInput(color.fg.RED.."You lost..."..color.reset.."\nretry(r) or leave(l)") -- prompt some questions
					decision = raw:sub(1,1):lower()
					if decision == "r" or decision == "l" then
					local decisionFunc = decisions[decision]
						local endGame = decisionFunc(self, board)
						if endGame then
							return endGame
						end
					end
				until decision == "r" or decision == "l"
			elseif board.board[self.y][self.x] == 2 and not self.collectedPrizes[tostring(self.x)..","..tostring(self.y)] then
				self.collectedPrizes[tostring(self.x)..","..tostring(self.y)] = true
				self.score = self.score + 1
			end
		end
	end
end

return module
