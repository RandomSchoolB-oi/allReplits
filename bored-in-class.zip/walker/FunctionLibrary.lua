local module = {}
local itemdata = require("walker.ItemData")
local color = require("walker.color")

function module.getInput(outputText)
	if outputText then
		local out = print(outputText)
	end

	return io.read()
end

local difficultyColors = {
	easy = "green",
	medium = "yellow",
	hard = "red",
}

function module.drawBoard(board, player)
	os.execute("clear")
	print("Map: ".. board.name)
	local diff = board.difficulty

	local first = diff:sub(1,1):upper()
	local after = diff:sub(2, diff:len())
	local capped = first..after

	local difficultyColored = color.fg[difficultyColors[diff]:upper()]..capped..color.reset
	print("difficulty: "..difficultyColored)
	for y, v in pairs(board.board) do
		local row = ""
		for x, object in pairs(v) do
			local objectData = itemdata[object]
			if y == player.y and x == player.x then
				row = row..itemdata["player"].symbol.." "
			elseif player.collectedPrizes[tostring(x)..","..tostring(y)] then
				row = row.. itemdata[4].symbol.." "
			else
				row = row..objectData.symbol.." "
			end
		end
		print(row)
	end
	local scoreText = tostring(player.score) do
		if scoreText:find("420") or scoreText:find(69) then
			local ran = {'BLACK', 'RED', 'GREEN', 'YELLOW', 'BLUE', 'PINK', 'CYAN', 'WHITE'}
			scoreText = color.fg[ran[math.random(1,#ran)]]..scoreText..color.reset
		end
	end
	print("score: "..scoreText.."\n".."moves: "..tostring(player.moves).."/"..tostring(board.maxMoves))
end

function module.wait(delay)
	local start = os.clock()
	repeat until os.clock() - start >= delay
	return true
end

function module.spawn(callback)
	coroutine.wrap(callback)()
end

function module.delay(delay, callback)
	module.spawn(function()
		module.wait(delay)
		callback()
	end)
end

function module.clamp(number, min, max)
	--return math.min(math.max(number, min), max) -- forgot how to do this
	if number > max then
		return max
	elseif number < min then
		return min
	else
		return number
	end
end

return module
