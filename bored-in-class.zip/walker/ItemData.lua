local color = require("walker.color")
local module = { -- █
	[0] = { -- background
		canCollide = false,
		symbol = " ",
	},

	[1] = { -- wall
		canCollide = true,
		symbol = color.fg.BLACK.."@"..color.reset,
	},

	[2] = { -- prize
		canCollide = false,
		symbol = color.fg.YELLOW.."$"..color.reset,
	},

	[3] = { -- win
		canCollide = false,
		symbol = color.fg.GREEN.."O"..color.reset,
	},

	[4] = { -- used prize
		canCollide = false,
		symbol = color.fg.BLACK.."$"..color.reset,
	},

	["player"] = {
		canCollide = false,
		symbol = "A",--color.fg.PINK.."A"..color.reset,
	},

}

return module
