local FL = require("walker.FunctionLibrary")
local itemdata = require("walker.ItemData")
local mapdata = require("walker.MapData")
local playerClass = require("walker.playerClass")
local color = require("walker.color")

local player = playerClass.new()
_G.currentMap = 0
_G.gameRunning = true

function loadBoard(map)
	if _G.gameRunning then
		local current = _G.currentMap

		player:reset(map)
		player.collectedPrizes = {}
		
		while current == _G.currentMap do
			local dontDraw = player:move(map)
			if not dontDraw then
				FL.drawBoard(map, player)
			end
		end
	end
end
local run = function()
	for i,v in pairs(mapdata) do
		loadBoard(v, player)
	end
end

run()
os.execute("clear")
print("Want to replay?("..color.fg.GREEN.."y"..color.fg.BLACK.."/"..color.fg.RED.."n"..color.reset..")")
local yes = io.read():sub(1,1):lower() == "y"

if yes then
	run()
else
	_G.gameRunning = false
end