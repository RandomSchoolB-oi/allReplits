--local color = require("walker.color")
--print(color.chart())
----[[
local games = {
	walker = true,
	clicker = true,
}
local game
while not game do
	local game = io.read()
	for i,v in pairs(games) do
		if i:lower():find(game:lower()) then
			require(i..".runner")
		end
	end
end
--]]