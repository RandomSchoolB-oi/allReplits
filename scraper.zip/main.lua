local http = require("socket.http")
local json = require("json")


local idToName = {
	["12"] = "RandomB_oi",
	["9"] = "Paper",
}
local text = {}

local WIDTH,HEIGHT = 400, 200

local scroll = 0
local messagePadding = 35
local textHeight = 15
local textRefreshRate = 4 -- per second


local lastDraw = os.clock()
local lastGetText = 0
local message = ""

love.load = function()
	love.window.setMode(WIDTH,HEIGHT)
end

love.update = function(dt)
	local speed = love.keyboard.isDown("space")
	local canScroll = love.keyboard.isDown("lshift")
	
	if love.keyboard.isDown("s") and canScroll then
		scroll = scroll - (dt* (speed and 2000 or 200))
		scrolling = true
	elseif love.keyboard.isDown("w") and canScroll then
		scroll = scroll + (dt* (speed and 2000 or 200))
		scrolling = true
	else
		scrolling = nil
	end

	
	
	if os.clock() - lastGetText > 1/textRefreshRate then
		lastGetText = os.clock()
		local chatData = '[{"text":"test1", "id":12}, {"text":"test2", "id":9}]'
		text = json.parse(chatData)
	end
end

local scrolling
love.draw = function()
	local dt = os.clock() - lastDraw
	lastDraw = os.clock()

	local y = scroll
	for i,v in pairs(text) do
		local name = idToName[tostring(v.id)] or v.id
		love.graphics.print("["..name.."]:",0,y)
		love.graphics.print("    "..v.text,0,y+textHeight)
		y = y + messagePadding
	end

	local tim = os.clock() * 10
	local showLine = math.floor(tim) % 2 == 1
	love.graphics.print(message.. (showLine and "|" or ""),0,HEIGHT - textHeight)
end


local changeKey = {
	space = " ",
	lshift = "",
	rshift = "",
	lctrl = "",
	rctrl = "",
	tab = "    ",
}
function love.keypressed(key,scancode)
	if not scrolling then
		if key == "backspace" then
			if message:len() <1 then
				return
			end
			if love.keyboard.isDown("lctrl") then
				local list = split(message, " ")
				list[#list] = nil
				message = table.concat(list, " ")
				return
			end
			message = message:sub(1, message:len()-1)
		elseif key == "return" then
			text[#text+1] = {id = 12, text = message}
			message = ""
		else
			key = changeKey[key] or key
			if love.keyboard.isDown("lshift") or love.keyboard.isDown("rshift") then
				key = key:upper()
			end
			message = message..key
		end
	end
end

function split (inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        local t={}
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                table.insert(t, str)
        end
        return t
end

