local ClassDirectory = "Classes."
getClass = function(name)
	return require(ClassDirectory..name)
end
return function(load)
	Signal = getClass("Signal")
	Vector3 = getClass("Vector3")
	
	WIDTH, HEIGHT = 400,400

	love.window.setMode(WIDTH, HEIGHT)

	drawSignal = Signal.new()
	updateSignal = Signal.new()

	love.load = load

	love.update = function(dt)
		updateSignal:run(dt)
	end

	love.draw = function()
		love.graphics.push()
		love.graphics.translate(WIDTH/2,HEIGHT/2)
		drawSignal:run()
		love.graphics.pop()
	end
end