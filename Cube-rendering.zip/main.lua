require("boot")(function()
	local class = require("Classes.Cube")
	local cube = class.new()
		cube.Size = Vector3.new(100, 100, 100)
	
	updateSignal:connect(function(dt)
		local rot = dt * 90
		cube.Orientation = cube.Orientation + Vector3.new(rot,rot,rot)
	end)

	drawSignal:connect(function()
		cube:render()
	end)
		
end)