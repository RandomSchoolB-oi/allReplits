local module = {}
module.__index = module

module.new = function(x,y,z)
	x = x or 0 
	y = y or 0 
	z = z or 0
	local magnitude = math.sqrt(x ^ 2 + y ^ 2 + z ^ 2)
	local vector = {
		X = x,
		Y = y,
		Z = z,
		Magnitude = magnitude,
		Unit = {
			X = x/magnitude,
			Y = y/magnitude,
			Z = z/magnitude,
			Magnitude = 1,
		}
	}
	return setmetatable(vector, module)
end

function module:__lt(other)
	return self.X < other.X and self.Y < other.Y and self.Y < other.Z
end
function module:__le(other)
	return self.X <= other.X and self.Y <= other.Y and self.Z <= other.Z
end

function module:__add(other)
	return module.new(self.X + other.X, self.Y + other.Y, self.Z + other.Z)
end
function module:__sub(other)
	return module.new(self.X - other.X, self.Y - other.Y, self,Z - other.Z)
end
function module:__div(other)
	if type(other) == "number" then
		return module.new(self.X / other, self.Y / other, self.Z / other)
	end
	return module.new(self.X / other.X, self.Y / other.Y, self.Z / other.Z)
end
function module:__mul(other)
	if type(other) == "number" then
		return module.new(self.X * other, self.Y * other, self.Z * other)
	end
	return module.new(self.X * other.X, self.Y * other.Y, self.Z * other.Z)
end
function module:__pow(other)
	if type(other) == "number" then
		return module.new(self.X ^ other, self.Y ^ other, self.Z ^ other)
	end
	return module.new(self.X ^ other.X, self.Y ^ other.Y, self.Z ^ other.Z)
end

function module:Dot(other)
	return self.X * other.X + self.Y * other.Y + self.Z * other.Z
end

function module:Cross(other)
	return module.new(
		self.y * other.z - self.z * other.y,
		self.x * other.z - self.z * other.x,
		self.x * other.y - self.y * other.x
	)
end

function module:matMul(matrix)
	-- local matrix = {
	-- 	{1,0,0},
	-- 	{0,1,0},
	-- }

	local v = {self.X, self.Y, self.Z}

	local newMatrix = {}

	for i = 1, #matrix do
		for index, value in pairs(v) do
			newMatrix[i] = (newMatrix[i] or 0) + matrix[i][index] * value
		end
	end

	return module.new(newMatrix[1],newMatrix[2],newMatrix[3])
end

return module