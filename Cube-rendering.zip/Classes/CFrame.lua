local module = {}
module.__index = module

module.new = function(x,y,z)
	local CFrame = {
		Position = Vector.new(x,y,z)
		LookVector = Vector3.zAxis,
		UpVector = Vector3.yAxis,
		RightVector = Vector3.xAxis,
	}
	return setmetatable(vector, module)
end

function module:__add(other)
	return module.new()
end
function module:__sub(other)
	return module.new(self.X - other.X, self.Y - other.Y, self.R - other.R)
end
function module:__mul(other)
	return module.new(self.X * other.X, self.Y * other.Y)
end

return module