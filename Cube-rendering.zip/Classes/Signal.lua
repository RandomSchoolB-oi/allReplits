local module = {}
module.__index = module

module.new = function()
	return setmetatable({_connections = {}, _serializer = 0}, module)
end

function module:connect(callback)
	local id = self._serializer
	self._serializer = self._serializer + 1

	self._connections[id] = {
		_callback = callback, 
		disconnect = function()
			self._connections[id] = nil
		end
	}
	return self._connections[id]
end

function module:run(...)
	for id, connection in pairs(self._connections) do
		connection._callback(...)
	end
end

return module