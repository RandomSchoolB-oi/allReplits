local module = {}
module.__index = module

local triPoints = {
	{1,2,3},
	{2,3,4},
}

local line = function(v1, v2)
	local x1,y1 = v1.X, v1.Y
	local x2,y2 = v2.X, v2.Y
	love.graphics.line(x1,y1,x2,y2)
end

local tri = function(v1,v2,v3)
	love.graphics.polygon("fill", 
		v1.X, v1.Y, 
		v2.X, v2.Y, 
		v3.X, v3.Y
	)
end

module.new = function()
	local cube = setmetatable({
		points = {
			Vector3.new(-1,-1,-1),
			Vector3.new(1,-1,-1),
			Vector3.new(1,1,-1),
			Vector3.new(-1,1,-1),
			Vector3.new(-1,-1,1),
			Vector3.new(1,-1,1),
			Vector3.new(1,1,1),
			Vector3.new(-1,1,1),

		},
		_projectedValues = {},
		Size = Vector3.new(100, 100, 100),
		Orientation = Vector3.new(0, 0, 0),
		Position = Vector3.new(0, 0, 0),
	}, module)

	cube:calculate()

	local editTbl = setmetatable({}, {
		__index = function(self, index)
			return cube[index]
		end,
		__newindex = function(self, index, value)
			if index == "Orientation" then
				value = Vector3.new(value.X % 360, value.Y % 360, value.Z % 360)
			end

			cube[index] = value
			cube:calculate()
		end
	})

	return editTbl
end

function module:calculate()
	local orientation = self.Orientation
	local ox, oy,oz = math.rad(orientation.X), math.rad(orientation.Y), math.rad(orientation.Z)
	local rotationX = {
		{1, 0, 0},
		{0, math.cos(ox), -math.sin(ox)},
		{0, math.sin(ox), math.cos(ox)},
	}
	local rotationY = {
		{math.cos(oy), 0, -math.sin(oy)},
		{0, 1 ,0},
		{math.sin(oy), 0, math.cos(oy)},
	}
	local rotationZ = {
		{math.cos(oz), -math.sin(oz), 0},
		{math.sin(oz), math.cos(oz), 0},
		{0,0,1},
	}

	local points = {}
	for i,v in pairs(self.points) do
		points[#points+1] = v
	end
	
	self._projectedValues = {}

	local distance = 3

	for i,v in pairs(points) do
		local rotated = v:matMul(rotationY):matMul(rotationX):matMul(rotationZ)
		
		local z = 1 / (distance - rotated.Z)
		local matrix = {
			{z,0,0},
			{0,z,0},
			{0,0,z},
		}

		local projected = rotated:matMul(matrix)

		self._projectedValues[#self._projectedValues+1] = projected * (self.Size/2)
	end
end

function module:line(a,b)
	line(self._projectedValues[a], self._projectedValues[b])
end

-- local sunDirection = Vector3.new(0, -1, 0)
-- function module:triangle(a,b,c)
-- 	local triangleNormal = (b-a):Cross(b-c)
	
	
-- 	tri(self._projectedValues[a], self._projectedValues[b], self._projectedValues[c])
-- end

function module:render()
	for i=1,4 do
		self:line(i, i%4 + 1)
		self:line(i+4, i%4+5)
		self:line(i, i+4)
	end

	-- self:triangle(1,2,3)
	-- self:triangle(3,4,1)
	
	for i,v in pairs(self._projectedValues) do
		love.graphics.circle("fill", v.X, v.Y, 5)
	end
end

return module