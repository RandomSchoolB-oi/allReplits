playerMover = {}
playerMover.__index = playerMover

playerMover.new = function(object)
	local mover = {}
	mover.object = object

	setmetatable(mover, playerMover)

	return mover
end


function playerMover:canMove(dir)
	return true
end


function playerMover:canMove_collision(dir)
	local newPos = (self.object.Position + dir)
	local from1 = newPos - self.object.Size/2 
	local to1   = newPos + self.object.Size/2
	love.graphics.circle("fill",from1.X,from1.Y, 5)
	love.graphics.circle("fill",to1.X,to1.Y, 5)


	for _, part in pairs(AllParts()) do
		local from2,to2 = part.Position - part.Size/2, part.Position + part.Size/2
		if (from1 > from2 and from1 < to2) or (to1 > from2 and to1 < to2) then
			return
		end
	end
	
	return true
end


function playerMover:move_no(dir)
	local points = {}
	local x,y,r = (self.object.CFrame + dir)()
	local w,h = self.Size()
	w,h = w/2,h/2

	-- rotated collision
	local x1,y1 = math.cos(r), math.sin(r)
	local x2,y2 = math.cos(r + math.pi), math.sin(r + math.pi)
	
	points[#points+1] = Vector2.new(x+x1*w, y+y1*h)
	points[#points+1] = Vector2.new(x+x2*w, y+y2*h)

	for _, part in pairs(AllParts()) do
		local partCorners = {
			
		}
		for _, corner in pairs(points) do
			
		end
	end
end