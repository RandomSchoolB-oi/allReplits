Color3 = {}
Color3.__index = Color3

clamp = function(a,b,c)
	return math.min(math.max(a, b), c)
end

Color3.new = function(r,g,b)
	local color = {
		R = r or 1,
		G = g or 1,
		B = b or 1,
	}
	color.R = color.R * 255
	color.G = color.G * 255
	color.B = color.B * 255

	return setmetatable(color, Color3)
end

function Color3:__call(brightness)
	brightness = brightness or 1
	local r = self.R * brightness
	local g = self.G * brightness
	local b = self.B * brightness
	love.graphics.setColor(r,g,b)
end