Projectile = {}
Projectile.__index = Projectile

local projectiles = {}
local projectileParts = {}
local serializer = 0

local gravity = Vector2.new(0,198.2)

Projectile.new = function(cf, speed)
	local id = serializer
	serializer = serializer + 1
	local projectile = {
		Position = cf.Position,
		Velocity = cf.LookVector * speed,
		id = id,
		tock = os.clock(),
		object = Instance.new(),
	}
	--projectile.object.Shape = "Circle"
	projectile.object.Size = Vector2.new(25,25)
	projectile.object.outline = true
	
	setmetatable(projectile, Projectile)
	projectiles[id] = projectile
	projectileParts[id] = projectile.object

	return projectile
end

function Projectile:update(dt)
	if os.clock() - (self.tock or 0) >= 6.5 then
		self:destroy()
		return
	end
	local touchingParts = self.object:getTouchingParts(Player, unpack(projectileParts))
	self.Position = self.Position + self.Velocity * dt
	self.Velocity = self.Velocity - gravity * dt

	local x,y = self.Position()
	local vx,vy = self.Velocity()

	for i,v in pairs(touchingParts) do
		v:destroy()
	end
	if #touchingParts >= 1 then
		self:destroy()
		return
	end

	self.object.CFrame = CFrame.lookAt(x,y,x+vx,y+vy)
end

function Projectile:destroy()
	if self.id then
	else
	return
	end
	projectiles[self.id] = nil
	for i,v in pairs(self) do
		if i == "object" then
			v:destroy()
		end
		self[i] = nil
	end
end

function updateAllProjectiles(dt)
	for i,v in pairs(projectiles) do
		v:update(dt)
	end
end