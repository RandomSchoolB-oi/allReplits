Instance = {}
Instance.__index = Instance

local colliding = function(pos1, size1, pos2, size2)
	return	pos1 > pos2-size2/2 and pos1 < pos2+size2/2
end

local find = function(tbl, val)
	for i,v in pairs(tbl) do
		if v == val then
			return i
		end
	end
end

local parts = {}
local serializer = 0
Instance.new = function()
	local part = {}
	part.CFrame = CFrame.new(0, 0, 0)
	part.Position = part.CFrame.Position
	part.Size = Vector2.new(100, 100)
	part.Shape = "Block"--Block, Circle
	part.Color = Color3.new(1,1,1)
	part.id = serializer
	serializer = serializer + 1

	setmetatable(part, Instance)

	local readwrite = setmetatable({},{
		__index = function(self, index)
			return part[index]
		end,
		
		__newindex = function(self, index, value)
			if index == "CFrame" then
				part.Position = Vector2.new(value.X, value.Y)
			elseif index == "Position" then
				part.CFrame = CFrame.new(value.X,value.Y,part.CFrame.R)
			end
			part[index] = value
		end,

		__call = Instance.__call,

		destroy = function(self)
			Instance.destroy(self)
		end,
	})

parts[part.id] = readwrite

	return readwrite
end

function Instance:__call()
	love.graphics.push()

	local x,y = self.Position()
	local r = self.CFrame.R
	local w,h = self.Size()

	if camera then
		local cx,cy,cr = camera.CFrame()
		love.graphics.translate(
			(cx - sx) + (sx - x) + sx, 
			(cy - sy) + (sy - y) + sy
		)
		--love.graphics.rotate(cr - r)
	else
		love.graphics.translate(x, y)
	end
	love.graphics.rotate(r)

	if self.Shape == "Block" then
		self.Color()
		love.graphics.rectangle("fill", -w/2, -h/2, w, h)
		if self.outline then
			if self.outlineStyle == "fancy" then
				local diff = 0.4
				self.Color(1+diff)
				love.graphics.rectangle("fill", -w/2, -h/2, w, 6)
				love.graphics.rectangle("fill", -w/2, -h/2, 6, h)
				self.Color(1-(diff/2))
				love.graphics.rectangle("fill", w/2, h/2, -w+6, -6)
				love.graphics.rectangle("fill", w/2, h/2, -6, -h+6)
			elseif self.outlineStyle == "thicc" then
				for i = 1, 12, .5 do
					self.Color(0.75)
					love.graphics.rectangle("line", -w/2+i, -h/2+i, w-i*2, h-i*2)
				end
			elseif self.outlineStyle == "diamond" then
				for i = 1, 12, .5 do
					local diff = 0.4
					self.Color(1+diff)
					love.graphics.rectangle("fill", -w/2, -h/2, w, 1)
					love.graphics.rectangle("fill", -w/2, -h/2, 1, h)
					self.Color(1-(diff/2))
					love.graphics.rectangle("fill", w/2, h/2, -w+1, -1)
					love.graphics.rectangle("fill", w/2, h/2, -1, -h+1)
					w = w - 2
					h = h - 2
					x = x + 1
					y = y + 1
				end
			else
				self.Color(0.75)
				love.graphics.rectangle("line", -w/2, -h/2, w, h)
			end
		end
	elseif self.Shape == "Circle" then
		self.Color()
		love.graphics.circle("fill", 0, 0, w/2)
		if self.outline then
			self.Color(0.75)
			love.graphics.circle("line", 0, 0, w/2)
		end
	end

	love.graphics.pop()

end

function Instance:getTouchingParts(...)
	local ignoreList = {...}
	local touching = {}
	for i,v in pairs(parts) do
		if find(ignoreList, v) then
		else
			--if v.Shape == "Circle" then
			--	if (self.Position - v.Position).Magnitude < v.Size.X/2 then
			--		touching[#touching+1] = v
			--	end
			--elseif v.Shape == "Block" then
				if colliding(self.Position, self.Size, v.Position, v.Size) then
					touching[#touching+1] = v
				end
			--end
		end
	end
	return touching
end

function Instance:destroy()
	local id = self.id
	for i,v in pairs(self) do
		self[i] = nil
	end
	parts[id] = nil
end

function AllParts()
	return parts
end

function Instance.render(self)
	if self then
		self()
	else
		for i,v in pairs(parts) do
			v()
		end
	end
end