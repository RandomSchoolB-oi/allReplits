Enemy = {}
Enemy.__index = Enemy

enemies = {}
local serializer = 0

function Enemy.new(x, y)
	local id = serializer
	local zombie = {
		object = Instance.new()
	}

	zombie.object.CFrame = CFrame.new(x,y)
	zombie.object.Size = Vector2.new(100, 100)
	zombie.object.Color = Color3.new(1,.2,.2)
	zombie.object.outline = true

	serializer = serializer + 1
	enemies[id] = zombie
	zombie.id = id

	setmetatable(zombie, Enemy)
	return zombie
end

function Enemy:update(dt)
	
end