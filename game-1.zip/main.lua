require("Objects.CoordinateFrame") 
require("Objects.Vector2") 
require("Objects.Color3") 
require("Objects.Camera") 
require("Objects.Part") 
require("Objects.Projectile")
require("Objects.PlayerMover")
require("Objects.Enemy")

sx,sy = 200,200
function love.load()
	love.window.setMode(sx*2,sy*2)
	love.graphics.setBackgroundColor(170, 255, 0)
end

local mouseX,mouseY = love.mouse.getPosition()
local mousePos = Vector2.new()

Player = Instance.new()
Player.Size = Vector2.new(50,50)
Player.CFrame = Player.CFrame + Player.CFrame.LookVector * 250

local mover = playerMover.new(Player)

local p = Instance.new()
p.Size = Vector2.new(100,400)

camera = Camera.new()

local elapsedTime = 0

function love.update(dt)
	elapsedTime = elapsedTime + dt

	updateAllProjectiles(dt)

	mouseX, mouseY = love.mouse.getPosition()
	mouseX, mouseY = Player.CFrame.X + mouseX - sx, Player.CFrame.Y + mouseY - sy
	mousePos = Vector2.new(mouseX, mouseY)
	-- character mover
	Player.CFrame = CFrame.lookAt(Player.CFrame.X, Player.CFrame.Y, mouseX, mouseY)
	
	do
		local dir
		if love.keyboard.isDown("w") then
			dir = Player.CFrame.LookVector * 100 * dt
		elseif love.keyboard.isDown("s") then
			dir = Player.CFrame.LookVector *-100 * dt
		end
		if dir then
			if mover:canMove(dir) then
				Player.CFrame = Player.CFrame + dir
			end
		end
	end
	do
		local dir
		if love.keyboard.isDown("a") then
			dir = Player.CFrame.RightVector * 100 * dt
		elseif love.keyboard.isDown("d") then
			dir = Player.CFrame.RightVector *-100 * dt
		end
		if dir then
			if mover:canMove(dir) then
				Player.CFrame = Player.CFrame + dir
			end
		end
	end
	
	camera.CFrame = Player.CFrame

	if math.random(0,100) == 0 then
		Enemy.new(math.random(0,sx), math.random(0,sy))
	end
	--Projectile.new(Player.CFrame, 250)
end

function love.mousepressed()
	Projectile.new(Player.CFrame, 300)
end

function love.draw()

	Instance.render()
end