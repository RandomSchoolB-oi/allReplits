Segment = {}
Segment.__index = Segment

local segments = {}
local serializer = 0

Segment.new = function(length)
	local seg = {
		CFrame = CFrame.new(),
		Length = length or 100,
	}
	local id = serializer
	serializer = serializer + 1
	segments[id] = seg
	seg.id = id
	
	return setmetatable(seg, Segment)
end

function Segment:updateB()
	self.PositionB = (self.CFrame + self.CFrame.LookVector * self.Length).Position
end

function Segment:updateA(x,y)
	self.CFrame = CFrame.new(x,y,self.CFrame.R)
	self:updateB()
end

function Segment:look(x,y)
	local looking = CFrame.lookAt(self.CFrame.X,self.CFrame.Y, x,y)
	self.CFrame = CFrame.new(looking.X, looking.Y, looking.R + math.pi)

	self:updateB()
end

function Segment:shift(length)
	self.CFrame = self.CFrame + self.CFrame.LookVector * length
	self:updateB()
end

function Segment:follow(x,y)
	self:look(x,y)
	self:shift(-self.Length)
	self:shift((self.PositionB - Vector2.new(x, y)).Magnitude)

end

function Segment:destroy()
	if self and self.id then
		segments[self.id] = nil
	end
end

function Segment:__call()
	love.graphics.setColor(255,255,255)

	local x,y = self.CFrame.Position()
	self:updateB()
	local bx,by = self.PositionB()

	love.graphics.line(x, y, bx, by)
end

function drawSegments()
	for i,v in pairs(segments) do
		v()
	end
end