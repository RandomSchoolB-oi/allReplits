function love.load()
	require("Objects.CoordinateFrame") 
	require("Objects.Vector2") 
	require("Objects.Color3") 
	require("Objects.Camera") 
	require("Objects.Part") 
	require("Objects.Projectile")
	require("Objects.Segment")
	require("Objects.InverseKinematics")

	sx,sy = 400, 300
	local elapsedTime = 0

	local snakes = {}
	snakes[#snakes+1] = IK.new()
	snakes[#snakes].base = Vector2.new(sx,sy)
--	snakes[#snakes+1] = IK.new()
--	snakes[#snakes].base = Vector2.new(sx,0)*2
--	snakes[#snakes+1] = IK.new()
--	snakes[#snakes].base = Vector2.new(0,sy)*2
--	snakes[#snakes+1] = IK.new()
--	snakes[#snakes].base = Vector2.new(sx,sy)*2
	
	wait = function(time)
		time = time or 0
		local started = os.clock()
		repeat until os.clock() - started > time
		return os.clock() - started
	end
	spawn = function(callback)
		return coroutine.wrap(callback)
	end
	delay = function(time, callback)
		return spawn(function(...)
			wait(time)
			callback(...)
		end)
	end
	
	function love.update(dt)
		elapsedTime = elapsedTime + dt
		----[[
		
		--]]
	--	local nextPos = Vector2.new(sx,sy) + Vector2.new(
	--		math.sin(elapsedTime * 2) * 200,
	--		math.cos(elapsedTime * 2) * 200
	--	)
		local nextPos = Vector2.new(love.mouse.getPosition())

		for i,v in pairs(snakes) do
			v.to = Vector2.new(nextPos())
			v:solve()
		end
	end

	function love.keypressed(key)
		if key == "w" then
			for _,snake in pairs(snakes) do
				snake:add(100)
			end
		elseif key == "s" then
			for _,snake in pairs(snakes) do
				snake:remove()
			end
		end
	end

	function love.draw()
		for i,v in pairs(snakes)do v:render() end
		Color3.new(1,1,1)()
	end


	love.window.setMode(sx*2,sy*2)
	love.graphics.setBackgroundColor(125,125,125)
end