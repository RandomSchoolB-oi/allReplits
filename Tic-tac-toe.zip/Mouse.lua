Mouse = {}

updateMouse = function()
	mouse.X = love.mouse.GetX()
	mouse.Y = love.mouse.GetY()
end