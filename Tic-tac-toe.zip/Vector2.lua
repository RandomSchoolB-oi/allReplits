Vector2 = {}
Vector2.__index = Vector2
function Vector2.__sub(self, other)
	local new = Vector2.new(self.x - other.x, self.y - other.y)
	return new
end

function Vector2.__add(self, other)
	local new = Vector2.new(self.x + other.x, self.y + other.y)
	return new
end

function Vector2.__mul(self, other)
	if type(other) == "number" then
		local new = Vector2.new(self.x * other, self.y * other)
		return new
	else
		local new = Vector2.new(self.x * other, self.y * other)
		return new
	end
end

function Vector2.__div(self, other)
	if type(other) == "number" then
		local new = Vector2.new(self.x / other, self.y / other)
		return new
	else
		local new = Vector2.new(self.x / other.x, self.y / other.y)
		return new
	end
end

function Vector2.__mod(self, other)
	if type(other) == "number" then
		local new = Vector2.new(self.x % other, self.y % other)
		return new
	else
		local new = Vector2.new(self.x % other.x, self.y % other.y)
		return new
	end
end

function Vector2.__pow(self, other)
	if type(other) == "number" then
		local new = Vector2.new(self.x ^ other, self.y ^ other)
		return new
	else
		local new = Vector2.new(self.x ^ other.x, self.y ^ other.y)
		return new
	end
end

function Vector2.__unm(self)
	return Vector2.new(-self.x, -self.y, -self.z)
end

function Vector2.__eq(self, other)
	return self.x == other.x and self.y == other.y
end

function Vector2.__lt(self, other)
	return self.x < other.x and self.y < other.y
end

function Vector2.__le(self, other)
	return self.x <= other.x and self.y <= other.y
end

function Vector2.__tostring(self)
	return tostring(self.x)..", "..tostring(self.y)
end

function Vector2.__call(self)
	return self.x, self.y
end
Vector2.new = function(x,y)
	local vector = {}
	vector.x = x or 0
	vector.y = y or 0
	return setmetatable(vector, Vector2)
end

return Vector2