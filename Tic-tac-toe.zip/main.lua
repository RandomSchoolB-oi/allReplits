require("game")

local function clamp(numb, min, max)
	if numb < min then
		return min
	elseif numb > max then
		return max
	else
		return numb
	end
end
local function find(tbl,value)
	for i,v in pairs(tbl) do
		print(v,value)
		if v == value then
			return i
		end
	end
end

local sx,sy = 3,3
local currentPlayer = true
function love.load()
	buttons = {}

	checkForWinState = function()
	print("Checking")
		local conditions = {}

		-- horizontal
		conditions.c1 = {p=nil,c={}}
		for y=0,sy-1 do
			for x=1,sx-3 do
				conditions.c1.p = buttons[x][y].player
				conditions.c1.c[#conditions.c1.c+1] = (buttons[x][y].player == buttons[x+1][y].player and buttons[x+1][y].player == buttons[x+2][y].player)
			end
		end
		if not find(conditions.c1.c, false) then
			return conditions.c1.p
		end

		-- vertical
		conditions.c2 = {p=nil,c={}}
		for x=0,sx-1 do
			for y=1,sy-3 do
				conditions.c2.p = buttons[x][y].player
				conditions.c2.c[#conditions.c2.c+1] = (buttons[x][y].player == buttons[x][y+1].player and buttons[x][y+1].player == buttons[x][y+2].player)
			end
		end
		if not find(conditions.c2.c, false) then
			return conditions.c2.p
		end
		--[[
		for y=0,sy-1 do -- horizontal
			if buttons[0][y].player == buttons[1][y].player and buttons[1][y].player == buttons[2][y].player then
				return buttons[0][y].player
			end
		end
		for x=0,sx-1 do -- vertical
			if buttons[x][0].player == buttons[x][1].player and buttons[x][1].player == buttons[x][2].player then
				return buttons[x][0].player
			end
		end
		-- cross
		local x = 0
		if buttons[0][0].player == buttons[1][1].player and buttons[1][1].player == buttons[2][2].player then
			return buttons[0][0].player
		end
		local p = (sx-1)
		if buttons[p][0].player == buttons[p][1].player and buttons[p][1].player == buttons[p][2].player then
			return buttons[p][0].player
		end
		--]]
	end
	makegame = function()
		for x = 0, sx-1 do
			buttons[x] = {}
			for y = 0, sy-1 do
				local newbutton = ButtonClass.new()
				newbutton.mouseButton1Down = function()
				if buttons[x][y].clicked then return end
				buttons[x][y].clicked = true
				buttons[x][y].player = (currentPlayer and 1 or 0)
					newbutton.text = (currentPlayer and "X" or "O")
					currentPlayer = not currentPlayer
					local winner = checkForWinState()
					if winner then
						print(winner, won)
						makegame()
					end
				end
				newbutton.size = Vector2.new(100,100)
				newbutton.position = Vector2.new(x*100,y*100)
				
				buttons[x][y] = {
					clicked = nil,
					player = nil,
					button = newbutton,
				}
			end
		end
	end
	makegame()
	love.window.setMode(sx*100, sy*100)
end

function love.update(dt)
	for x, list in pairs(buttons) do
		for y, button in pairs(list) do
			button.button:update(dt)
		end
	end
end

function love.draw()
	for x, list in pairs(buttons) do
		for y, button in pairs(list) do
			button.button:draw()
		end
	end
end