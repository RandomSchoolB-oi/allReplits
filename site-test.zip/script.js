function ColorElement(id) {
	var button = document.getElementById(id);
	button.style.backgroundColor = "red";
}

function Contact() {}