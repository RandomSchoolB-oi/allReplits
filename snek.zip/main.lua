require("Vector2")require("Color3")

local snake = {
	parts = {
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
		{
			position = Vector2.new(100, 100), 
			color = Color3.new(1, 1, 1)
		},
	},
}
local mouse = {
	position = Vector2.new(0,0)
}
clean = function(tbl)
local newTbl = {}
for i,v in pairs(tbl) do
newTbl[#newTbl+1] = v
end
return newTbl
end
love.window.setMode(400,400)
local timePassed = 0
function love.update(dt)
	mouse.position = Vector2.new(love.mouse.getX(), love.mouse.getY())
	timePassed = timePassed + dt
	if timePassed > 1/10 then
		local direction = (snake.parts[#snake.parts].position - mouse.position).unit * (10)
		local part = snake.parts[1]
		part.position = part.position - direction
		timePassed = 0
		snake.parts[1] = nil
		snake.parts = clean(snake.parts)
		snake.parts[#snake.parts+1] = part
	end
end

function love.draw()
    for i,v in pairs(snake.parts) do
		love.graphics.setColor(255,255,255)--(v.color())
		local x,y = v.position()
		local w,h = 10,10
		love.graphics.rectangle("fill", x,y, w,h)
	end
end