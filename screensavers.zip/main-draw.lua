local points = {}

function love.update(dt)
	if love.mouse.isDown(1) then
		local x,y = love.mouse.getX(), love.mouse.getY()
		points[#points+1] = {x,y}
	end
end

function love.draw()
	for i,v in pairs(points) do
		--love.graphics.circle("fill", v[1]-1.5,v[2]-1.5, 3)
		local lastPoint = points[i-1]
		if lastPoint then
			love.graphics.line(lastPoint[1], lastPoint[2], v[1], v[2])
		end
	end
end