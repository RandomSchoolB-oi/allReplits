local screenSize = {400,300}
local pixelSize = {4,4}

require("Color3")

layerNoise = function(x,y,seed, layers)
	local noise = 0
	local amp = .1
	local freq = 0.49
	for i=1, layers do
		noise = noise + love.math.noise(seed*freq+i*50,x*freq,y*freq)*amp
		freq = freq * 1.2
		amp = amp * .4
	end
	return noise
end

local savers = {
 	function(x,y) -- noise
	 	x,y = x/pixelSize[1],y/pixelSize[2]
		local freq = 0.19
		local seed = os.clock()

		-- local numb = love.math.noise(
		-- 	love.math.noise(
		-- 		seed,
		-- 		x*freq,
		-- 		y*freq
		-- 	) * 10,
		-- 	-- layerNoise(x,y,seed, 3)*10,
		-- 	x*freq,
		-- 	y*freq
		-- )
		local numb = layerNoise(
			x,
			y,
			os.clock(),
			10
		) * 10
		local from = Color3.new(1,1,1)
		local to = Color3.new(0,0,0)
		return from:lerp(to, numb)
		
	end,


	----[[
	function(x,y) -- stripe color
		return Color3.new(x % 2, y % 2, x % 2)
	end,

	function(x,y) -- stripe
		local numb = x % 2
		return Color3.new(numb, numb, numb)
	end,
	
	function(x,y) -- checker
		local numb = (x+y) % 2
		return Color3.new(numb, numb, numb)
	end,
	
	function(x,y)
		return Color3.new((x) % 8, (x) % 4, (x) % 2)
	end,

	function(x,y) -- temp
		local numb = 1
		return Color3.new(numb, numb, numb)
	end,

	function(x,y)
		local numb = 1-y/(screenSize[2]/pixelSize[2])
		return Color3.new(numb, numb, numb)
	end,

	function(x,y)
		local numb = 1-x/(screenSize[1]/pixelSize[1])
		return Color3.new(numb, numb, numb)
	end,
	
	function(x,y)
		local numb = 1-(x/((screenSize[1]/pixelSize[1])/2)) + 1-(y/((screenSize[2]/pixelSize[2])/2))
		return Color3.new(numb, numb, numb)
	end,
	--]]
}
--math.randomseed(os.time())
local chosen = 1--math.random(1,#savers)

draw = function()
	for x = 0, screenSize[1]/pixelSize[1] do
		for y = 0, screenSize[2]/pixelSize[2] do
			local color = savers[chosen](x,y)
			love.graphics.setColor(color())
			love.graphics.rectangle("fill", x*pixelSize[1], y*pixelSize[2], pixelSize[1],pixelSize[2])
		end
	end
end

love.keypressed = function(key)
	if key == "e" then
		chosen = (chosen%#savers) + 1 
	elseif key == "q" then
		chosen = chosen - 1 
		if chosen <= 0 then
			chosen = #savers
		end
	end
end

love.window.setMode(screenSize[1], screenSize[2])

love.draw = draw