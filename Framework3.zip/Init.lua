require("Framework.Libraries.Math")
require("Framework.Libraries.Graphics")
require("Framework.Libraries.Physics")
require("Framework.Libraries.Table")

Udim = require("Framework.Classes.Udim")
Udim2 = require("Framework.Classes.Udim2")
Color = require("Framework.Classes.Color")
Vector = require("Framework.Classes.Vector")
CFrame = require("Framework.Classes.CFrame")
Signal = require("Framework.Classes.Signal")
Cache = require("Framework.Classes.Cache")
Datastore = require("Framework.Classes.Datastore")
PhysicsObject = require("Framework.Classes.PhysicsObject")
Timer = require("Framework.Libraries.Timer")
Input = require("Framework.Libraries.Input")

GUI = {
	Frame = require("Framework.Classes.GUI.Frame"),
	Button = require("Framework.Classes.GUI.Button"),
	Text = require("Framework.Classes.GUI.Text"),
}

ScreenSize = Vector.new(200, 200)
BackgroundColor = Color.new(0, 0, 0, 255)
Camera = Vector.new(100,100)

Update = Signal.new()
Draw = Signal.new()

gameCache = Cache.new()

local privateKeys = {
	ScreenSize = gameCache:Set(nil, "ScreenSize"),
	BackgroundColor = gameCache:Set(nil, "BackgroundColor"),
}

love.update = function(dt)
	Update:Run(dt)
	Timer.wait(1/60)
end
love.draw = function()
	if ScreenSize ~= gameCache:Get(privateKeys.ScreenSize) then
		gameCache:Set(ScreenSize, privateKeys.ScreenSize)
		love.window.setMode(ScreenSize.X, ScreenSize.Y)
	end
	
	if BackgroundColor ~= gameCache:Get(privateKeys.BackgroundColor) then
		gameCache:Set(BackgroundColor, privateKeys.BackgroundColor)
		love.graphics.setBackgroundColor(BackgroundColor:GetRGB())
	end
	Draw:Run()
end