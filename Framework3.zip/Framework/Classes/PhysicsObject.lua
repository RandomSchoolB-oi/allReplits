local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.CFrame = CFrame.new()
	self.Size = Vector.new(100, 100)
	self.Color = Color.new(1,1,1,1)
	self.Velocity = Vector.new(0, 0)
	self.Active = true
	self.Connections = {
		Update:Connect(function(dt)
			
		end),
		Draw:Connect(function()
			self:draw()
		end)
	}
	return self
end

function module:draw()
	rect(self.CFrame, self.Size, self.Color)
end



return module