local module = {}
module.__index = module

module.new = function(scale, offset)
	local self = setmetatable({}, module)
	self.Scale = scale or 0
	self.Offset = offset or 0
	return self
end

function module:Lerp(other, a)
	return module.new(
		math.lerp(self.Scale, other.Scale, a),
		math.lerp(self.Offset, other.Offset, a)
	)
end

return module