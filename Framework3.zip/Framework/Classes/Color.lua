local module = {}
module.__index = module

module.new = function(r,g,b,a) -- [0-1]
	local self = setmetatable({}, module)
	self.R = r or 0
	self.G = g or 0
	self.B = b or 0
	self.A = a or 1
	return self
end

module.from255 = function(r,g,b,a) -- [0-255]
	return module.new((r or 0)/255, (g or 0)/255, (b or 0)/255)
end

function module:Lerp(b,t)
	return module.new(
		math.lerp(self.R, b.R, t),
		math.lerp(self.G, b.G, t),
		math.lerp(self.B, b.B, t),
		math.lerp(self.A, b.A, t)
	)
end

function module.Random()
	return module.from255(
		math.random(0,255),
		math.random(0,255),
		math.random(0,255),
		255
	)
end

function module:GetRGB()
	return self.R*255, self.G*255, self.B*255
end

function module:GetRGBA()
	return self.R*255, self.G*255, self.B*255, self.A*255
end

return module