local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Size = Udim2.new(0,100,0,100)
	self.Position = Udim2.new(0,0,0,0)
	self.AnchorPoint = Vector.new(0,0)
	self.Color = Color.new(1,1,1,1)

	self.AbsoluteSize = Vector.new(0,0)
	self.AbsolutePosition = Vector.new(0,0)
	
	self.Parent = nil
	self.Children = {}

	self.Visible = true
	
	return self
end

function module:RemoveParent()
	if self.Parent then
		table.remove(self.Parent.Children, table.find(self.Parent.Children, self))
		self.Parent = nil
	end
end

function module:AddFrame(frame)
	if frame.Parent then
		frame:RemoveParent()
	end
	frame.Parent = self
	table.insert(self.Children, frame)
end
function module:SetParent(parent)
	parent:AddFrame(self)
end

function module:update()
	local canvasSize = ScreenSize
	if self.Parent then
		canvasSize = self.Parent.AbsoluteSize
	end
	local size = self.Size:Calculate(canvasSize)
	local position = self.Position:Calculate(canvasSize)

	self.AbsoluteSize = size
	self.AbsolutePosition = position - size * self.AnchorPoint + Camera
	
	for _, frame in pairs(self.Children) do
		frame:update()
	end
end

function module:within(x, y)
	local min = self.AbsolutePosition
	local max = min + self.AbsoluteSize
	return x > min._x and x < max._x and y > min._y and y < max._y
end

function module:drawChildren()
	for _, frame in pairs(self.Children) do
		frame:draw()
	end
end

function module:draw()
	if not self.Visible then return end
	rect(self.AbsolutePosition, self.AbsoluteSize, 0, self.Color)

	self:drawChildren()
end

return module