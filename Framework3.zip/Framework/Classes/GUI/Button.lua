local module = {}
module.__index = module
local base = require("Framework.Classes.GUI.Frame")
setmetatable(module, base)

local onMousePressed = Input.MousePressed

module.new = function()
	local self = setmetatable(base.new(), module)
	self.Activated = Signal.new()

	self._inputConn = onMousePressed:Connect(function(key, x,y ,when)
		if key == 1 then
			if self:within(x,y) then
				self.Activated:Run(when)
				self.MouseDown = true
				Input.MouseReleased:Once(function(releaseKey)
					if releaseKey == 1 then
						self.MouseDown = false
					end
				end)
			end
		end
	end)
	
	return self
end

function module:draw()
	if not self.Visible then return end
	if self.MouseDown then -- lighter
		rect(self.AbsolutePosition, self.AbsoluteSize, 0, self.Color)
	elseif self:within(Mouse.X, Mouse.Y) then -- darker
		rect(self.AbsolutePosition, self.AbsoluteSize, 0, self.Color)
	else
		rect(self.AbsolutePosition, self.AbsoluteSize, 0, self.Color)
	end

	self:drawChildren()
end

return module