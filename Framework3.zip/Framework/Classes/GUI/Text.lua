local module = {}
module.__index = module
local base = require("Framework.Classes.GUI.Frame")
setmetatable(module, base)

local font = love.graphics.newFont(128, "normal")

module.new = function()
	local self = setmetatable(base.new(), module)
	self.Activated = Signal.new()

	self.Text = "Label"
	self.TextColor = Color.new(0,0,0,255)
	self.TextStretch = false
	self._textobjectCache = {lastText = "", textObject = nil}
	
	return self
end

function module:update()
	base.update(self)
	if self._textobjectCache.lastText ~= self.Text or not self._textobjectCache.textObject then
		self._textobjectCache.textObject = love.graphics.newText(font, self.Text)
		self._textobjectCache.lastText = self.Text
	end
end

function module:draw()
	if not self.Visible then return end
	base.draw(self)
	drawText(self.AbsolutePosition, self.AbsoluteSize, 0, self._textobjectCache.textObject, self.TextColor, self.TextStretch)
end

return module