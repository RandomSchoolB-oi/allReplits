local module = {}
module.__index = function(self, i)
	local moduleHas = rawget(self, i)
	if moduleHas then return moduleHas end
	
	if i == "X" or i == "x" then
		return rawget(self, "_x")
	elseif i == "Y" or i == "y" then
		return rawget(self, "_y")
	elseif i == "Magnitude" or i == "Length" then
		return math.sqrt(rawget(self, "_x")^2 + rawget(self, "_y")^2)
	elseif i == "Unit" or i == "Normalized" or i == "Normal" then
		local length = self.Magnitude
		
		return self/length
	end
	
	return nil
end

module.__newindex = function(self, i, v)
	if i == "X" or i == "x" then
		rawset(self, "_x", v)
	elseif i == "Y" or i == "y" then
		rawset(self, "_y", v)
	elseif i == "Magnitude" or i == "Length" then
		local length = self.Magnitude
		local x,y = self._x, self._y
		rawset(self, "_x", x/length * v)
		rawset(self, "_y", y/length * v)
	elseif i == "Unit" or i == "Normalized" then
		local length = self.Magnitude

		rawset(self, "_x", v._x * length)
		rawset(self, "_y", v._y * length)
	end
end

module.new = function(x,y)
	local self = setmetatable({
			_x = x or 0,
			_y = y or 0
	}, module)

	return self
end

function module:Lerp(b,t)
	return module.new(
		math.lerp(self._x, b._x, t),
		math.lerp(self._y, b._y, t)
	)
end

function module:__add(other)
	return module.new(self._x + other._x, self._y + other._y)
end
function module:__sub(other)
	return module.new(self._x - other._x, self._y - other._y)
end
function module:__mul(other)
	if type(other) == "number" then
		return module.new(self._x * other, self._y * other)
	end
	return module.new(self._x * other._x, self._y * other._y)
end
function module:__div(other)
	if type(other) == "number" then
		return module.new(self._x / other, self._y / other)
	end
	return module.new(self._x / other._x, self._y / other._y)
end

function module:__eq(other)
	return self._x == other._x and self._y == other._y
end

function module:__lt(other)
	return self._x < other._x and self._y < other._y
end
function module:__le(other)
	return self._x <= other._x and self._y <= other._y
end

module.zero = module.new(0, 0)
module.left = module.new(-1, 0)
module.right = module.new(0, 1)
module.up = module.new(0, -1)
module.down = module.new(0, 1)
module.one = module.new(1, 1)

return module