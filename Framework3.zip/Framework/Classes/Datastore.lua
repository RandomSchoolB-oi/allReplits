-- usage
--[[
local playerData = Datastore:GetDatastore("BobData")

local key = "Bob"
local val = playerData:IncrementAsync(key)

print(val)
]]

function getStr(value)
	if type(value) == "string" then
		return "\""..value.."\""
	elseif type(value) == "table" then
		return tableToString(value)
	else
		return tostring(value)
	end
end

function tableToString(tbl)
	local str = "{"
	for index, value in pairs(tbl) do
		local indexString = "["..getStr(index).."]"
		local valueString = getStr(value)
		
		str = str..indexString.." = "..valueString..","
	end
	str = str.."}"
	return str
end

function getValue(str)
	return loadstring("return "..str)()
end

local Datastore = {}
Datastore.__index = Datastore

local datastoreCache = {}

function Datastore:GetDatastore(name)
	if datastoreCache[name] then
		return datastoreCache[name]
	end
	local self = setmetatable({}, Datastore)
	self.name = name
	self.path = "Framework/StoredData/"..name
	pcall(function()
		os.execute("mkdir " .. self.path)
	end)

	datastoreCache[name] = self
	
	return self
end

function Datastore:SetAsync(key, data)
	local str = getStr(data)
	local f = io.open(self.path.."/"..key, "w")
	f:write("", str)
	f:close()
end

function Datastore:GetAsync(key)
	local f = io.open(self.path.."/"..key, "r")
	if f then
   		local t = f:read("*all")
	    f:close()
	
		return getValue(t)
	end
end

function Datastore:IncrementAsync(key, amount)
	local amount = amount or 1
	local hasVal = self:GetAsync(key)
	if type(hasVal) ~= "number" then
		hasVal = 0
	end
	local val = (hasVal or 0) + amount
	self:SetAsync(key, val)
	
	return val
end

return Datastore