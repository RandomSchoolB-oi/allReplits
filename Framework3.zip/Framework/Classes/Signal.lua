local module = {}
module.__index = module

module.new = function()
	return setmetatable({}, module)
end

function module:Connect(callback)
	local connection connection = {
		callback = callback,
		Disconnect = function()
			for i, conn in pairs(self) do
				if conn == connection then
					table.remove(self, i)
					break
				end
			end
		end,
	}

	table.insert(self, connection)
	return connection
end

function module:Once(callback)
	local connection = self:Connect(function()
		callback()
		connection:Disconnect()
	end)
	return connection
end

function module:Wait()
	local start = os.clock()
	local thread = coroutine.running()
	self:Once(function(...)
		coroutine.resume(...)
	end)
	
	return coroutine.yield(thread)
end

function module:Run(...)
	local args = {...}
	for _, conn in pairs(self) do
		coroutine.wrap(conn.callback)(unpack(args))
		-- conn.callback(unpack(args))
	end
end

return module