local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.cache = {}
	self.serial = 0
	return self
end

function module:Get(key)
	return self.cache[key]
end

function module:Set(value, key)
	if not key then
		key = self.serial
		self.serial = self.serial + 1
	end

	self.cache[key] = value

	return key
end

return module