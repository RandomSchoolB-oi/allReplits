local module = {}
local pi = math.pi
local hpi = pi/2
module.__index = function(self, i)
	local moduleHas = rawget(self, i)
	if moduleHas then return moduleHas end
	
	local r = rawget(self,"_r")
	
	if i == "R" or i == "r" then
		return r
	elseif i == "Forward" then
		return Vector.new(math.cos(r - hpi), math.sin(r - hpi))
	elseif i == "Back" then
		return Vector.new(math.cos(r + hpi), math.sin(r + hpi))
	elseif i == "Right" then
		return Vector.new(math.cos(r), math.sin(r))
	elseif i == "Left" then
		return Vector.new(math.cos(r+pi), math.sin(r+pi))
	end
	
	return nil
end

module.__newindex = function(self, i, v)
	if i == "R" or i == "r" then
		rawset(self, "_r", v)
	end
end

module.new = function(x,y,r)
	local self = setmetatable({
		Position = Vector.new(x,y),
		_r = r or 0,
	}, module)

	return self
end

function module:Lerp(b,t)
	local lerpedPos = self.Position:Lerp(b.Position, t)
	return module.new(
		lerpedPos._x,
		lerpedPos._y,
		math.lerp(self._r, b._r, t)
	)
end

function module:__add(other)
	local selfPos = self.Position
	return module.new(selfPos._x + other._x, selfPos._y + other._y)
end
function module:__sub(other)
	local selfPos = self.Position
	return module.new(selfPos._x - other._x, selfPos._y - other._y)
end
function module:__mul(other)
	local movedX = self.Position._x * other.Position._x
	local movedY
end
function module:__div(other)
	if type(other) == "number" then
		return module.new(self._x / other, self._y / other)
	end
	return module.new(self._x / other._x, self._y / other._y)
end

return module