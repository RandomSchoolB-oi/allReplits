local module = {}
module.__index = module

module.new = function(xScale, xOffset, yScale, yOffset)
	local self = setmetatable({}, module)
	self.X = Udim.new(xScale, xOffset)
	self.Y = Udim.new(yScale, yOffset)
	return self
end

function module:Calculate(canvasSize)
	if not canvasSize then
		canvasSize = ScreenSize
	end

	return Vector.new(
		self.X.Scale * canvasSize.X + self.X.Offset,
		self.Y.Scale * canvasSize.Y + self.Y.Offset
	)
end

function module:Lerp(other, a)
	local x,y = self.X:Lerp(other.X, a), self.Y:Lerp(other.Y, a)

	return module.new(
		x.Scale,
		x.Offset,
		y.Scale,
		y.Offset
	)
end

return module