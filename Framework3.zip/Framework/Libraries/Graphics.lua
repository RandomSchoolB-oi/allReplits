local gr = love.graphics

rectCF = function(cf, size, color)
	local pos = cf.Position
	gr.push()
	gr.translate(pos._x, pos._y)
	gr.rotate(cf._r)
	love.graphics.setColor(color:GetRGBA())
	gr.rectangle("fill", -size._x/2, -size._y/2, size._x, size._y)
	gr.pop()
end

rect = function(pos, size, rot, color)
	gr.push()
	gr.translate(pos._x, pos._y)
	gr.rotate(rot)
	love.graphics.setColor(color:GetRGBA())
	gr.rectangle("fill", 0, 0, size._x, size._y)
	gr.pop()
end


drawText = function(pos, size, rot, text, color, stretch)
	gr.push()
	gr.translate(pos._x, pos._y)
	gr.rotate(rot)
	local textSize = Vector.new(text:getDimensions())
	local scale = size / textSize
		-- print(scale())
	if not stretch then
		local normal = math.min(scale.X, scale.Y)
		scale.X, scale.Y = normal, normal
		local stretchOffset = size/2 - (scale*textSize)/2
		gr.translate(stretchOffset._x, stretchOffset._y)
	end
	love.graphics.setColor(color:GetRGBA())
	love.graphics.draw(text, 0, 0, 0, scale.X, scale.Y)
	gr.pop()
end