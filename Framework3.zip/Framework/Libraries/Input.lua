local module = {}

module.KeyPressed = Signal.new()
module.KeyReleased = Signal.new()
module.MousePressed = Signal.new()
module.MouseReleased = Signal.new()

local keyPresses = {}
local mousePresses = {}

love.keypressed = function(key)
	local t = os.clock()
	keyPresses[key] = t
	module.KeyPressed:Run(key, t)
end
love.keyreleased = function(key)
	local t = os.clock()
	local whenPressed = keyPresses[key]
	if whenPressed then
		keyPresses[key] = nil
		module.KeyReleased:Run(key, t-whenPressed)
	end
end

love.mousepressed = function(x,y,key)
	local t = os.clock()
	mousePresses[key] = t
	module.MousePressed:Run(key, x,y, t)
end
love.mousereleased = function(x,y,key)
	local t = os.clock()
	local whenPressed = mousePresses[key]
	if whenPressed then
		mousePresses[key] = nil
		module.MouseReleased:Run(key, x,y, t-whenPressed)
	end
end
Mouse = setmetatable({},{__index = function(_, i)
	if i == "X" then
		return love.mouse.getX()
	elseif i == "Y" then
		return love.mouse.getX()
	end
end, __newindex = function(_, i, v)
	if i == "X" then
		love.mouse.setX(v)
	elseif i == "Y" then
		love.mouse.setY(v)
	end
end})

return module