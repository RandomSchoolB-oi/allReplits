table.find = function(tbl, value)
	for i, v in pairs(tbl) do
		if v == value then
			return i
		end
	end
end