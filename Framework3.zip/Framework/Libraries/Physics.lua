physics = {}

physics.IsCollidingAABB = function(p1, p2) -- (colliding, depth, normal)
	local bigSize = p1.Size + p2.Size
	local halfBigSize = bigSize/2
	local difference = p1.CFrame.Position - p2.CFrame.Position
	local aX,aY = math.abs(difference._x), math.abs(difference._y)
	if aX < halfBigSize._x and aY < halfBigSize._y then
		return true, (halfBigSize - difference).Length, difference.Unit
	end
	return false, 0, Vector.zero
end

physics.Step = function(objects)
	local len = #objects
	for i = 1, len-1, 1 do
		local p1 = objects[i]
		for j = i+1, len, 1 do
			local p2 = objects[j]
			local colliding, depth, normal = physics.IsCollidingAABB(p1,p2)
			if colliding then
				
			end
		end
	end
end