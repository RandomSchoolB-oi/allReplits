function math.clamp(numb, min, max)
	return math.max(math.min(numb, max), min)
end

function math.round(numb)
	return math.floor(numb+0.5)
end

function math.lerp(a, b, t)
	return (b-a) * t + a
end