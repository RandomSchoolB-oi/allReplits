local module module = {
	wait = function(t)
		local s = os.clock()
		local lt
		while true do
			if lt and lt - s > t then
				break
			else
				lt = os.clock()
			end
		end
		return lt - s
	end,

	delay = function(t, callback, ...)
		local args = {...}
		coroutine.create(function()
			coroutine.close()
			module.wait(t)
			callback(unpack(args))
		end)
	end,

	spawn = function(callback, ...)
		coroutine.wrap(callback)(...)
	end,
}
return module