require("Init")
ScreenSize = Vector.new(200, 200)
BackgroundColor = Color.new(0, 0, 0, 1)

local board = {}

local function check()
	-- horizontal check
	for y = 1, 3 do
		local player = board[1][y]
		local win = true
		for x = 1, 3 do
			local p = board[x][y]
			if p ~= player or not p then
				win = false
				break
			end
		end
		if win then 
			return player 
		end
	end
	-- vertical check
	for x = 1, 3 do
		local player = board[x][1]
		local win = true
		for y = 1, 3 do
			local p = board[x][y]
			if p ~= player or not p then
				win = false
				break
			end
		end
		if win then 
			return player 
		end
	end
	-- diagonal check
	do
		local player = board[i][i]
		local win = true
		for i = 1, 3 do
			local p = board[i][i]
			if p ~= player or not p then
				win = false
				break
			end
		end
		if win then 
			return player
		end
	end
	do
		local player = board[i][4-i]
		local win = true
		for i = 1, 3 do
			local p = board[i][4-i]
			if p ~= player or not p then
				win = false
				break
			end
		end
		if win then 
			return player
		end
	end
end

local function commenceWin(winner)
	for i = 1, 20 do
		print("Winner winner, chicken dinner. Player".. tostring(winner).." won!!")
	end
end

local function click(player, x,y)
	board[x][y] = player
	local won = check()
	if won then 
		commenceWin(won)
	end
end

local isPlayer1 = true
local buttons = {}

for x = 1,3 do
	board[x] = {}
	for y = 1,3 do
		local button = GUI.Button.new()
		button.Size = Udim2.new(1/3,0,1/3,0)
		button.Position = Udim2.new(1/3 * (x-1),0,1/3 * (y-1),0)
		buttons[#buttons+1] = button
		button.Activated:Once(function()
			click(isPlayer1 and 1 or 2, x,y)
		end)
	end
end
Camera = Vector.new(0, 0)

Update:Connect(function(dt)
	for i, button in ipairs(buttons) do
		button:update(dt)
	end
end)

Draw:Connect(function()
	for i, button in ipairs(buttons) do
		button:draw()
	end
end)