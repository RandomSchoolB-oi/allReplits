local w, h = 20, 20

local function lerp(a,b,x)
	return (b-a)*x+a
end

local asciiList = string.reverse([[$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~<>i!lI;:,"^`'.]])
local asciiLength = asciiList:len()

local function round(x)
	return math.floor(x+0.5)
end
local function clamp(x, a,b)
	if x < a then
		return a
	elseif x > b then
		return b
	else
		return x
	end
end
local function GetCharacter(brightness)
	local b = clamp(brightness, 0, 1)
	local nearestChar = clamp(round(b * asciiLength), 1, asciiLength)

	return asciiList:sub(nearestChar, nearestChar)
end

local function shape(x,y)
	local cx, cy = w/2, h/2
	local radius = 8
	local d = math.sqrt((x-cx)^2 + (y-cy)^2)

	local a = (x%2 + y%2)%2
	return 1-lerp(a,1, clamp(d/radius, 0, 1))
end

for y = 1, h do
	local text = ""
	for x = 1, w do
		text = text .. GetCharacter(shape(x,y)).." "
	end
	print(text)
end