local function loadClass(name)
    return require("Framework/Classes/"..name)
end

local function reqDirectory(dir)
	local list = {}
	local folders = {}
	for _, fileName in ipairs(love.filesystem.getDirectoryItems(dir)) do
		local value
		local fileDir = dir.."/"..fileName
		if fileName:find(".lua") then
			local modName = fileName:gsub(".lua", "")
			list[modName] = require(fileDir:gsub(".lua", ""))
		else
			table.insert(folders, fileName)
		end
	end
	for _, fileName in ipairs(folders) do
		list[fileName] = reqDirectory(dir.."/"..fileName)
	end
	return list
end

local function recursePrint(tbl)
	for i,v in pairs(tbl) do
		if type(v) == "table" then
			print(tostring(i).." = {")
			recursePrint(v)
			print("}")
		else
			print(tostring(i).." = "..tostring(v))
		end
	end
end

local originalTypeFunction = type
function type(v)
	local regType = originalTypeFunction(v)
	if regType == "table" and v.Type then
		return v.Type
	end
	return regType
end

Framework = {}
Framework.Classes = reqDirectory("Framework/Classes")
Vector = Framework.Classes.Vector
Udim2 = Framework.Classes.Udim2
Maid = Framework.Classes.Maid
Spring = Framework.Classes.Spring
Signal = Framework.Classes.Signal
Game = Framework.Classes.Game
Instance = Framework.Classes.Instance
BaseInstance = Framework.Classes.BaseInstance

Framework.Instances = reqDirectory("Framework/Instances")
Scene = Framework.Instances.Scene

OnDraw = Signal.new()
OnUpdate = Signal.new()


local fps = 1/60
local et = 0
function love.update(dt)
	et = et + dt
	if et >= fps then
		OnUpdate:Fire(et)
		et = et - fps
	end
end
function love.draw()
	OnDraw:Fire()
end

local gameList = {"TestBranch"}
for i, v in pairs(gameList) do
	print("["..tostring(i).."] = "..v..",")
end
print("type the number of the game")
local gameName = gameList[1] --gameList[tonumber(io.read())]
-- os.execute()
if not gameName then print("Invalid Game") return end
print("loading: "..gameName)
require("Games/"..gameName.."/main")