return {
	PartShape = {
		Box = 1,
		Circle = 2,
	}
}