local module = {}
module.__index = module
module.Type = "Scene"

local scenes = {}
local serial = 0

module.new = function()
	serial = serial + 1
	local self = setmetatable({}, module)
	self.UniqueId = serial
	self.Objects = {}
	self._maid = Maid.new()
	self.OnDraw = Signal.new()
	self.OnUpdate = Signal.new()
	self.Enabled = true
	self.Paused = false
	
	self._maid:GiveTask(self.OnUpdate)
	self._maid:GiveTask(self.OnDraw)
	self._maid:GiveTask(self.OnUpdate:Connect(function(dt)
		if not self.Enabled or self.Paused then return end
		for id in pairs(self.Objects) do
			local object = BaseInstance.GetObjectById(id)
			if object then
				object:_update(dt)
			end
		end
	end))
	self._maid:GiveTask(self.OnDraw:Connect(function()
		if not self.Enabled then return end
		for id in pairs(self.Objects) do
			local object = BaseInstance.GetObjectById(id)
			if object then
				object:_draw()
			end
		end
	end))

	scenes[self.UniqueId] = self
	
	return self
end

function module.GetSceneById(id)
	return scenes[id]
end

function module:RemoveObject(object)
	self.Objects[object.UniqueId] = nil
	self.Scene = nil
end

function module:GiveObject(object)
	local oldScene = object:GetScene()
	if oldScene then
		oldScene:RemoveObject(object)
	end
	self.Objects[object.UniqueId] = true
	object.Scene = self.UniqueId
end

function module:Destroy()
	self._maid:Destroy()
end

return module