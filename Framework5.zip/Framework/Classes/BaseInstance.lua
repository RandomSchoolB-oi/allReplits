local module = {}
-- module.Type = "BaseInstance"

local serial = 1
local partLookup = {}
local moduleLookup = {}
local moduleIndices = {}

module.__index = function(self, i)
	local selfHas = rawget(self, i)
	if selfHas then return selfHas end
	
	local moduleHas = rawget(module, i)
	if moduleHas then return moduleHas end

	local listenProps = rawget(self, "_listenProperties")
	if listenProps and listenProps[i] then
		return listenProps[i].value
	end
	
	local extraModules = rawget(self, "_extraModules")
	if extraModules then
		for index in pairs(extraModules) do
			local mod = moduleLookup[index]
			if mod then
				local modHas = rawget(mod, i)
				if modHas then return modHas end
			end
		end
	end
end
module.__newindex = function(self, i, v)
	local listenProps = rawget(self, "_listenProperties")
	if listenProps and listenProps[i] then
		local newValue = listenProps[i].callback(v)
		listenProps[i].value = newValue
		return
	end
	rawset(self, i,v)
end
-- make a metatable listen for indices and call the callback and set it somewhere

module.new = function()
	local self = {}
	self._maid = Maid.new()
	self._listenProperties = {}
	self._extraModules = {}
	self.UniqueId = serial
	partLookup[self.UniqueId] = self
	serial = serial + 1
	self._maid:GiveTask(function()
		partLookup[self.UniqueId] = nil
	end)
	
	return setmetatable(self, module)
end

function module.GetObjectById(id)
	return partLookup[id]
end

function module:GiveModule(mod)
	if not moduleIndices[mod] then
		serial = serial + 1
		moduleIndices[mod] = serial
		moduleLookup[moduleIndices[mod]] = mod
	end
	self._extraModules[moduleIndices[mod]] = true
end

function module:GetScene()
	return Scene.GetSceneById(self.Scene)
end

function module:GiveListenProperty(index, callback)
	self._listenProperties[index] = {
		value = nil, 
		callback = callback
	}
end

return module