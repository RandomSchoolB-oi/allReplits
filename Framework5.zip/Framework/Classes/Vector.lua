local module = {}
module.Type = "Vector"
module.__index = function(self, i)
	local has = rawget(self, i)
	if has then return has end
	local has2 = rawget(module, i)
	if has2 then return has2 end

	if self ~= module then
		if i == "Unit" then
			return self/self.Magnitude
		elseif i == "Magnitude" then
			return math.sqrt(self.X^2+self.Y^2)
		end
	end
end

module.new = function(x, y)
	return setmetatable({
		X = x or 0,
		Y = y or 0,
	}, module)
end

module.fromAngle = function(angle)
	return module.new(math.cos(angle), math.sin(angle))
end

function module:__add(other)
	return module.new(self.X+other.X, self.Y+other.Y)
end
function module:__sub(other)
	return module.new(self.X-other.X, self.Y-other.Y)
end
function module:__div(other)
	if type(other) == "number" then
		return module.new(self.X/other, self.Y/other)
	end
	return module.new(self.X/other.X, self.Y/other.Y)
end
function module:__mul(other)
	if type(other) == "number" then
		return module.new(self.X*other, self.Y*other)
	end
	return module.new(self.X*other.X, self.Y*other.Y)
end
function module:__unm()
	return self*-1
end
function module:__eq(other)
	return self.X == other.X and self.Y == other.Y
end
function module:__call()
	return self.X, self.Y
end
function module:ToAngle()
	return math.atan2(self.Y, self.X)
end

function module:Cross(other)
	local t = type(other)
	assert(t == "table", "Attempted operation \"cross\" on a "..type(self).." and a "..t)
	return self.X * other.Y + self.Y * other.X
end

function module:Lerp(other, a)
	return module.new((other.X-self.X)*a + self.X, (other.Y-self.Y)*a + self.Y)
end

-- function module:Rotate(rot)
-- 	local r  = self:ToAngle() + rot
-- 	local s,c = math.sin(r), math.cos(r)

-- 	return module.new(s,c)
-- end

function module.GetRotationMatrix(rot)
	return {
		{math.cos(rot), -math.sin(rot)},
		{math.sin(rot), math.cos(rot)},
	}
end

function module:MatrixMultiply(matrix)
	-- local matrix = {
	-- 	{1,0},
	-- 	{0,1},
	-- }

	local v = {self.X, self.Y}

	local newMatrix = {}

	for i = 1, #matrix do
		for index, value in pairs(v) do
			newMatrix[i] = (newMatrix[i] or 0) + matrix[i][index] * value
		end
	end

	return module.new(newMatrix[1],newMatrix[2])
end

function module:Reflect(normal)
	local t = type(other)
	assert(t == "table", "Attempted operation \"reflect\" on a "..type(self).." and a "..t)
	return self - (normal * self:Dot(normal) * 2)
end

function module:Dot(other)
	local t = type(other)
	assert(t == "table", "Attempted operation \"dot\" on a "..type(self).." and a "..t)
	return self.X * other.X + self.Y * other.Y
end

function module:AngleBetween(normal)
	local t = type(other)
	assert(t == "table", "Attempted operation \"angleBetween\" on a "..type(self).." and a "..t)
	return math.deg(math.acos(clamp(-self.Unit:Dot(normal), -1, 1)))
end

return module