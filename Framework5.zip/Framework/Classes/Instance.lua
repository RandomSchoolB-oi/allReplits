local module = {}
module.__index = module
module.Type = "Instance"

local classes = {}

module.new = function(className, ...)
	return classes[className].new(...)
end

function module:RegisterClass(className, class)
	classes[className] = class
end

return module