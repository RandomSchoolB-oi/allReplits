local module = {}
module.__index = module
module.Type = "Game"

module.new = function()
	local self = setmetatable({}, module)
	self._maid = Maid.new()
	self.Scenes = {Default = Instance.new("Scene", self)}
	self.OnDraw = Signal.new()
	self.OnUpdate = Signal.new()
	self._maid:GiveTask(self.OnDraw)
	self._maid:GiveTask(self.OnUpdate)
	
	self._maid:GiveTask(OnDraw:Connect(function()
		self.OnDraw:Fire()
		for sceneName, scene in pairs(self.Scenes) do
			if scene.Enabled then
				scene.OnDraw:Fire()
			end
		end
	end))
	self._maid:GiveTask(OnUpdate:Connect(function(dt)
		self.OnUpdate:Fire(dt)
		for sceneName, scene in pairs(self.Scenes) do
			if scene.Enabled and not scene.Paused then
				scene.OnUpdate:Fire(dt)
			end
		end
	end))

	return self
end

function module:GiveScene(name,scene)
	self.Scenes[name] = scene or Instance.new("Scene", self)
end

function module:Destroy()
	self._maid:Destroy()
	for _, scene in pairs(self.Scenes) do
		scene:Destroy()
	end
end

return module