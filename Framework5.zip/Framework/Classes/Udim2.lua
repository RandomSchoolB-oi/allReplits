local module = {}
module.__index = module
module.Type = "Udim2"

module.new = function(scaleX, offsetX, scaleY, offsetY)
	local self = setmetatable({
		ScaleX = scaleX or 0,
		ScaleY = scaleY or 0,
		OffsetX = offsetX or 0,
		OffsetY = offsetY or 0,
	}, module)
end

module.fromScale = function(x,y)
	return module.new(x,0,y,0)
end
module.fromOffset = function(x,y)
	return module.new(0,x,0,y)
end

function module:Project(size)
	return Vector.new(size.X * self.ScaleX + self.OffsetX, size.Y * self.ScaleY + self.OffsetY)
end

return module