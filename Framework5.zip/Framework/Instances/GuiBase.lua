local module = {}
module.__index = module
setmetatable(module, BaseInstance)
module.Type = "GuiBase"

module.new = function()
	local self = BaseInstance.new()
	self:GiveModule(module)
	self._gameMaid = Maid.new()
	
	self.Position = Udim2.new(0, 0, 0, 0)
	self.Size = Udim2.fromOffset(100, 100)
	self.AnchorPoint = Vector.new(0, 0)
	
	self:GiveListenProperty("Parent", function(newValue)
		self._parentMaid:Destroy()
		if newValue and newValue.Type == "Game" then
			self._parentMaid:GiveTask(newValue.OnDraw:Connect(function()
				self:_draw()			
			end))
			self._parentMaid:GiveTask(newValue.OnUpdate:Connect(function(dt)
				self:_update(dt)			
			end))
		end
		return newValue
	end)
	
	return self
end

function module:_update(dt)
	
end

function module:_draw()
	love.graphics.push()
	love.graphics.translate(self.Position.X, self.Position.Y)
	love.graphics.rectangle("fill", -self.Size.X/2, -self.Size.Y/2, self.Size.X, self.Size.Y)
	love.graphics.pop()
end

Instance:RegisterClass("GuiBase", module)

return module