local module = {}
module.__index = module
setmetatable(module, BaseInstance)
module.Type = "BasePart"

module.new = function()
	local self = BaseInstance.new()
	self:GiveModule(module)
	self._parentMaid = Maid.new()
	
	self.Position = Vector.new(0, 0)
	self.Size = Vector.new(100, 100)

	self:GiveListenProperty("Scene", function(newValue)
		if newValue then
			newValue:GiveObject(self)
			return newValue.UniqueId
		end
	end)
	
	return self
end

function module:_update(dt)
	local t = os.clock() * 4
	local r = 50
	self.Position = Vector.new(math.sin(t)*r+100, math.cos(t)*r+100)
end

function module:_draw()
	love.graphics.push()
	love.graphics.translate(self.Position.X, self.Position.Y)
	love.graphics.rectangle("fill", -self.Size.X/2, -self.Size.Y/2, self.Size.X, self.Size.Y)
	love.graphics.pop()
end

Instance:RegisterClass("BasePart", module)

return module