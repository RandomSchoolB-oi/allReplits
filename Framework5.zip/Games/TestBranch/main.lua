local game = Game.new()
local part = Instance.new("BasePart")
part.Scene = game.Scenes.Default