require("Libraries.Vector2")
require("Libraries.Color3")
require("Data.Plants")
require("Data.ColorData")
require("Data.Zombies")
local LevelData = require("Data.RoundData")

dimensions = {8,6}
boardPixelSize = 75
showHealth = false
nocooldown = false
infinitesuns = t
brightness = 1
speedmultiplier = 1

local devTest = true
if devTest then
	-- showHealth = true
	nocooldown = true
	infinitesuns = true
	speedmultiplier = 2
end

local board = {}
local lawnmowers = {}
local zombies = {}
local bullets = {}
local suns = {}
local currentPlant

for wave, roundData in pairs(LevelData) do
	lastSun = 0
	elapsedTime = 0
	dt = 0

	local sunCount = infinitesuns and math.huge or 50



	function newBullet(tower, x,y)
		bullets[#bullets+1] = {
			Position = Vector2.new(x,y), 
			damage = itemData[tower.name].damage, 
			speed = itemData[tower.name].speed,
			when = elapsedTime,
			lifetime = itemData[tower.name].shotDecay,
			from = tower,
			speedMul = itemData[tower.name].speedMul,
			speedTime = itemData[tower.name].speedTime,
		}
	end

	function newZombie(possible)
		local name = possible[math.random(1, #possible)]
		local chosen = ZombieData[name]

		zombies[#zombies+1] = {
			Position = Vector2.new(
				(dimensions[1]) * boardPixelSize, 
				math.floor(math.random(0,dimensions[2]-1)+.5)*boardPixelSize
			), 
			Size = Vector2.new(boardPixelSize, boardPixelSize), 
			maxSpeed = chosen.speed,
			speedMul = 1, 
			health = chosen.health,
			maxHealth = chosen.health,
			lastHit = 0,
			name = name,
		}
	end

	function clamp(numb, min, max)
		return numb < min and min or numb > max and max or numb
	end

	love.load = function()
		for i=0, dimensions[2]-1 do
			lawnmowers[i] = {
				Position = Vector2.new(0, i * boardPixelSize),
				Size = Vector2.new(-boardPixelSize/2, i * boardPixelSize)
			}
		--	local temp = {
		--		Position = Vector2.new(x,y), 
		--		damage = itemData[tower.name].damage, 
		--		speed = itemData[tower.name].speed,
		--		when = elapsedTime,
		--		lifetime = itemData[tower.name].shotDecay,
		--		from = tower,
		--		speedMul = itemData[tower.name].speedMul,
		--		speedTime = itemData[tower.name].speedTime,
		--	}
		end

		for x, column in pairs(board) do
			for y, data in pairs(column) do
				column[y] = {
				--	name =  "Sunflower", 
				--	health = itemData["Sunflower"].health,
				--	lastShot = 0, 
				--	lastBurst = 0, burstQuantity = 0
				}
			end
		end
	end

	love.window.setMode(dimensions[1] * boardPixelSize, (dimensions[2]+1) * boardPixelSize, {resizable = true})

	for x = 0, dimensions[1]-1 do
		board[x] = {}
		for y = 0, dimensions[2]-1 do
			board[x][y] = {}
		end
	end

	function love.update(T)
		dt = T*(speedmultiplier)
		--speedmultiplier = clamp(speedmultiplier + T / 5, 0, 10)
		elapsedTime = elapsedTime + dt

		for i,v in pairs(roundData) do
			if i <= elapsedTime then
				if (v.quantitySent or 0) >= v.quantity then
					roundData[i] = nil
				else
					if (elapsedTime - (v.lastSend or 0)) > v.timeDelay then
						v.quantitySent = (v.quantitySent or 0) + 1
						v.lastSend = elapsedTime
						newZombie(v.possible or {"Craig"})
					end
				end
			end
		end
		
		if elapsedTime - lastSun > math.random(20,30) then
			suns[#suns+1] = {
				Position = Vector2.new(clamp(math.random(boardPixelSize/2, dimensions[1]*boardPixelSize - boardPixelSize/2),boardPixelSize/2, dimensions[1]*boardPixelSize-boardPixelSize/2), clamp(math.random(boardPixelSize/2, dimensions[2]*boardPixelSize - boardPixelSize/2),boardPixelSize/2,dimensions[2]*boardPixelSize-boardPixelSize/2)), 
				give = 25,
				when = elapsedTime
				}
			lastSun = elapsedTime
		end

		for i,v in pairs(suns) do
			if elapsedTime - v.when > 25 then
				suns[i] = nil
			end
		end

		for x, row in pairs(board) do
			for y, data in pairs(row) do
				if data.name then
					if data.lastEmit and elapsedTime - data.lastEmit > itemData[data.name].emitRate then
						data.lastEmit = elapsedTime
						suns[#suns+1] = {Position = Vector2.new(
							(x * boardPixelSize) + (boardPixelSize/2),
							(y * boardPixelSize) + (boardPixelSize/2)
							),
							give = itemData[data.name].sunGive or 25,
							when = elapsedTime,
						}
					end
					local main, burst = elapsedTime - data.lastShot >= itemData[data.name].rate, elapsedTime - data.lastBurst >= itemData[data.name].burstDelay
					local zombieOnRow
					for i,v in pairs(zombies) do
						if v.Position.Y / boardPixelSize == y then
							zombieOnRow = true
						end
					end
					if (main or burst) and zombieOnRow then
						local run = true
						if main then
							data.lastShot = elapsedTime
							data.burstQuantity = 0
						end
						if burst then
							if elapsedTime - data.lastBurst >= itemData[data.name].burstDelay then
								if data.burstQuantity < itemData[data.name].burstAmount then
									data.lastBurst = elapsedTime
									data.burstQuantity = data.burstQuantity + 1
								else
									run = false
								end
							end
						end
						if run then
							newBullet(data, (x+1)*boardPixelSize, y*boardPixelSize + (boardPixelSize/2))
						end
					end
				end
			end
		end
		for i,v in pairs(bullets) do
			if elapsedTime - v.when > v.lifetime then
				bullets[i] = nil
			else
				v.Position = v.Position + Vector2.new(v.speed * dt, 0)
			end
		end
		for i,v in pairs(zombies) do
			local boardY = (v.Position.Y - (v.Position.Y % boardPixelSize))/boardPixelSize
			local boardX = (v.Position.X - (v.Position.X % boardPixelSize))/boardPixelSize
			local plantOnRow
			if board[boardX] and board[boardX][boardY] and board[boardX][boardY].name then
				
				if elapsedTime - (v.lastSwing or 0) >= (ZombieData[v.name].hitSpeed/v.speedMul) then
					board[boardX][boardY].health = board[boardX][boardY].health - ZombieData[v.name].damage
					if board[boardX][boardY].health <=0 then
						board[boardX][boardY] = {}
					end
					v.lastSwing = elapsedTime
					v.lastHit = elapsedTime
				end
				plantOnRow = true
			end
			if not plantOnRow then
				v.Position = v.Position - Vector2.new(v.maxSpeed * v.speedMul * dt, 0)
			end
			if v.Position.X < 0 then
				love.mousepressed = function()

				end
				love.draw = function()
					love.graphics.setColor(170,255,0)
					love.graphics.print("you died")
				end
				love.update = function(dt)

				end
			end
			if v.unspeed and v.unspeed <= elapsedTime then
				v.speedMul = 1
				v.unspeed = nil
			end
			for bulletIndex,bullet in pairs(bullets) do
				if bullet.Position > v.Position and bullet.Position < v.Position + v.Size then
					bullets[bulletIndex] = nil
					v.health = v.health - bullet.damage
					if bullet.speedMul then
						v.speedMul = bullet.speedMul
						v.unspeed = elapsedTime + bullet.speedTime
					end
					v.lastHit = elapsedTime
					if v.health <= 0 then
						zombies[i] = nil
					end
				end
			end
		end
	end

	function love.mousepressed(key)
		local mX, mY = love.mouse.getX(), love.mouse.getY()
		local x, y = (mX - (mX%boardPixelSize))/boardPixelSize, (mY - (mY%boardPixelSize))/boardPixelSize
		for i,v in pairs(suns) do
			if (v.Position - Vector2.new(love.mouse.getX(), love.mouse.getY())).Magnitude <= boardPixelSize/2 then
				sunCount = sunCount + v.give
				suns[i] = nil
				return
			end
		end
		if y == dimensions[2] then
			local count =0
			for i,v in pairs(itemData) do
				count = count +1
				if x+1 == count then
					if currentPlant == i then
						currentPlant = nil
					else
						currentPlant = i
					end
				end
			end
		end
		if currentPlant and 
		(itemData[currentPlant].nextPlant or 0) < elapsedTime and 
		sunCount >= itemData[currentPlant].sunCost 
		and board[x] and board[x][y] then
			if not board[x][y].name then
				local newPlant = {
					name =  currentPlant, 
					health = itemData[currentPlant].health,
					lastShot = 0, 
					lastBurst = 0, burstQuantity = 0
				}
				board[x][y] = newPlant
				if itemData[currentPlant].emitRate then
					newPlant.lastEmit = elapsedTime
				end
				itemData[currentPlant].nextPlant = elapsedTime + (nocooldown and 0.1 or itemData[currentPlant].cooldownTime)
				sunCount = sunCount - itemData[currentPlant].sunCost
			else
				if currentPlant == "Shovel" then
					board[x][y] = {}
				end
			end
		end
	end

	function love.draw()
		for x, row in pairs(board) do
			for y, data in pairs(row) do
				local c = ((x+(y%2))%2)
				local w = boardPixelSize
				ColorData.GoodGreen(brightness * clamp(c+.9,0,1))
				love.graphics.rectangle("fill", x*boardPixelSize,y*boardPixelSize, boardPixelSize,boardPixelSize)
			
				if data.name then
					local healthPercent = w * (data.health / itemData[data.name].health)

					itemData[data.name].drawShooter(x * boardPixelSize - (10 - clamp(((elapsedTime) - (data.lastBurst or 0))*20, 0, 10)), y * boardPixelSize)
					
					----[[
					if showHealth then
						local x=x*boardPixelSize
						local y=y*boardPixelSize
						ColorData.HealthBar.backdrop()
						love.graphics.rectangle("fill", x,y+(boardPixelSize/2-2.5), w, 5)
						ColorData.HealthBar.outline()
						love.graphics.rectangle("line", x,y+(boardPixelSize/2-2.5), w, 5)
						ColorData.HealthBar.slider()
						love.graphics.rectangle("fill", x,y+(boardPixelSize/2-2.5), healthPercent, 5)
						ColorData.HealthBar.outline()
						love.graphics.rectangle("line", x,y+(boardPixelSize/2-2.5), healthPercent, 5)
					end
					--]]
				end
			end
		end
		for i,v in pairs(zombies) do
			local x,y = v.Position()
			local w,h = v.Size()
			local healthPercent = w * (v.health / v.maxHealth)
			
			ZombieData[v.name].draw(v)

			----[[
			if showHealth then
				ColorData.HealthBar.backdrop()
				love.graphics.rectangle("fill", x,y+(boardPixelSize/2-2.5), w, 5)
				ColorData.HealthBar.outline()
				love.graphics.rectangle("line", x,y+(boardPixelSize/2-2.5), w, 5)
				ColorData.HealthBar.slider()
				love.graphics.rectangle("fill", x,y+(boardPixelSize/2-2.5), healthPercent, 5)
				ColorData.HealthBar.outline()
				love.graphics.rectangle("line", x,y+(boardPixelSize/2-2.5), healthPercent, 5)
			end
			--]]
		end
		for i,v in pairs(bullets) do
			local x,y = v.Position()
			itemData[v.from.name].drawBullet(x, y)
		end
		for i,v in pairs(suns) do
			local x,y = v.Position()
			local r = (boardPixelSize/4) * (v.give / 25)
			
			ColorData.Sun.backdrop()
			love.graphics.polygon("fill", x + r*-.5, y-r+5, x + r*.5, y-r+5, x, y-r+5 - 20)
			love.graphics.polygon("fill", x + r*-.5, y+r-5, x + r*.5, y+r-5, x, y+r-5 + 20)
			love.graphics.polygon("fill", x-r+5, y - r*.5, x-r+5, y + r*.5, x-r+5 - 20, y)
			love.graphics.polygon("fill", x+r-5, y - r*.5, x+r-5, y + r*.5, x+r-5 + 20, y)
			
			ColorData.Sun.outline()
			love.graphics.polygon("line", x + r*-.5, y-r+5, x + r*.5, y-r+5, x, y-r+5 - 20)
			love.graphics.polygon("line", x + r*-.5, y+r-5, x + r*.5, y+r-5, x, y+r-5 + 20)
			love.graphics.polygon("line", x-r+5, y - r*.5, x-r+5, y + r*.5, x-r+5 - 20, y)
			love.graphics.polygon("line", x+r-5, y - r*.5, x+r-5, y + r*.5, x+r-5 + 20, y)
		

			ColorData.Sun.backdrop()
			love.graphics.circle("fill", x,y, r)
			ColorData.Sun.outline()
			love.graphics.circle("line", x,y, r)
		end
		local count = 0
		for plant,v in pairs(itemData) do
			if v.sunCost then
				count = count+1
				local x,y = (count-1) * boardPixelSize,dimensions[2]*boardPixelSize
				if plant == currentPlant then
					ColorData.plantDark()
				else
					ColorData.plantLight()
				end
				love.graphics.rectangle("fill", x,y, boardPixelSize,boardPixelSize)
				v.drawShooter(x,y)
				Color3.fromRGB(100,0,0)()
				love.graphics.rectangle("line", x,y, boardPixelSize,boardPixelSize)
				Color3.fromRGB(0,0,0)()
				love.graphics.rectangle("fill",x,y, boardPixelSize, clamp(boardPixelSize*(((v.nextPlant or 0) - elapsedTime)/((nocooldown and 0.1 or v.cooldownTime) or 30)),0, boardPixelSize))
				Color3.fromRGB(255,255,255)()
				love.graphics.print(plant, x,y)
				Color3.fromRGB(255,255,111)()
				love.graphics.print(v.sunCost, x,y+boardPixelSize-20)
			end
		end

		for y, mower in pairs(lawnmowers) do
			if not mower.invoked then
				
			end
		end

		Color3.fromRGB(255,255,255)()
		love.graphics.print(sunCount)
	end


	local longest
	for i,v in pairs(roundData) do
		longest = i > (longest or 0) and i
	end
	
	local roundLength = longest + (roundData[longest].quantity * roundData[longest].timeDelay)
	
	local started = os.clock()
	
	
	--repeat
	--until os.clock()-started >= roundLength
end