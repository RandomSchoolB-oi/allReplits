Vector2 = {}
Vector2.__index = Vector2

Vector2.new = function(x,y)
	local vector = {
		X=x or 0,
		Y=y or 0
	}
	vector.Magnitude = math.sqrt(x ^ 2 + y ^2)
	return setmetatable(vector,Vector2)
end
function Vector2:__sub(other)
	return Vector2.new(self.X-other.X, self.Y-other.Y)
end
function Vector2:__add(other)
	return Vector2.new(self.X+other.X, self.Y+other.Y)
end
function Vector2:__call()
	return self.X, self.Y
end
function Vector2:__lt(other)
	return self.X < other.X and self.Y < other.Y
end
function Vector2:__le(other)
	return self.X <= other.X and self.Y <= other.Y
end