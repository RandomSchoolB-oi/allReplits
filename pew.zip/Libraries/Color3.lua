Color3 = {}
Color3.__index = Color3

Color3.__add = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R + other, self.G + other, self.B + other)
	else
		return Color3.fromRGB(self.R + other.R, self.G + other.G, self.B + other.B)
	end
end

Color3.__sub = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R - other, self.G - other, self.B - other)
	else
		return Color3.fromRGB(self.R - other.R, self.G - other.G, self.B + other.B)
	end
end

Color3.__mul = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R * other, self.G * other, self.B * other)
	else
		return Color3.fromRGB(self.R * other.R, self.G * other.G, self.B * other.B)
	end
end

Color3.__div = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R / other, self.G / other, self.B / other)
	else
		return Color3.fromRGB(self.R / other.R, self.G / other.G, self.B / other.B)
	end
end

Color3.__mod = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R % other, self.G % other, self.B % other)
	else
		return Color3.fromRGB(self.R % other.R, self.G % other.G, self.B % other.B)
	end
end

Color3.__pow = function(self, other)
	if type(other) == "number" then
		return Color3.fromRGB(self.R ^ other, self.G ^ other, self.B ^ other)
	else
		return Color3.fromRGB(self.R ^ other.R, self.G ^ other.G, self.B ^ other.B)
	end
end

Color3.__tostring = function(self)
	return tostring(self.R)..", "..tostring(self.G)..", "..tostring(self.B)
end

Color3.__call = function(self, customBrightness)
	local bright = customBrightness or brightness or 1
	return love.graphics.setColor(self.R * bright, self.G * bright, self.B * bright)
end

Color3.lerp = function(self, to, alpha)
	return (self * (1-alpha)) + (to * alpha)
end

Color3.new = function(r, g, b) -- from 0 to 1
	r,g,b = r or 0, g or 0, b or 0

	local color = {}
	color.R = r*255
	color.G = g*255
	color.B = b*255

	return setmetatable(color, Color3)
end

Color3.fromRGB = function(r, g, b) -- from 0 to 255
	r,g,b = r or 0, g or 0, b or 0
	local color = {}
	color.R = r
	color.G = g
	color.B = b

	return setmetatable(color, Color3)
end
