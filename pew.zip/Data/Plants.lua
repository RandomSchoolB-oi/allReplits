itemData = {
	["Pea Shooter"] = {
		damage = 1,
		rate = 1.5,
		shotDecay = 6,
		burstAmount = 1,
		burstDelay = 0,
		speed = 100,
		health = 5,
		drawBullet = function(x,y)
			Color3.fromRGB(170, 255, 0)()
			love.graphics.circle("fill", x,y, 10)
			Color3.fromRGB(150, 200, 0)()
			love.graphics.circle("line", x,y, 10)
		end,
		drawShooter = function(x,y)
			Color3.fromRGB(170,255,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB(150,200,0)()
			love.graphics.rectangle("line", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
		
			Color3.fromRGB(170,255,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/2, y + boardPixelSize/2 - 5, 20, 10)
			Color3.fromRGB(150,200,0)()
			love.graphics.rectangle("line", x + boardPixelSize/2, y + boardPixelSize/2 - 5, 20, 10)
		end,
		cooldownTime = 30,
		sunCost = 100,
	},
	Repeater = {
		damage = 1,
		rate = 1.5,
		shotDecay = 6,
		burstAmount = 2,
		burstDelay = .2,
		speed = 100,
		health = 7,
		drawBullet = function(x,y)
			Color3.fromRGB(170, 255, 0)()
			love.graphics.circle("fill", x,y, 10)
			Color3.fromRGB(150, 200, 0)()
			love.graphics.circle("line", x,y, 10)
		end,
		drawShooter = function(x,y)
			Color3.fromRGB(170,255,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB(150,200,0)()
			love.graphics.rectangle("line", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
		
			Color3.fromRGB(170,255,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/2, y + boardPixelSize/2 - 10, 40, 20)
			Color3.fromRGB(150,200,0)()
			love.graphics.rectangle("line", x + boardPixelSize/2, y + boardPixelSize/2 - 10, 40, 20)
		end,
		cooldownTime = 45,
		sunCost = 200,
	},
--[[
	DevPlant = {
		damage = 1,
		rate = 1,
		shotDecay = 6,
		burstAmount = 5,
		burstDelay = .1,
		speed = 100,
		health = 20,
		drawBullet = function(x,y)
			Color3.fromRGB(0, 0, 0)()
			love.graphics.circle("fill", x,y, 10)
		end,
		drawShooter = function(x,y)
			Color3.fromRGB(0,0,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
		end,
		cooldownTime = .5,
		sunCost = 0,
	},--]]
	Sunflower = {
		damage = 0,
		rate = 0,
		shotDecay = 0,
		burstAmount = 0,
		burstDelay = 0,
		speed = 0,

		emitRate = 15,
		sunGive = 25,

		health = 4,
		drawBullet = function(x,y)

		end,
		drawShooter = function(x,y)
			Color3.fromRGB(255, 255, 0)()
			love.graphics.rectangle("fill", x, y + boardPixelSize/2 - 10, boardPixelSize, 20)
			love.graphics.rectangle("fill", x + boardPixelSize/2 - 10, y, 20, boardPixelSize)
			Color3.fromRGB(200, 200, 0)()
			love.graphics.rectangle("line", x, y + boardPixelSize/2 - 10, boardPixelSize, 20)
			love.graphics.rectangle("line", x + boardPixelSize/2 - 10, y, 20, boardPixelSize)
		
			Color3.fromRGB(170,100,0)()
			love.graphics.rectangle("fill", x + boardPixelSize*.2, y + boardPixelSize*.2, boardPixelSize*.6, boardPixelSize*.6)
			Color3.fromRGB(150,70,0)()
			love.graphics.rectangle("line", x + boardPixelSize*.2, y + boardPixelSize*.2, boardPixelSize*.6, boardPixelSize*.6)
		
		end,
		cooldownTime = 10,
		sunCost = 50,
	},

	["Frozen Pea Shooter"] = {
		damage = 1,
		rate = 1.5,
		shotDecay = 6,
		burstAmount = 1,
		burstDelay = 0,
		speed = 100,
		health = 5,

		speedMul = .4,
		speedTime = 10,

		drawBullet = function(x,y)
			Color3.fromRGB(0, 170, 255)()
			love.graphics.circle("fill", x,y, 10)
			Color3.fromRGB(0, 150, 200)()
			love.graphics.circle("line", x,y, 10)
		end,
		drawShooter = function(x,y)
			Color3.fromRGB(0, 170, 255)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB(0, 150, 200)()
			love.graphics.rectangle("line", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
		
			Color3.fromRGB(0, 170, 255)()
			love.graphics.rectangle("fill", x + boardPixelSize/2, y + boardPixelSize/2 - 5, 30, 10)
			Color3.fromRGB(0, 150, 200)()
			love.graphics.rectangle("line", x + boardPixelSize/2, y + boardPixelSize/2 - 5, 30, 10)
		end,
		cooldownTime = 15,
		sunCost = 175,
	},
	["Shovel"] = {
		drawShooter = function(x,y)
		end,
		cooldownTime = 2,
		sunCost = 0,
	},


	Potato = {
		damage = 0,
		rate = 0,
		shotDecay = 0,
		burstAmount = 0,
		burstDelay = 0,
		speed = 0,

		health = 30,
		drawBullet = function(x,y)

		end,
		drawShooter = function(x,y)
			Color3.fromRGB(200,50,0)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB(150,25,0)()
			love.graphics.rectangle("line", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
		end,
		cooldownTime = 10,
		sunCost = 50,
	},

	["Lawn Mower"] = {
		noDestroy = true,
		damage = math.huge,

		rate = 0,
		shotDecay = 0,
		burstAmount = 0,
		burstDelay = 0,
		speed = 125,

		health = math.huge,
		drawBullet = function(x,y)

		end,
		drawShooter = function(x,y)
			Color3.fromRGB(150,150,150)()
			love.graphics.rectangle("fill", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB(100,100,100)()
			love.graphics.rectangle("line", x + boardPixelSize/4, y + boardPixelSize/4, boardPixelSize/2, boardPixelSize/2)
			Color3.fromRGB()()
			love.graphics.circle("fill", x + boardPixelSize * .25, y + boardPixelSize * .75, 10)
			love.graphics.circle("fill", x + boardPixelSize * .75, y + boardPixelSize * .75, 10)
			Color3.fromRGB(25,25,25)()
			love.graphics.circle("line", x + boardPixelSize * .25, y + boardPixelSize * .75, 10)
			love.graphics.circle("line", x + boardPixelSize * .75, y + boardPixelSize * .75, 10)
			Color3.fromRGB(255)()
			love.graphics.rectangle("fill",x,y + boardPixelSize/4,boardPixelSize/4,boardPixelSize/8)
			Color3.fromRGB(200)()
			love.graphics.rectangle("line",x,y + boardPixelSize/4,boardPixelSize/4,boardPixelSize/8)
		end,
		sunCost = 1,
		cooldownTime = 1,
	},
}