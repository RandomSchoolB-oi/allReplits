ColorData = {
	Zombie = {
		outline = Color3.fromRGB(0, 150, 0),
		backdrop = Color3.fromRGB(0, 200, 0),
		frozen = Color3.fromRGB(0, 0, 200)
	},
	BOB = {
		outline = Color3.fromRGB(150, 0, 0),
		backdrop = Color3.fromRGB(200, 0, 0),
		frozen = Color3.fromRGB(100, 0, 100)
	},
	HealthBar = {
		outline = Color3.fromRGB(0, 0, 0),
		slider = Color3.fromRGB(170, 255, 0),
		backdrop = Color3.fromRGB(200, 0, 0)
	},
	Sun = {
		outline = Color3.fromRGB(200, 150, 0),
		backdrop = Color3.fromRGB(255, 200, 0)
	},
	Sunflower = {
		pedalBackdrop = Color3.fromRGB(255,255,0),
		pedalOutline = Color3.fromRGB(200,200,0),
		mainBackdrop = Color3.fromRGB(170,100,0),
		mainOutline = Color3.fromRGB(150,70,0),
	},
	invoked = Color3.new(1,1,1),

	GoodGreen = Color3.fromRGB(170, 255, 0),

		plantLight = Color3.fromRGB(130, 30, 0),
		plantDark = Color3.fromRGB(100, 0, 0),
}