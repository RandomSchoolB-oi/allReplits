ZombieData = {
	Craig = {
		speed = 5,
		health = 10,
		damage = 1,
		hitSpeed = 1,
		draw = function(data)
			local x,y = data.Position()
			local w,h = data.Size()
			local alpha = clamp((elapsedTime - (data.lastHit or 0)) * 5,0,1) / 1
			
			ColorData.invoked:lerp((ColorData.Zombie.frozen:lerp(ColorData.Zombie.backdrop, data.speedMul)), alpha)()

			love.graphics.rectangle("fill", x,y, w,h)
			ColorData.Zombie.outline()
			love.graphics.rectangle("line", x,y, w,h)
		end
	},
	Bob = {
		speed = 5,
		health = 25,
		damage = 5,
		hitSpeed = 1/3,
		draw = function(data)
			local x,y = data.Position()
			local w,h = data.Size()
			local alpha = clamp((elapsedTime - (data.lastHit or 0)) * 5,0,1) / 1
			
			ColorData.invoked:lerp((ColorData.BOB.frozen:lerp(ColorData.BOB.backdrop, data.speedMul)), alpha)()

			love.graphics.rectangle("fill", x,y, w,h)
			ColorData.BOB.outline()
			love.graphics.rectangle("line", x,y, w,h)
		end
	},
}