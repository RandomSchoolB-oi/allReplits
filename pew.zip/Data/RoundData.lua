local function makePossibleFromDict(dict)
	local new = {}
	for zombie, quantity in pairs(dict) do
		for _ = 1, quantity do
			new[#new+1] = zombie
		end
	end
	return new
end

local module = {
	{
		[90] = {
			quantity = 5,
			timeDelay = 10,
			possible = {
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Bob",
			},
		},
		[200] = {
			quantity = 25,
			timeDelay = 2,
			possible = {
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Craig",
				"Bob"
			},
		},
		[300] = {
			quantity = math.huge,
			timeDelay = 1,
			possible = {
				"Craig",
				"Craig",
				"Bob"
			},
		},
	},
}
return module