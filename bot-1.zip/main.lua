local key = "NzU3NzUzMDY5MjE0NzYwOTYx.X2k-ig.AYC548ptnILqHFCErun4bhymzwk"


local discord = require("discordia")
local client = discord.Client()
discord.extensions()

local prefix = "#"

function unpack(t, index)
    index = index or 1
    if t[index] then
        return t[index], unpack(t, index + 1)
    end
end

client:on("ready", function()
    getGuild():getChannel("899270464914985010"):send("ur dad")
end)

client:on("messageCreate", function(message)
    local content = message.content
    local author = message.author
    local webId = message.webhookId
	local args = content:split(" ")
    local s, e
    
    s, e = pcall(function()
        local command = commands[args[1]:lower()]
        if command then
            local permission = getPermissionLevel(author.id, webId)
            if permission and permission >= command.permissionLevel then
                table.remove(args, 1)
                command.func(unpack(args))
            end
        end
    end)
    if e then
        message:reply(e)
    end
end)



client:run('Bot '.. key)