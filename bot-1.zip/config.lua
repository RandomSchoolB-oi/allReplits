return {
    botToken = "ODYyMTI0MDQyNDgzNTMxODQ2.YOTxlQ.ceyQ-SDBJiKLXoJvpqGI5efQQw0",
    guildId = "862117174168387634",
    mainChannel = "862117174168387636",
    queue = "862131398382977055",
    general = "862117174168387637",
    permissions = {
        --["862124042483531846"] = 6, -- runs the commands no matter what, and can be used to bypass the permissionlevel with #say
        ["298534803027001344"] = 5, -- randomb_oi
        ["862126563797106727"] = 6, -- webhook
    },
}