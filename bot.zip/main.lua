local numb = 5.88

local diffrentNumbers=0

local n = numb

local uniqueNumbs = {}
for i.v in pairs(split(tostring(numb)))
print()