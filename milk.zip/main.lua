milk = function(x,y)
	love.graphics.setColor(255, 255, 200)
	love.graphics.rectangle("fill", x-20,y-25, 40, 50)
	love.graphics.polygon("fill",x-20, y-25, x+20, y-25, x, y-50)
end

function love.draw()
    milk(love.mouse.getX(), love.mouse.getY())
end