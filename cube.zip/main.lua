local w,h = 400,400
-- love.load = function()
-- 	love.window.setMode(w,h)
-- end
local cube = {
	{x=0,y=0},{x=0,y=0},{x=0,y=0},{x=0,y=0},
	{x=0,y=0},{x=0,y=0},{x=0,y=0},{x=0,y=0},
}
local size = 100
local rot = {x = 0, y = 0, z = 0}

love.update = function(dt)
	for i=1,4 do
		local v1, v2 = cube[i], cube[i+4]
		local off = math.pi * (i/2)
		v1.x = math.sin(rot.y * 4 + off) * (size * (3/4))
		v1.y = (math.cos(rot.y * 4 + off) * ((size * math.sin(rot.x)) * (3/4)))
		v2.x = v1.x
		v2.y = v1.y + size * math.cos(-rot.x)

	end
	rot.x = rot.x + math.rad(dt*45)
	rot.y = rot.y + math.rad(dt*10)

	rot.x = rot.x % (math.pi*2)
	rot.y = rot.y % (math.pi*2)
	rot.z = rot.z % (math.pi*2)
end

drawlineFrom = function(from, to)
	local v1,v2 = cube[from], cube[to]
	love.graphics.line(v1.x, v1.y, v2.x, v2.y)
	love.graphics.circle("fill", v1.x, v1.y, 5)
	love.graphics.circle("fill", v2.x, v2.y, 5)
end

love.draw = function()
	love.graphics.push()
	love.graphics.translate(w/2, h/2)
	for i=1,4 do
		drawlineFrom(i, i+4)
		drawlineFrom(i,(i%4)+1)
		drawlineFrom(i+4,(i%4)+5)
			drawlineFrom(i, (i % #cube)+2)
	end
	love.graphics.pop()
end