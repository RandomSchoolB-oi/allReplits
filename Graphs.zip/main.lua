local start = 0

local π = math.pi
local goal = π*1
local inc = π/30
local serialGraph = 1
local yoff = 0


local graph = function(f)
	local calcXY = function(i)
		return i * 30+10, -(f(i) * 40) + yoff+100
	end
	for i=start, goal+inc, inc do
		local x1,y1 = calcXY(i)
		local x2,y2 = calcXY(i+inc)

		love.graphics.setColor(255,255,255)

		love.graphics.line(x1,y1, x2,y2)
	end
	yoff = yoff + 100
end

local serialGrid = 1
local gridScale = 10
local grid = function(f)
	for x=start, goal+inc, inc do
		for y=start, goal+inc, inc do
			local v = f(x, y)/2 + .5
			local c = 255 * v
			love.graphics.setColor(c,c,c)
			love.graphics.rectangle("fill", x * gridScale,y * gridScale + (yoff) ,inc * gridScale,inc * gridScale)
		end
	end
	love.graphics.rectangle("line", 0, yoff, (gridScale * (goal + inc)),(gridScale * (goal + inc)))
	yoff = yoff + ((goal + inc)*gridScale)
end

movingSin = function(x)
	return math.sin(x + (os.clock() * 2))
end
movingNoise = function(x, y)
	x, y = x or 0, y or 0
	return love.math.noise(x * 0.49 + os.clock(), y * 0.49)
end

layerNoise = function(x, y)
	--layeredNoise = function(x,y,seed,layers,amp, freq)
	_amp, _freq = 1, 0.49
	local seed = 20
	local noise = 0
	local layers = 2
	y = y or 0
	for i=1,layers do
		noise = noise + love.math.noise(x * _freq, y * _freq, seed * _freq) * _amp
		_amp = _amp * .5
		_freq = _freq * 1.1
	end
	return noise
	--end
end

function love.load()
	love.graphics.setLineStyle("smooth")
	love.graphics.setLineWidth(5)
end


local calcXY = function(i)
	return math.sin(i) * 20 + 200, math.cos(i) * 20 + 200
end
function love.draw()
	graph(math.cos)	
	graph(math.sin)
	graph(math.atan)
	grid(math.atan2)
	graph(movingNoise)
	grid(movingNoise)
	graph(layerNoise)
	grid(layerNoise)

	yoff = 0
end
