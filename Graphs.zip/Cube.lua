local module = {}
module.__index = module

module.draw(x,y,z, w,h,d)
	love.graphics.polygon("fill")
end

return module