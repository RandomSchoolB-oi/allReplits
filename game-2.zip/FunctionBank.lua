targetBarData = {
	name = "",
	health = 0,
	maxHealth = 0,
	lastDraw = 0,
}
FB = {
	makeToolbar = function()
		local toolbar = {}
		for i, v in pairs(data.toolbar) do
			local button = Instance.new("Button")
			button.Relative = false
			button.Activated = function()
				if data.currentTool == i then
					data.currentTool = nil
				else
					data.currentTool = i
				end
				print(i)
			end
			toolbar[#toolbar+1] = button
		end
		return toolbar
	end,
	
	updateToolbar = function(toolbar)
		local cellsize = WIDTH/(#toolbar+2)
		for k,v in pairs(toolbar) do
			local i = k-1
			v.Size = Vector.new(cellsize, cellsize)
			v.Position = Vector.new(cellsize * i + cellsize/2 + cellsize, HEIGHT - cellsize/2)
			if k == data.currentTool then
				v.Color = ColorData.goodGreen
			else
				v.Color = ColorData.lightGrey
			end
			v.Visible = uiVis
		end
	end,

	drawTargetBar = function(name, health,maxHealth)
		targetBarData = {
			name = name or 0,
			health = health or 0,
			maxHealth = maxHealth or 0,
			lastDraw = os.clock(),
		}
	end,

	swing = function()
		player.lastSwing = os.clock()
		for i,v in pairs(getParts()) do
			if v:IsA("Resource") then
				if (v.Position - player.Position).Magnitude < (v.Size.X/2 + player.Size.X) then
					
					if player.CFrame:canSee(v.Position, math.pi/4) then
						v.hit(10)
						FB.drawTargetBar(v.ResourceName, v.Health, v.MaxHealth)
					end
				end
			end
		end
	end,

	dropItem = function(dropData)
		local name = dropData.Name
		local pos = dropData.Position
		local randomize = dropData.Randomize
		local quantity = dropData.Quantity or 1
		for i=1,quantity do
			local item = Instance.new("Item")
			item.Position = pos + (randomize and Vector.new(math.random(-30, 30), math.random(-30, 30)) or Vector.new())
			item.ResourceName = name
		end
	end,

	giveItem = function(item,quantity)
		local maxStack = 16
		local notGiven = quantity
		for i=1,quantity do
			for i,v in pairs(data.inventory) do
				if (v.name == item or not v.name ) and (v.quantity or 0) < maxStack then
					v.name = item
					v.quantity = (v.quantity or 0) + 1
					notGiven = notGiven - 1
					break
				end
			end
		end
		print(notGiven)
		return notGiven
	end,

	drawInventory = function()
		if uiVis then
			local gridLength = 5
			for k,v in pairs(data.inventory) do
				local i = k-1
				local x = i % (gridLength)
				local y = (i-x) / (gridLength)
				local cellsize = WIDTH / (gridLength)
				ColorData.grey()
				local px,py = x * cellsize, y * cellsize
				love.graphics.rectangle("fill", px,py, cellsize, cellsize)
				if v.name and itemData[v.name] and itemData[v.name].draw then
					local cf = CFrame.new(x * cellsize + cellsize/2, y * cellsize + cellsize/2, math.pi/4)
					itemData[v.name].draw(cf)
				end
				Color3.new(255,255,255)()
				love.graphics.print(v.name or "", px,py)
				love.graphics.print(v.quantity or "", px,py+cellsize-20)
			end
		end
	end,

	drawCrafting = function()
	local serial = 0
		for i,v in pairs(itemData) do


			serial = serial + 1
		end
	end
}