local module = {}

rect = function(fill, x,y,w,h,r)
	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(r)
	love.graphics.rectangle(fill and "fill" or "line", -w/2,-h/2, w,h)
	love.graphics.pop()
end

ellipse = function(fill, x,y,w,h,r)
	love.graphics.push()
	love.graphics.translate(x, y)
	love.graphics.rotate(r)
	love.graphics.ellipse(fill and "fill" or "line", 0,0,w/2,h/2)
	love.graphics.pop()
end

circle = function(fill, x,y, r)
	love.graphics.circle(fill and "fill" or "line", x,y, r)
end

line = function(x1,y1,x2,y2)
	love.graphics.line(x1,y1,x2,y2)
end

tri = function(fill, x1,y1, x2,y2, x3,y3)
	love.graphics.polygon(fill and 'fill' or 'line', x1,y1, x2,y2, x3,y3)
end

lineCircle = function(x,y,r,degs)
	for i=1,degs do
		local rot = (i/degs) *  math.pi *2
		local cf = CFrame.new(x,y,rot)
		local cx,cy = (cf * r)()
		love.graphics.line(x,y,cx,cy)
	end
end

module.rect = rect
module.ellipse = ellipse
module.line = line
module.tri = tri
module.lineCircle = lineCircle
module.circle = circle

return module