local module = {}
module.__index = module

module.Gravity = Vector.new(0, 196.2)

local parts = {}
local serializer = 0

local types = {
	Part = "BasePart",
	Button = "Button",
	Player = "Player",
	Resource = "Resource",
	Item = "Button",
}
local directions = {
	w = Vector.new(0, -1),
	a = Vector.new(-1, 0),
	s = Vector.new(0, 1),
	d = Vector.new(1, 0)
}
within = function(x1,y1, x2,y2,w2,h2)
	x2 = x2 - w2/2
	y2 = y2 - h2/2
	return x1 > x2 and y1 > y2 and x1 < x2+w2 and y1 < y2+h2
end

module.new = function(className)
	assert(types[className], "not a valid instance type")
	local part = {
		ClassName = className,
		CFrame = CFrame.new(0, 0, 0),
		Position = Vector.new(0, 0),
		Size = Vector.new(100, 100),
		Color = Color3.new(255, 255, 255),
		Visible = true,
		Shape = "rectangle",
		OutlineStyle = "Border",
		OutlineThickness = 1,
		Relative = true,
	}
	if className == "Item" then
		part.ResourceName = "Log"
		part._clicked = false
		part.AutomaticColor = true
		part.Activated = function()
			local quantityLeft = FB.giveItem(part.ResourceName,1)
			if quantityLeft > 0 then
				FB.dropItem({
					Name = part.ResourceName,
					Quantity = quantityLeft,
					Position = part.Position,
					Randomize = true
				})
			end
			part:Destroy()
		end
	elseif types[className] == "Button" then
		part.Activated = false
		part._clicked = false
		part.AutomaticColor = true
	elseif types[className] == "BasePart" then
		part.CanCollide = false
		part.Anchored = true
		part.Velocity = Vector.new()
	elseif types[className] == "Player" then
		part.leftHand = CFrame.new()
		part.rightHand = CFrame.new()
		part.swingSpeed = 1/10
		part.lastSwing = 0
		part.walkspeed = 300
		part.Color = ColorData.lightGrey
	elseif types[className] == "Resource" then
	
		part.Health, part.MaxHealth = 100, 100
		part.ResourceName = "Tree"


		part.setInfo = function(itemName)
			part.Health, part.MaxHealth = itemData[itemName].health,itemData[itemName].health

			part.ResourceName = itemName
		end
		
		part.hit = function(dmg)
			part.Health = part.Health - dmg
			FB.drawTargetBar(part.ResourceName, part.Health, part.MaxHealth)
			if part.Health <= 0 then
				for item, quantity in pairs(itemData[part.ResourceName].drops) do
					FB.dropItem({
						Name = item, 
						Position = part.Position, 
						Quantity = quantity,
						Randomize = true
					})
				end
				part:Destroy()
			end
		end
	end
	setmetatable(part, module)
	
	local editTable = setmetatable({},{
		__index = part,
		__newindex = function(self, index, value)
			if index == "CFrame" then
				part.Position = value.Position
			elseif index == "Position" then
				part.CFrame = CFrame.new(value.X, value.Y, part.CFrame.R)
			else
				if part[index] == nil then
					return
				end
			end

			part[index] = value
		end
	})

	local id = serializer
	serializer=serializer+1
	part.id = id
	parts[id] = editTable

	return editTable
end

function module:IsA(className)
	return className == self.ClassName or types[self.ClassName] == className
end

function module:Destroy()
	parts[self.id or -1] = nil
	for i,v in pairs(self) do
		self[i] = nil
	end
end

function updateParts(dt)
	for i,v in pairs(parts) do
		if (v:IsA("Resource") or v:IsA("Item")) and v.ResourceName and itemData[v.ResourceName].size then
			v.Size = itemData[v.ResourceName].size
		end
		if v:IsA("Button") then
			local x,y = v.Position()
			local w,h = v.Size()

			local rmx,rmy = love.mouse.position()()
			local mx,my = love.mouse.getPosition()
			
			local inside = v.Relative and within(rmx,rmy, x,y, w,h) or not v.Relative and within(mx,my, x,y, w,h)

			if inside then
				if love.mouse.isDown(1) then
					if not v._clicked then
						v._clicked = true
						if v.Activated then
							v.Activated()
						end
					end
				else
					v._clicked = false
				end
			end
		elseif v:IsA("BasePart") then
			if not v.Anchored then
				local nextPos = v.Position + v.Velocity * dt
				v.Velocity = v.Velocity + module.Gravity * dt
				v.Position = nextPos
			end
		elseif v:IsA("Player") then
			local direction = Vector.new()
			local moved
			for i,v in pairs(directions) do
				if love.keyboard.isDown(i) then
					direction = direction + v
					moved = true
				end
			end
			if moved then
				v.Position = v.Position + (direction.Unit * v.walkspeed * dt)
			end
			local playerPos = v.Position
			local mousePos = love.mouse.position()
			local cf = CFrame.lookAt(playerPos, mousePos)
			v.CFrame = cf

			local w,h = v.Size()

			local swingPercent = mathf.clamp(os.clock()-v.lastSwing, 0, v.swingSpeed) / v.swingSpeed
			
			v.rightHand = cf * CFrame.Angles(math.pi/4 * swingPercent) * CFrame.new(0, w/2)
			v.leftHand = cf * CFrame.Angles(-math.pi/4) * CFrame.new(0, w/2)
		end
	end
end

function drawParts()
	for i,v in pairs(parts) do
		if v.Visible then
			if v.Relative then
				love.graphics.push()
				local x,y,r = CAMERA()

				local rx, ry = x - WIDTH/2, y - HEIGHT/2
				love.graphics.translate(-rx, -ry)
			end
			local x,y,r = v.CFrame()
			local w,h = v.Size()

			local rmx,rmy = love.mouse.position()()
			local mx,my = love.mouse.getPosition()
			
			local inside = v.Relative and within(rmx,rmy, x,y, w,h) or not v.Relative and within(mx,my, x,y, w,h)

			if v:IsA("Button") and inside then
				if love.mouse.isDown(1) then
					v.Color(1.2)
				else
					v.Color(.8)	
				end
			else
				v.Color()
			end
			if v:IsA("Player") then
				local lx,ly = v.leftHand()
				local rx,ry = v.rightHand()
				

				v.Color()
				circle(1, x,y, w/2)
				v.Color(.8)
				circle(nil, x,y, w/2)

				v.Color()
				circle(1, lx,ly, 20)
				circle(1, rx,ry, 20)
				v.Color(.8)
				circle(nil, lx,ly, 20)
				circle(nil, rx,ry, 20)
			elseif (v:IsA("Resource") or v:IsA("Item"))and v.ResourceName and itemData[v.ResourceName].draw then
				itemData[v.ResourceName].draw(v.CFrame)
			else
				if v.Shape == "rectangle" then
					if v.OutlineStyle == "Border" then
						rect(true, x,y, w,h,r)
						v.Color(.5)
						for i=0,v.OutlineThickness-1 do
							rect(false, x,y,w+i,h+i, r)
						end
					elseif v.OutlineStyle == "Fancy" then
						rect(true, x,y, w,h,r)
						love.graphics.push()
						love.graphics.translate(x,y)
						love.graphics.rotate(r)
						local t = v.OutlineThickness
						--top
						v.Color(.9)
						for i=0, t-1 do
							rect(true, 0, -h/2+i,w-i*2,1, 0)
						end
						--bottom
						v.Color(.6)
						for i=0, t-1 do
							rect(true, 0, h/2-i,w-i*2,1, 0)
						end
						--left
						v.Color(.85)
						for i=0, t-1 do
							rect(true, -w/2+i, 0,1,h-i*2, 0)
						end
						--right
						v.Color(.65)
						for i=0, t-1 do
							rect(true, w/2-i, 0,1,h-i*2, 0)
						end

						love.graphics.pop()
					elseif v.OutlineStyle == "Glass" then
						rect(true, x,y, w,h,r)
						love.graphics.push()
						love.graphics.translate(x,y)
						love.graphics.rotate(r)
						local t = v.OutlineThickness
						v.Color(.5)
						rect(true, w/2-t/2, 0, t,h,0)
						v.Color(.5)
						rect(true, 0, h/2-t/2, w,t,0)
						v.Color(.9)
						rect(true, -w/2+t/2, 0, t,h,0)
						v.Color(.9)
						rect(true, 0, -h/2+t/2, w,t,0)

						love.graphics.pop()
					elseif v.OutlineStyle == "Fade" then
						local t = v.OutlineThickness*4-1
						rect(true, x, y, w-v.OutlineThickness,h-v.OutlineThickness,r)
						for i=0,t do
							local p = i/t
							--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
							v.Color(1,1-p)
							rect(false, x,y, w-i+(i*.5),h-i+(i*.5), r)
						end
					end
				elseif v.Shape == "Circle" then
					if v.OutlineStyle == "Fade" then
						local t = v.OutlineThickness
						love.graphics.circle("fill", x, y, w/2-t)
						for i=0,t do
							local p = i/t
							--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
							v.Color(1,1-p)
							love.graphics.circle("line", x,y, w/2-i)
						end
					else
						love.graphics.circle("fill", x,y,w/2)
					end
				end
			end
			if v.Relative then
				love.graphics.pop()
			end
		end
	end
end

getParts = function()
	return parts
end

return module