local module = {}
module.__index = module

local r = function(numb)
	--return math.floor(numb + .5)
	return numb
end

function module.new(x,y,isUnit)
	local Vector = {
		X = r(x or 0),
		Y = r(y or 0),
	}
	Vector.Magnitude = r(math.sqrt(Vector.X^2 + Vector.Y^2))
	if not isUnit then
		local r = math.atan2(0 - Vector.Y, 0 - Vector.X)
		local x,y = math.cos(r), math.sin(r)
		Vector.Unit = module.new(-x, -y, true)
	end
	return setmetatable(Vector, module)
end

function module.__unm(self)
	return module.new(-self.X, -self.Y)
end

function module.__mul(self, other)
	if type(other) == "number" then
		return module.new(self.X * other, self.Y * other)
	else
		return module.new(self.X * other.X, self.Y * other.Y)
	end
end
function module.__div(self, other)
	return module.new(self.X / other, self.Y / other)
end

function module.__add(self, other)
	return module.new(self.X + other.X, self.Y + other.Y)
end
function module.__sub(self, other)
	return module.new(self.X - other.X, self.Y - other.Y)
end

function module.__eq(self, other)
	return self.X == other.X and self.Y == other.Y
end
function module.__lt(self, other)
	return self.X < other.X and self.Y < other.Y
end
function module.__le(self, other)
	return self.X <= self and self.Y <= other.Y
end


function module:change(new)
	self.X = new.X
	self.Y = new.Y
	self.Magnitude = new.Magnitude
end

function module:add(other)
	self:change(self + other)
end
function module:sub(other)
	self:change(self - other)
end
function module:mul(other)
	self:change(self * other)
end
function module:div(other)
	self:change(self / other)
end

function module:Lerp(to, alpha)
	return module.new(
		lerp(self.X, to.X, alpha),
		lerp(self.Y, to.Y, alpha)
	)
end

function module.__call(self)
	return self.X, self.Y
end

return module