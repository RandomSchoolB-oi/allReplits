local module = {}
module.__index = module

module.new = function(r,g,b)
	if config and config.version == "0.10.2" then
		r = (r or 0)*255
		g = (g or 0)*255
		b = (b or 0)*255
	end

	local color = {
		R = r or 0,
		G = g or 0,
		B = b or 0,
	}
	return setmetatable(color, module)
end

module.newHSV = function(h,s,v)
	
end

function module:Lerp(to, alpha)
	return module.new(
		lerp(self.R, to.R, alpha),
		lerp(self.G, to.G, alpha),
		lerp(self.B, to.B, alpha)
	)
end

function module:__call(brightness,transparency)
	brightness = brightness or 1
	transparency = transparency or 0
	love.graphics.setColor(
		self.R * brightness,
		self.G * brightness,
		self.B * brightness,
		255-(transparency * 255)
	)
end

return module