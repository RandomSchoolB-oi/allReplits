return function(load)
	Vector, CFrame, Graphics, Color3 = require("Objects.Vector"), require("Objects.CFrame"), require("Objects.Graphics"), require("Objects.Color3")
	IK = require("Objects.IK.Snake")
	Segment = require("Objects.IK.Segment")
	Instance = require("Objects.Instance")
	Thread = require("Objects.Thread")
	mathf = require("Objects.Mathf")
	require("Objects.String")

	CAMERA = CFrame.new()

	WIDTH, HEIGHT = 500,500
	FPS = 60
	TITLE = "Label"
	BACKGROUND_COLOR = Color3.new(0,0,0)

	local lastW, lastH
	ElapsedTime = 0

	love.load = load

	local lastUpdate = ElapsedTime
	function love.mouse.position(screenPos)
		local mx,my = love.mouse.getPosition()
		local cx,cy,r = CAMERA()
		local hw, hh = WIDTH/2, HEIGHT/2
		if screenPos then
			return Vector.new(mx, my)
		else
			return Vector.new(cx + mx - hw, cy + my - hh)
		end
	end
	function love.update(dt)
		repeat until os.clock() - lastUpdate > 1/FPS

		ElapsedTime = ElapsedTime + dt
		local s,e = pcall(function()
			if update then
				update(os.clock() - lastUpdate)
			end
			updateParts(os.clock() - lastUpdate)
		end)
		lastUpdate = os.clock()
		if not s and e then
			print("error in update:",e)
		end
	end
	local lastDraw = ElapsedTime
	function love.draw()
		repeat until os.clock() - lastDraw > 1/FPS
		if WIDTH ~= lastW or HEIGHT ~= lastH then
			lastW,lastH = WIDTH, HEIGHT
			love.window.setMode(WIDTH,HEIGHT)
		end
		TITLE = TITLE or "Game"
		if _G.CURRENT_TITLE ~= TITLE then
			_G.CURRENT_TITLE = TITLE
			love.window.setTitle(TITLE)
		end
		love.graphics.setBackgroundColor(BACKGROUND_COLOR.R,BACKGROUND_COLOR.G,BACKGROUND_COLOR.B)
			local s,e = pcall(function()
				if draw then
					draw(os.clock() - lastDraw)
					lastDraw = os.clock()
				end
			end)
			drawParts()
			drawSegments()
			IK.solve()

		if not s and e then
			print("error in draw:",e)
		end
	end
end