math.randomseed(os.time())
require("boot")(function()
	WIDTH,HEIGHT = 600,600
	FPS = 60
	TITLE = "Big Bob"
	BACKGROUND_COLOR = Color3.new(100,100,100)
	require("FunctionBank")
	ColorData = require("Data.ColorData")
	itemData = require("Data.ItemData")
	uiVis = true
	local inventoryVisible = false
	local craftVisible = false

	local rock = Instance.new("Resource")
	rock.Color = ColorData.lightGrey
	rock.Position = Vector.new(WIDTH/2, HEIGHT/2)
	rock.setInfo("Rock")

	

	player = Instance.new("Player")
	data = {
		inventory = {
			{},{},{},{},{},
			{},{},{},{},{},
		},
		toolbar = {
			{},
			{},
			{},
			{},
		},
		currentTool = 1
	}

	local toolbar = FB.makeToolbar()	
	

	function update(dt)
		FB.updateToolbar(toolbar)
		CAMERA = player.CFrame
	end

	function draw(dt)
		if os.clock() - targetBarData.lastDraw < 2 then
			ColorData.badRed()
			love.graphics.rectangle("fill", 20, 20, WIDTH-40,50)
			ColorData.goodGreen()
			love.graphics.rectangle("fill", 21, 21, (targetBarData.health / targetBarData.maxHealth) * (WIDTH-42),48)
		end
		if inventoryVisible then
			FB.drawInventory()
		end
		if craftVisible then
			FB.drawCrafting()
		end
	end


	love.mousepressed = function(_,_,key)
		if key == 1 then
			if os.clock() - player.lastSwing >= player.swingSpeed then
				FB.swing()
			end
		end
	end
	love.keypressed = function(key)
		if key == "u" then
			uiVis = not uiVis
		end
		if key == "c" then
			inventoryVisible = not inventoryVisible
			craftVisible = false
		end
		if key == "x" then
			craftVisible = not craftVisible
			inventoryVisible = false
		end
	end
end)