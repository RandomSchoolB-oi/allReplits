local module = {
	Rock = {
		drops = {
			Stone = 12,
			Axe = 5
		},
		health = 100,
		draw = function(cf)
			local x,y,r = cf()
			ColorData.lightGrey()
			rect(1, x,y, 75,50, r)
		end
	},
	Stone = {
		size = Vector.new(20,20),
		draw = function(cf)

			local x,y,r = cf()
			ColorData.lightGrey()
			circle(1, x,y, 10)
		end
	},
	Log = {
		size = Vector.new(30,20),
		draw = function(cf)

			local x,y,r = cf()
			ColorData.lightBrown()
			rect(1, x,y, 25,15, r)
		end
	},

	Axe = {
		recipe = {
			Stone = 1,
			Log = 2,
		},
		draw = function(cf)
			local x,y,r = cf()
			ColorData.lightBrown()
			rect(1, x,y, 10,30, r)
			ColorData.lightGrey()
			rect(1, x+7,y-15, 15, 10, r)
		end
	},
}

return module