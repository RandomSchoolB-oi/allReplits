local module = {
	lightGrey = Color3.new(235, 223, 185),
	goodGreen = Color3.new(170, 255, 0),
	badRed = Color3.new(255, 0, 0),
	lightBrown = Color3.new(138, 114, 78),
	grey = Color3.new(150, 150, 150)
}

return module