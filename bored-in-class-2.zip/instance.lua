require("Vector2")
require("Color3")
local signal = require("scriptSignal")
instance = {}
instance.__index = instance

local red,yellow,green = Color3.new(1,0,0), Color3.new(1,1,0), Color3.new(0,1,0)

instance.new = function(type)
	local object = {}
	if type == "Part" then
		object.name = "Part"
		object.position = Vector2.new(0, 0)
		object.size = Vector2.new(200, 50)
		object.color = Color3.new(0.7,0.7,0.7)
		object.shape = "rectangle"
		object.wireframe = false
		object.canCollide = true
		object.anchored = false
		object.velocity = Vector2.new(0, 0)
		object.health = 100
		object.maxHealth = 100
		object.parent = nil
	elseif type == "Workspace" then
		object.name = "Workspace"
		object.parent = nil
	elseif type == "Storage" then
		object.name = "Storage"
		object.parent = nil
	end

	object.propertyChanged = signal.new()
	object.touched = signal.new()

	return setmetatable(object, instance)
end

function instance:set(property, value)
	if property == "parent" then
		if self.parent then
			self.parent[self.name] = nil
		end
		value[self.name] = self
	elseif property == "name" and self.parent then
		self.parent[self.name] = nil
		self.parent[value] = self
	end
	self[property] = value
	self.propertyChanged:Run(property, value)
end


function instance:update(dt)
	if self.name == "Workspace" then
		
	end
	if not self.anchored then
		local canmove = true
		if self.canCollide then
			local futurePos = self.position + self.velocity
			local region = region2.new(futurePos, futurePos + self.size)
			for i, v in pairs(region:getParts()) do
				if v ~= self and v.canCollide then
					if v.lastHit ~= self then
					v.lastHit = self
						v.touched:Run(v)
					end
					canmove = false
					break
				end
			end
		end
		if canmove then
			self:set("position", self.position + self.velocity)
			self:set("velocity", self.velocity + (Vector2.new(0, 5) * dt))
		else
			self.velocity = Vector2.new(0, 0, 0)
		end
	end
end

function instance:draw()
	love.graphics.setColor(self.color())
	local x,y = self.position()
	local w,h = self.size()
	love.graphics[self.shape]((self.wireframe and "line") or "fill", x,y, w,h)
	if self.health and self.maxHealth then
		local x,y = self.position()
		local w,h = self.size()
		love.graphics.setColor(red())
		local backdrop = love.graphics.rectangle("fill", x, y, w, 5)
		love.graphics.setColor(green())
		local backdrop = love.graphics.rectangle("fill", x, y, w*(self.health / self.maxHealth), 5)

	end
end

function instance:getChildren(ignorelist)
	local children = {}
	for i,v in pairs(self) do
		if type(v) == "table" and v.name then
			children[#children+1] = v
		end
	end
	return children
end
function instance:isGrounded()
	local futurePos = self.position + Vector2.new(0,  1)
	local region = region2.new(futurePos, futurePos + self.size)
	for i, v in pairs(region:getParts()) do
		if v ~= self and v.canCollide then
			return true
		end
	end
end