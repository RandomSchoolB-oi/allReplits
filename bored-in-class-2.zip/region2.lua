require("game")
require("Vector2")
region2 = {}
region2.__index = region2

region2.new = function(min, max)
	local region = {}
	region.min = min
	region.max = max
	return setmetatable(region, region2)
end

function region2:getParts()
	local regionParts = {}
	for i, v in pairs(workspace:getChildren()) do
		if (v.position + v.size/2) >= (self.min - v.size/2) and (v.position + v.size/2) <= (self.max + v.size/2) then
			regionParts[#regionParts+1] = v
		end
	end
	return regionParts
end