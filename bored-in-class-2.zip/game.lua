require("instance")
game = {}
workspace = instance.new("Workspace")
workspace:set("parent", game)
storage = instance.new("Storage")
storage:set("parent", game)
