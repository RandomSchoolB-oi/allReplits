local module = {}
module.__index = module

function module.new()
	local signal = {
		_connections = {},
	}
	return setmetatable(signal, module)
end

function module:Connect(callback)
	local connection = {}
	connection.callback = callback

	local addedIndex = #self._connections+1

	function connection:Disconnect()
		self._connections[addedIndex] = nil
	end

	self._connections[addedIndex] = connection
end

function module:Run(...)
	for _, v in pairs(self._connections) do
		v.callback(...)
	end
end

return module