require("Vector2")require("instance")require("Color3")require("timer")require("game")require("region2")

function love.load()
	player = instance.new("Part")
	
	player:set("color", Color3.new(1, 1, 1))
	player:set("name","Player")
	player:set("parent", workspace)
	player:set("anchored", false)
	player:set("position", Vector2.new(100, 100))
	player:set("size", Vector2.new(75, 75))
	player:set("canCollide", true)

	floor = instance.new("Part")
	floor:set("anchored", true)
	floor:set("canCollide", true)
	floor:set("color", Color3.new(.25,.25,.25))
	floor:set("position", Vector2.new(0, 300))
	floor:set("size", Vector2.new(800,100))
	floor:set("name","floor")
	floor:set("parent", workspace)

	floor2 = instance.new("Part")
	floor2:set("anchored", true)
	floor2:set("canCollide", true)
	floor2:set("color", Color3.new(.25,.25,.25))
	floor2:set("position", Vector2.new(400, 0))
	floor2:set("size", Vector2.new(100,300))
	floor2:set("name","floor2")
	floor2:set("parent", workspace)

	floor3 = instance.new("Part")
	floor3:set("anchored", true)
	floor3:set("canCollide", true)
	floor3:set("color", Color3.new(.25,.25,.25))
	floor3:set("position", Vector2.new(-100, 0))
	floor3:set("size", Vector2.new(100,300))
	floor3:set("name","floor3")
	floor3:set("parent", workspace)

	floor4 = instance.new("Part")
	floor4:set("anchored", true)
	floor4:set("canCollide", true)
	floor4:set("color", Color3.new(.25,.25,.25))
	floor4:set("position", Vector2.new(0, -100))
	floor4:set("size", Vector2.new(800,100))
	floor4:set("name","floor4")
	floor4:set("parent", workspace)

	love.window.setMode(400, 300)
end

local eT = 0
local DT = 0

local directions = {
	a = Vector2.new(-5,0),
	d = Vector2.new(5,0),
	space = Vector2.new(0, -2)
}

function clamp(numb, min, max)
	if numb < min then
		return min
	elseif numb > max then
		return max
	else
		return numb
	end
end

function love.update(dt)
	for i,v in pairs(workspace:getChildren()) do
		v:update(dt)
	end
	eT = eT + dt
	DT = dt
	for key, dir in pairs(directions) do
		if love.keyboard.isDown(key) and (key == "space" and player:isGrounded() or key ~= "space") then
			player:set("velocity", player.velocity + (key == "space" and dir or dir * dt))
			--player:set("velocity", (dir * dt))
		end
	end
end
local red,yellow,green = Color3.new(1,0,0), Color3.new(1,1,0), Color3.new(0,1,0)
color = function(fps)
	if fps > 30 then
		return green
	else
		if fps > 15 then
			return yellow
		else
			return red
		end
	end
end

function love.draw()
	for i,v in pairs(workspace:getChildren()) do
		v:draw()
	end
	local fps = math.floor((1/DT)+.5)
	love.graphics.setColor(color(fps)())
	--local x,y = player.position()
	--local v,w = player.velocity()
	--x = math.floor(x+.5)
	--y = math.floor(y+.5)
	--v = math.floor(v+.5)
	--w = math.floor(w+.5)
	--love.graphics.print(x..","..y.."|"..v..","..w)
	love.graphics.print(fps)
end
