require("game")require("Vector2")require("region2")
Ray = {}
Ray.__index = Ray

Ray.new = function(origin, direction, ignoreList)
	local newRay = {}
	newRay.origin = origin
	newRay.direction = direction
	newRay.ignoreList = ignoreList

	return setmetatable(newRay, Ray)
end

function Ray:Cast()
	for i,v in pairs(workspace:getChildren(self.ignoreList)) do
		
	end
end