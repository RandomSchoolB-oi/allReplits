wait = function(delay)
	local start = os.clock()
	repeat until os.clock() - start > (delay or 0)
	return true
end

spawn = function(callback)
	coroutine.wrap(callback)()
end

delay = function(delay, callback)
	spawn(function()
		wait(delay)
		callback()
	end)
end