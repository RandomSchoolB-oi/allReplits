Thread = require("Objects.Thread")
function love.conf(config)
	config.modules.joystick = false
	config.modules.physics = false
end