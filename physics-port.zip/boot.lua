math.randomseed(os.time())
return function(load)
	Vector, CFrame, Graphics, Color3 = require("Objects.Vector"), require("Objects.CFrame"), require("Objects.Graphics"), require("Objects.Color3")
	IK = require("Objects.IK.Snake")
	Segment = require("Objects.IK.Segment")
	Thread = require("Objects.Thread")
	mathf = require("Objects.Mathf")
	Ray = require("Objects.Raycast")
	Udim = require("Objects.Udim")
	require("Objects.Enum")
	require("Objects.String")
	Signal = require("Objects.Signal")
	Input = require("Objects.Input")
	Instance = require("Objects.Instance")
	Region = require("Objects.Region")
	GuiObjects = {
		Joystick = require("Objects.Gui.Joystick"),
		Slider = require("Objects.Gui.Slider"),
		Gamepad = require("Objects.Gui.Gamepad"),
	}

	WIDTH, HEIGHT = 500,500
	FPS = 60
	TITLE = "Label"
	BACKGROUND_COLOR = Color3.new(0,0,0)
	CAMERA = Vector.new(0, 0)

	local lastW, lastH
	ElapsedTime = 0

	love.load = load

	local lastUpdate = ElapsedTime
	function love.mouse.position()
		return Vector.new(love.mouse.getPosition()) + CAMERA - Vector.new(WIDTH/2, HEIGHT/2)
	end
	function love.update(delta)
		repeat until os.clock() - lastUpdate > 1/FPS
		local dt = os.clock() - lastUpdate
		ElapsedTime = ElapsedTime + dt
		local s,e = pcall(function()
			if update then
				update(dt)
			end
			updateGamepads(dt)
			updateParts(dt)
			updateJoysticks(dt)
			updateSliders(dt)
		end)
		IK.solve()
		lastUpdate = os.clock()
		if not s and e then
			print("error in update:",e)
		end
	end
	local lastDraw = ElapsedTime
	function love.draw()
		repeat until os.clock() - lastDraw > 1/FPS
		if WIDTH ~= lastW or HEIGHT ~= lastH then
			lastW,lastH = WIDTH, HEIGHT
			love.window.setMode(WIDTH,HEIGHT)
		end
		TITLE = TITLE or "Game"
		if _G.CURRENT_TITLE ~= TITLE then
			_G.CURRENT_TITLE = TITLE
			love.window.setTitle(TITLE)
		end
		love.graphics.setBackgroundColor(BACKGROUND_COLOR.R,BACKGROUND_COLOR.G,BACKGROUND_COLOR.B)
		
		love.graphics.push()
		local s,e = pcall(function()
			if draw then
				love.graphics.push()
				love.graphics.translate((Vector.new(WIDTH/2, HEIGHT/2))())
				draw(os.clock() - lastDraw)
				lastDraw = os.clock()
				drawSegments()
				love.graphics.pop()
			end
		end)
		drawParts()
		love.graphics.push()
		love.graphics.translate((Vector.new(WIDTH/2, HEIGHT/2))())
		
		drawJoysticks()
		drawSliders()
		love.graphics.pop()
		love.graphics.pop()

		if not s and e then
			print("error in draw:",e)
		end
	end
end