--require("Tools.Language")
require("Tools.InstanceStore")
require("boot")(function()
	WIDTH,HEIGHT = 500,500
	FPS = 900000
	TITLE = "name"
	BACKGROUND_COLOR = Color3.new(50,50,50)

	--local char = Instance.new("Part")
	
	-- local slider = GuiObjects.Slider.new(3, 5, .1, 200)
	-- slider.axis = "X"
	-- slider.Moved:Connect(function(value)
	-- 	print(value)
	-- end)
	local controller = GuiObjects.Gamepad.new()
	-- local Slider = GuiObjects.Slider.new(0, 10, 1, 100)
	-- Slider.Moved:Connect(function(value)
	-- 	print(value)
	-- end)
	
	controller.Position = Vector.new(0, 150)
	
	Input.InputBegan:Connect(function(input)
		if input.Keyboard == Enum.Keyboard.H then
			saveAllParts()
		elseif input.Keyboard == Enum.Keyboard.N then
			local backDrop = Instance.new("EditableFrame", true)
			backDrop.Visible = true
		end
	end)

	function update(dt)
		
	end

	function draw(dt)

	end
end)