local CFrame = {}
CFrame.__index = CFrame

local pi = math.pi
local hPi = pi / 2
local qPi = pi / 4

local Vector = require("Objects.Vector")

CFrame.type = "CFrame"

function CFrame.new(x, y, r)
	local cf
	if type(x) == "table" then
		if type(y) == "table" then
			return CFrame.lookAt(x, y)
		else
			cf = {
				X = x.X,
				Y = x.Y,
				R = y or 0,
			}
		end
	else
		cf = {
			X = x or 0,
			Y = y or 0,
			R = r or 0,
		}
	end
	if cf then
		local lx,ly = math.cos(cf.R), math.sin(cf.R)
		cf.LookVector = Vector.new(lx,ly)
		
		local rx,ry = math.cos(cf.R + hPi), math.sin(cf.R + hPi)
		cf.RightVector = Vector.new(rx,ry)

		cf.Position = Vector.new(cf.X, cf.Y)
	end
	
	cf.R = cf.R % (math.pi*2)

	return setmetatable(cf,CFrame)
end

function CFrame.Angles(r)
	return CFrame.new(0,0,r)
end

function CFrame.lookAt(x1,y1,x2,y2)
	if type(y1) == "table" then
		x2,y2 = y1()
	end
	if type(x1) == "table" then
		x1,y1 = x1()
	end
	return CFrame.new(x1,y1, math.atan2(y2-y1, x2-x1))
end
function CFrame:canSee(pos, fov)
	local px,py = pos()
	local sx,sy = self.Position()
	local angle = math.atan2(py - sy, px - sx) % (math.pi*2)
	local r = self.R % (math.pi*2)
	--print(self.R, angle)
	return r > (angle - fov) and r < (angle + fov)
end

function CFrame:__add(other)
	return CFrame.new(self.X + other.X, self.Y + other.Y, self.R)
end
function CFrame:__sub(other)
	return CFrame.new(self.X - other.X, self.Y - other.Y, self.R)
end

function CFrame:__mul(cf)
	local look, right = self.LookVector, self.RightVector
	local movedX, movedY = look * cf.X, right * cf.Y
	
	return CFrame.new(self.X + movedX.X + movedY.X, self.Y + movedX.Y + movedY.Y, (self.R + cf.R) % (math.pi*2))
end

function CFrame:__call(type)
	if type then
		if type:lower() == "p" then
			return self.X, self.Y
		end
	else
		return self.X, self.Y, self.R
	end
end

function CFrame:_change(new)
	self.X = new.X
	self.Y = new.Y
	self.R = new.R % (math.pi*2)
	self.Position = new.Position
end

function CFrame:add(other)
	self:_change(self + other)
end
function CFrame:sub(other)
	self:_change(self - other)
end
function CFrame:mul(other)
	self:_change(self * other)
end

return CFrame