local module = {}
module.__index = module

module.new = function(min, max, ignoreList)
	assert(min, "has to have a minimum value")
	assert(max, "has to have a maximum value")
	assert(min < max, "the minimum has to be less than the maximum")
	local region = {
		_min = min,
		_max = max,
		_ignore = ignoreList or {},
	}
	return setmetatable(region, module)
end

function module:getPartsInside()
	local parts = {}
	for i,v in pairs(Instance.Parts) do
		if not mathf.find(self._ignore, v) then
			local pos = v.Position
			local size = v.Size
			local topLeft = pos - size/2
			local bottomRight = pos + size/2
			if topLeft > self._min and bottomRight < self._max then
				parts[#parts+1] = v
			end
		end
	end
	return parts
end

-- function module:getPartsTouching()
-- 	local parts = {}
-- 	for i,v in pairs(Instance.Parts) do
-- 		if not mathf.find(self._ignore, v) then
-- 			local pos = v.Position
-- 			local size = v.Size
			
-- 			if pos > self._min and pos < self._max then
-- 				parts[#parts+1] = v

-- 			end
-- 		end
-- 	end
-- 	return parts
-- end

return module