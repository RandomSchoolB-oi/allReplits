local Vector, CFrame = require("Objects.Vector"), require("Objects.CFrame")
local Segment = require("Objects.IK.Segment")

local IK = {}
IK.__index = IK

local snakes = {}
local serializer = 0

IK.new = function()
	local object = {}
	object.segments = {}
	object.to = nil
	object.base = nil
	local snake = setmetatable(object, IK)

	local id = serializer
	serializer = serializer + 1
	object.id = id
	snakes[id] = snake

	return snake
end

function IK:add(length)
	self.segments[#self.segments+1] = Segment.new(length or 100)
end

function IK:remove()
	if #self.segments < 1 then return end
	self.segments[#self.segments]:destroy()
	self.segments[#self.segments] = nil
end

function IK:solve()
	if not self then
		for i,v in pairs(snakes) do
			v:solve()
		end
		return
	end
	if not self.to or not self.base then return end
	
	if #self.segments >= 1 then
		self.segments[#self.segments]:follow(self.to())

		for i=#self.segments-1,1,-1 do
			self.segments[i]:follow(self.segments[i+1].CFrame.Position())
		end

		local base = Vector.new(self.base())
		self.segments[1]:updateA(base())
	
		for i = 2, #self.segments do
			local previous,current = self.segments[i-1], self.segments[i]
			current:updateA(previous.PositionB())
		end
	end
end

function IK:render()
	if not self then
		for i,v in pairs(snakes) do
			v:render()
		end
		return
	end
	for i, v in pairs(self.segments) do
		v()
	end
end

return IK