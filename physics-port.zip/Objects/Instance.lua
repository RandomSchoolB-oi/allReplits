local module = {}
module.__index = module

module.Gravity = Vector.new(0, 1962)
local world = love.physics.newWorld(module.Gravity())

local parts = {}
local serializer = 0

local types = {
	Part = "BasePart",
	Button = "Button",
	EditableFrame = "Button",
	Frame = "Gui"
}

local clickedButton

module.type = "Instance"

function module:Inside(pos)
	if self.Shape == "Circle" then
		return self.Size.X/2 >= (self.Position - pos).Magnitude
	elseif self.Shape == "Rectangle" then
		local topLeft = self.Position - self.Size/2
		local bottomRight = self.Position + self.Size/2
		return pos > topLeft and pos < bottomRight
	end
end

within = function(x1,y1, x2,y2,w2,h2)
	x2 = x2 - w2/2
	y2 = y2 - h2/2
	return x1 > x2 and y1 > y2 and x1 < x2+w2 and y1 < y2+h2
end

module.Parts = parts

module.SaveableParts = {}

module.new = function(className, save)
	assert(types[className], "not a valid instance type")
	local part = {
		ClassName = className,
		CFrame = CFrame.new(0, 0, 0),
		Position = Vector.new(0, 0),
		Size = Vector.new(100, 100),
		Color = Color3.new(255, 255, 255),
		Visible = true,
		Relative = true,
		Shape = "Rectangle",
		OutlineStyle = "Border",
		OutlineThickness = 1,
		Changed = Signal.new(),
	}
	part.OutlineColor = part.Color
	if types[className] == "Button" then
		part.Activated = Signal.new()
		part.AutomaticColor = true

		if className == "EditableFrame" then
			part._dragData = {
				left = module.new("Button"),
				right = module.new("Button"),
				up = module.new("Button"),
				down = module.new("Button"),
			}
			part.OutlineStyle = nil
			for i,v in pairs(part._dragData) do
				v.Size = Vector.new(20,20)
				v.OutlineStyle = nil

				v.Activated:Connect(function()
					part._dragData.dragOffset = v.Position - love.mouse.position()
					part._dragData.currentDrag = v
				end)
			end
		end
	elseif types[className] == "BasePart" then
		part.CanCollide = false
		part.Anchored = true
		part.Velocity = Vector.new()
	elseif types[className] == "Gui" then
		part.Relative = nil
		part.Size = Udim.new(0,0,0,0)
		part.Position = Udim.new(0,0,0,0)
	end

	local metapart = setmetatable(part, module)
	local editTable = setmetatable({},{
		__index = function(self, index)
			return part[index]
		end,
		__newindex = function(self, index, value)
			if index == "CFrame" then
				part.Position = value.Position
			elseif index == "Position" then
				part.CFrame = CFrame.new(value.X, value.Y, part.CFrame.R)
			else
				if part[index] == nil then
					return
				end
			end
			if part[index] ~= value then
				local oldValue = part[index]
				part[index] = value
				part.Changed:Run(index, oldValue, value)
			end
		end
	})

	local id = serializer
	serializer=serializer+1
	part.id = id
	parts[id] = editTable

	if className == "EditableFrame" then
		editTable.Activated:Connect(function()
			editTable._dragData.dragOffset = editTable.Position - love.mouse.position()
			editTable._dragData.currentDrag = editTable
		end)
	end
	if save then
		module.SaveableParts[#module.SaveableParts+1] = editTable
	end

	return editTable
end

function module:IsA(className)
	return className == self.ClassName or types[self.ClassName] == className
end

function module:Destroy()
	parts[self.id or -1] = nil
	for i,v in pairs(self) do
		self[i] = nil
	end
end

function updateParts(dt)
	for i,v in pairs(parts) do
		if v:IsA("Button") then
			if v:IsA("EditableFrame") then
				local currentDragging = v._dragData.currentDrag
				local mousePos = love.mouse.position() + (v._dragData.dragOffset or Vector.new(0, 0))
				if love.mouse.isDown(1) then
					if currentDragging == v._dragData.left or currentDragging == v._dragData.right then
						currentDragging.Position = Vector.new(mousePos.X, v.Position.Y)
						v.Position = v._dragData.right.Position:Lerp(v._dragData.left.Position, .5)
						v.Size = Vector.new((v._dragData.left.Position - v._dragData.right.Position).Magnitude-(v._dragData.left.Size.X), v.Size.Y)
					elseif currentDragging == v._dragData.up or currentDragging == v._dragData.down then
						currentDragging.Position = Vector.new(v.Position.X, mousePos.Y)
						v.Position = v._dragData.up.Position:Lerp(v._dragData.down.Position, .5)
						v.Size = Vector.new(v.Size.X, (v._dragData.up.Position - v._dragData.down.Position).Magnitude-(v._dragData.up.Size.Y))
					elseif currentDragging == v then
						currentDragging.Position = mousePos
					end
				else
					v._dragData.currentDrag = nil
				end
				local x,y = v.Position()
				local w,h = v.Size()
				v._dragData.left.Position = Vector.new(x - w/2-(v._dragData.left.Size.X/2), y)
				v._dragData.right.Position = Vector.new(x + w/2+(v._dragData.right.Size.X/2), y)
				v._dragData.up.Position = Vector.new(x, y - h/2-(v._dragData.up.Size.Y/2))
				v._dragData.down.Position = Vector.new(x, y + h/2+(v._dragData.down.Size.Y/2))
			end
		elseif v:IsA("BasePart") then
			-- if not v.Anchored then
			-- 	local nextPos = v.Position + v.Velocity * dt
			-- 	v.Velocity = v.Velocity + module.Gravity * dt
			-- 	v.Position = nextPos
			-- end
			if v.Anchored then
				
			end
		end
	end
end

function drawParts()
	for i,v in pairs(parts) do
		if v.Visible then
			local rmx,rmy = love.mouse.position()()
			local mx,my = love.mouse.getPosition()
			local x,y,r = v.CFrame()
			local w,h
			if v:IsA("Gui") then
				x,y = v.Position:Calculate()
				w,h = v.Size:Calculate()
				r = 0
			else
				x,y,r = v.CFrame()
				w,h = v.Size()
			end
			local inside = not v:IsA("Gui") and (v.Relative and within(rmx,rmy, x,y, w,h) or not v.Relative and within(mx,my, x,y, w,h))
			if v.Relative then
				love.graphics.push()
				love.graphics.translate((CAMERA + Vector.new(WIDTH/2, HEIGHT/2))())
			end
			if v:IsA("Button") and inside and v.AutomaticColor then
				if love.mouse.isDown(1) then
					v.Color(1.2)
				else
					v.Color(.8)	
				end
			else
				v.Color()
			end
			if v.Shape == "Rectangle" then
				if v.OutlineStyle == "Border" then
					if v.OutlineThickness > 0 then
						rect(true, x,y, w,h,r)
						v.OutlineColor(.5)
						love.graphics.setLineWidth(v.OutlineThickness)
						rect(false, x,y,w+v.OutlineThickness/2,h+v.OutlineThickness/2, r)
						love.graphics.setLineWidth(1)
					end
				elseif v.OutlineStyle == "Fancy" then
					rect(true, x,y, w,h,r)
					love.graphics.push()
					love.graphics.translate(x,y)
					love.graphics.rotate(r)
					local t = v.OutlineThickness
					--top
					v.OutlineColor(.9)
					for i=0, t-1 do
						rect(true, 0, -h/2+i,w-i*2,1, 0)
					end
					--bottom
					v.OutlineColor(.6)
					for i=0, t-1 do
						rect(true, 0, h/2-i,w-i*2,1, 0)
					end
					--left
					v.OutlineColor(.85)
					for i=0, t-1 do
						rect(true, -w/2+i, 0,1,h-i*2, 0)
					end
					--right
					v.OutlineColor(.65)
					for i=0, t-1 do
						rect(true, w/2-i, 0,1,h-i*2, 0)
					end

					love.graphics.pop()
				elseif v.OutlineStyle == "Glass" then
					rect(true, x,y, w,h,r)
					love.graphics.push()
					love.graphics.translate(x,y)
					love.graphics.rotate(r)
					local t = v.OutlineThickness
					v.OutlineColor(.5)
					rect(true, w/2-t/2, 0, t,h,0)
					v.OutlineColor(.5)
					rect(true, 0, h/2-t/2, w,t,0)
					v.OutlineColor(.9)
					rect(true, -w/2+t/2, 0, t,h,0)
					v.OutlineColor(.9)
					rect(true, 0, -h/2+t/2, w,t,0)

					love.graphics.pop()
				elseif v.OutlineStyle == "Fade" then
					local t = v.OutlineThickness*4-1
					rect(true, x, y, w-v.OutlineThickness,h-v.OutlineThickness,r)
					for i=0,t do
						local p = i/t
						--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
						v.OutlineColor(1,1-p)
						rect(false, x,y, w-i+(i*.5),h-i+(i*.5), r)
					end
				else
					rect(true, x,y, w,h,r)
				end
			elseif v.Shape == "Circle" then
				if v.OutlineStyle == "Fade" then
					local t = v.OutlineThickness
					love.graphics.circle("fill", x, y, w/2-v.OutlineThickness)
					for i=0,t do
						local p = i/t
						--v.Color:Lerp(BACKGROUND_COLOR, 1-p)()
						v.OutlineColor(1,1-p)
						love.graphics.circle("line", x,y, w/2-(i))
					end
				else
					love.graphics.circle("fill", x,y,w/2)
				end
			end
			if v.Relative then
				love.graphics.pop()
			end
		end
	end
end


Input.InputEnded:Connect(function(input)
	if input.Mouse == Enum.Mouse.LeftMouseButton then
		clickedButton = nil
	end
end)
Input.InputBegan:Connect(function(input)
	if input.Mouse == Enum.Mouse.LeftMouseButton then
		for i,v in pairs(parts) do
			if v:IsA("Button") then
				local rmx,rmy = love.mouse.position()()
				local mx,my = love.mouse.getPosition()
				local x,y = v.Position()
				local w,h = v.Size()
				local inside = v.Relative and within(rmx,rmy, x,y, w,h) or not v.Relative and within(mx,my, x,y, w,h)
				if inside then
					if not clickedButton then
						clickedButton = true
						v.Activated:Run()
					end
				end
			end
		end
	end
end)

return module