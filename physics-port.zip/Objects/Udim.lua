local module = {}
module.__index = module

module.new = function(offx, scalex, offy, scaley)
	local udim = {
		Scale = {
			X = scalex or 0,
			Y = scaley or 0,
		},
		Offset = {
			X = offx or 0,
			Y = offy or 0,
		}
	}
	return setmetatable(udim, module)
end

function module.__add(other)
	local x1 = self.Scale.X + other.Scale.X
	local y1 = self.Scale.Y + other.Scale.Y
	local x2 = self.Offset.X + other.Offset.X
	local y2 = self.Offset.Y + other.Offset.Y
	return module.new(x1,y1,x2,y2)
end

function module.__sub(other)
	local x1 = self.Scale.X - other.Scale.X
	local y1 = self.Scale.Y - other.Scale.Y
	local x2 = self.Offset.X - other.Offset.X
	local y2 = self.Offset.Y - other.Offset.Y
	return module.new(x1,y1,x2,y2)
end
function module.__mul(other)
	local x1,y1,x2,y2
	if type(other) == "number" then
		x1 = self.Scale.X * other
		y1 = self.Scale.Y * other
		x2 = self.Offset.X * other
		y2 = self.Offset.Y * other
	else
		x1 = self.Scale.X * other.Scale.X
		y1 = self.Scale.Y * other.Scale.Y
		x2 = self.Offset.X * other.Offset.X
		y2 = self.Offset.Y * other.Offset.Y
	end
	return module.new(x1,y1,x2,y2)
end
function module.__div(other)
	local x1,y1,x2,y2
	if type(other) == "number" then
		x1 = self.Scale.X / other
		y1 = self.Scale.Y / other
		x2 = self.Offset.X / other
		y2 = self.Offset.Y / other
	else
		x1 = self.Scale.X / other.Scale.X
		y1 = self.Scale.Y / other.Scale.Y
		x2 = self.Offset.X / other.Offset.X
		y2 = self.Offset.Y / other.Offset.Y
	end
	return module.new(x1,y1,x2,y2)
end

function module:lerp(to, alpha)
	return (self * (1-alpha) + to * alpha)
end

function module:Calculate()
	local s,o = self.Scale, self.Offset
	return s.X * WIDTH + o.X, s.Y * HEIGHT + o.Y
end

module.type = "Udim"

return module