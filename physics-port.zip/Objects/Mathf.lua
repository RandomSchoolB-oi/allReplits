local module = {}

pythagoras = function(x1,y1, x2,y2)
	local w,h = x1 - x2, h1 - h2
	return math.sqrt(w^2 + h^2)
end
lerp = function(a,b,alpha)
	return a * (1-alpha) + b * alpha
end
clamp = function(numb, min, max)
	return numb > max and max or numb < min and min or numb
end
triHeight = function(a)
	return a * math.sqrt(3) / 2 
end

local s = 0

local _amp, _freq
layeredNoise = function(x,y,seed,layers,amp, freq)
	_amp, _freq = amp, freq
	local noise = 0
	for i=1,layers do
		s = s + 1
		if s % 100 == 0 then
			wait(0.1)
		end
		noise = noise + love.math.noise(x * _freq, y * _freq, seed * _freq) * _amp
		_amp = _amp * .5
		_freq = _freq * 1.1
	end
	return noise
end

module.Hypotenuse = pythagoras
module.Lerp = lerp
module.noise = layeredNoise
module.clamp = clamp
module.triHeight = triHeight
module.find = function(tbl, val)
	for i,v in pairs(tbl) do
		if v == val then
			return i
		end
	end
end

--[[
	y2 - y1 / x2 - x1
]]
module.slope = {
	calcM = function(a,b) -- slope
		return (b[2] - a[2]) / (b[1] - a[1]) 
	end,

	calcB = function(m,x,y) -- y-intercept
		return y/m-x
	end,

	calcY = function(m,x,b) -- y
		return m*x+b
	end,
}

return module