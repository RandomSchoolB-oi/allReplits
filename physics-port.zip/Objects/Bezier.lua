local module = {}
module.__index = module

module.new = function(...)
	local path = {
		points = {...}
	}
	return setmetatable(path, module)
end

function module:get(percent)
	local points = self.points
	if #points == 3 then
		local ab = points[1]:Lerp(points[2], percent)
		local bc = points[2]:Lerp(points[3], percent)
		local ac = ab:Lerp(bc, percent)
		return ac
	elseif #points == 4 then
		local ab = points[1]:Lerp(points[2], percent)
		local cd = points[3]:Lerp(points[4], percent)
		local ab = ab:Lerp(cd, percent)
		return ab
	elseif #points == 5 then
		local ab = points[1]:Lerp(points[2], percent)
		local de = points[4]:Lerp(points[5], percent)
		local bc = ab:Lerp(points[3], percent)
		local cd = de:Lerp(points[3], percent)
		local ae = bc:Lerp(cd, percent)
		return ae
	end
end

return module