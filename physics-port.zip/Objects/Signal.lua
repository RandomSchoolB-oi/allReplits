local module = {}
module.__index = module

local serial = 0

module.new = function()
	return setmetatable({
		_connections = {},
	}, module)
end

function module:Connect(callback)
	local id = serial
	serial = serial + 1
	self._connections[id] = {
		_call = function(...)
			callback(...)
		end,
		Disconnect = function()
			self._connections[id] = nil
		end,
	}
end

module.connect = module.Connect

-- function module:Wait()
-- 	local startTime = os.clock()

-- 	self._Waiting = true
-- 	repeat until not self._Waiting

-- 	return oc.clock() - startTime
-- end

function module:Run(...)
	-- self._Waiting = false
	for i,v in pairs(self._connections) do
		v._call(...)
	end
end

return module