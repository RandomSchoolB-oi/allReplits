local module = {}
module.__index = module

module.InputBegan = Signal.new()
module.InputEnded = Signal.new()

local lastPressed = {}

local enumLookup = {}
for inputType, tbl in pairs(Enum) do
	enumLookup[inputType] = {}
	for enum, key in pairs(tbl) do
		enumLookup[inputType][key] = enum
	end
end

love.keypressed = function(key)
	if enumLookup.Keyboard[key] then
		lastPressed[enumLookup.Keyboard[key]] = os.clock()
		module.InputBegan:Run({
			Keyboard = Enum.Keyboard[enumLookup.Keyboard[key]]
		})
	end
end
love.mousepressed = function(_, _, button)
	if enumLookup.Mouse[button] then
		lastPressed[enumLookup.Mouse[button]] = os.clock()
		module.InputBegan:Run({
			Mouse = Enum.Mouse[enumLookup.Mouse[button]]
		})
	end
end


love.keyreleased = function(key)
	if enumLookup.Keyboard[key] then
		module.InputEnded:Run({
			Keyboard = Enum.Keyboard[enumLookup.Keyboard[key]]
		}, os.clock() - lastPressed[enumLookup.Keyboard[key]])
	end
end
love.mousereleased = function(_, _, button)
	if enumLookup.Mouse[button] then
		module.InputEnded:Run({
			Mouse = Enum.Mouse[enumLookup.Mouse[button]]
		}, os.clock() - lastPressed[enumLookup.Mouse[button]])
	end
end


return module