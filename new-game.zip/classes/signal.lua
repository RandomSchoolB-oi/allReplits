local module = {}
module.__index = module
module.type = "signal"
	
module.new = function()
	return setmetatable({}, module)
end

function module:connect(callback, order)
	local connection = {
		order = order or 10,
		_callback = callback,
		disconnect = function(connection)
			table.remove(self, table.find(self, connection))
		end,
	}
	connection.Disconnect = connection.disconnect
	table.insert(self, connection)
	return connection
end

function module:once(callback)
	local connection connection = self:connect(function(...)
		connection:Disconnect()
			
		coroutine.wrap(callback)(...)
	end)
end

function module:wait()
	local thread = coroutine.running()
	self:once(function(...)
		coroutine.resume(thread, ...)
	end)
	return coroutine.yield()

	-- local returned
	-- self:once(function(...)
	-- 	returned = {...}
	-- end)
	-- while not returned do end
	-- return unpack(returned)
end

local unknownOrder = 99999
local doOrderedSignals = true
function module:fire(...)
	if doOrderedSignals then
		local orderedConnections = {}
		
		for _, connection in pairs(self) do
			if not orderedConnections[connection.order or unknownOrder] then
				orderedConnections[connection.order or unknownOrder] = {}
			end
			table.insert(orderedConnections[connection.order], connection)
		end
	
		local orderList = {}
		for order in pairs(orderedConnections) do
			table.insert(orderList, order)
		end
		table.sort(orderList, function(a,b)
			return a < b
		end)
		-- for i = #orderList, 1, -1 do
		--	local v = orderList[i]
		for i,v in ipairs(orderList) do
			local list = orderedConnections[v]
			for _, connection in ipairs(list) do
				coroutine.wrap(connection._callback)(...)
			end
		end
	else
		for _, connection in pairs(self) do
			coroutine.wrap(connection._callback)(...)
		end
	end
end

function module:destroy()
	local index, task = next(self)
	while index and task ~= nil do
		task:disconnect()
		index, task = next(self)
	end
end

return module