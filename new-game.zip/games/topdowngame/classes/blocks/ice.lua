local module = {}
module.__index = module
module.derives = "games/topdowngame/classes/tile"

module.new = function(self)
	-- self.image = love.graphics.newImage("games/topdowngame/assets/grass.png")
	self.color = color.new(0.2, 0.2, 1, 1)
	-- self.friction = vector2.new(0.2, 0.2)
	
	return self
end

module.init = function()
	instance.addClass("ice", module)
end

return module