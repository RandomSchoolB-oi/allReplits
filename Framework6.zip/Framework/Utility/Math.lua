local originalMath = math
math = {}
for i,v in pairs(originalMath) do
	math[i] = v
end

math.clamp = function(x,a,b)
	return x < a and a or x > b and b or x
end

math.lerp = function(a,b,x)
	return (b-a)*x+a
end

math.dist = function(a,b)
	return math.abs(b-a)
end

math.map = function(minI, maxI, minO, maxO, x)
	return ((x-minI)/(maxI-minI))*(maxO-minO)+minO
end

math.noise = function(...)
	local noise = love.math.noise(...)
	return (noise - 0.5) * 2
end

math.AABB = function(p1, s1, p2,s2)
	local diff = p2-p1
	local range = (s1+s2)/2
	if math.abs(diff.X) > range.X or math.abs(diff.Y) > range.Y then
		return false
	end
	return true
end