local originalTable = table
table = {}
for i,v in pairs(originalTable) do
	table[i] = v
end

table.insert = function(table, value, index)
	if not index then index = #table+1 end
	table[index] = value
end

table.unpack = unpack
table.find = function(haystack, needle)
	for i,v in pairs(haystack) do
		if v == needle then
			return i
		end
	end
end
table.copy = function(tbl)
	local copy = {}
	for i,v in pairs(tbl) do
		local indexType = type(i)
		if typeof(v)=="Maid" then
			v = Maid.new()
		end
		if indexType == "string" and (not i:find("__")) or indexType ~= "string" then
			if type(v) == "table" then
				local val = table.copy(v)
				local meta = getmetatable(v)
				if meta then setmetatable(val, meta) end
				copy[i] = val
			else
				copy[i] = v
			end
		end
	end
	return copy
end