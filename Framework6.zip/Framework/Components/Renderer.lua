local module = {}
module.__index = module
module.ClassName = "Renderer"
module.Inherits = "BaseClasses/BaseComponent"

module.new = function(this)
	local self = setmetatable(module.InheritClass.new(), module)
	self.this = this
	self.Color = Color.new(1,1,1,1)
	self.Image = ""
	self._image = {}
	self._buttonHover = false
	self._buttonClick = false
	return self
end

function module:Update(dt)
	if self._image.name ~= self.Image then
		self._image.name = self.Image
		if self.Image and self.Image ~= "" then
			self._image.image = love.graphics.newImage(self.Image)
		end
	end
end

function module:Draw()
	local cf = self.this.CFrame
	local size = self.this.Size
	love.graphics.push()
	love.graphics.translate(cf.X, cf.Y)
	love.graphics.rotate(cf.R)
	local color = self.Color
	if self._buttonClick then
		color = color:Lerp(Color.White, 1/10)
	elseif self._buttonHover then
		color = color:Lerp(Color.Black, 1/15)
	end
	love.graphics.setColor(color:Get())
	if self._image.image then
		local imageSizeX, imageSizeY = self._image.image:getDimensions()
		local scaleX, scaleY = size.X/imageSizeX, size.Y/imageSizeY
		love.graphics.draw(self._image.image, -size.X/2, -size.Y/2, 0, scaleX, scaleY)
	else
		local collider = self.this:GetComponent("Collider")
		if collider then
			for _, triangle in ipairs(collider:GetTriangles()) do
				love.graphics.polygon("fill", triangle)
			end
		else
			love.graphics.rectangle("fill", -size.X/2, -size.Y/2, size.X, size.Y)
		end
	end
	love.graphics.pop()
end

return module