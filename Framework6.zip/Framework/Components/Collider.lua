local module = {}
module.__index = module
module.ClassName = "Collider"
module.Inherits = "BaseClasses/BaseComponent"

module.new = function(this)
	local self = setmetatable(module.InheritClass.new(), module)
	self.this = this
	-- self.Vertices = {}
	-- local dots = 12
	-- for i = 1, dots do
	-- 	local p = i/dots * math.pi*2
	-- 	local x = math.cos(p)
	-- 	local y = math.sin(p)
	-- 	table.insert(self.Vertices, Vector.new(x, y))
	-- end
	self.Vertices = { -- MUST BE CONVEX
		Vector.new(-1, -1),
		Vector.new(1, -1),
		Vector.new(1, 1),
		Vector.new(-1, 1),
	}
	return self
end

function module:GetDot(index)
	local size = self.this.Size/2
	-- local rot = self.this.Rotation
	return self.this.CFrame.Position + self.Vertices[index]:MatrixMultiply(Vector.GetRotationMatrix(self.this.CFrame.R)) * size
	-- return self.this.CFrame + self.Vertices[index] * size
end

function module:GetMinMax(axis, offset)
	local min = math.huge
	local max = -math.huge

	local offset = offset or Vector.new()
	
	for i = 1, #self.Vertices do
		local projected = (self:GetDot(i) + offset):Dot(axis)
		if projected < min then min = projected end
		if projected > max then max = projected end
	end
	
	return min,max
end

function module:GetTriangles()
	local list  = {}
	local hSize = self.this.Size/2
	for _, vertex in ipairs(self.Vertices) do
		table.insert(list, vertex.X*hSize.X)
		table.insert(list, vertex.Y*hSize.Y)
	end
	local triangles = love.math.triangulate(list)
	return triangles
end

local function getNormal(x1,y1,x2,y2)
	local angle = math.atan2(y2-y1, x2-x1) - math.pi/2
	return Vector.new(math.cos(angle), math.sin(angle))
end

-- function module:GetCenterOfGeometry()
-- 	local center
-- 	local prevDot
-- 	for i = 1, #self.Vertices do
-- 		local vert1, vert2 = self.Vertices[i], self.Vertices[i % #self.Vertices + 1]
-- 		center = (center or vert1):Lerp(vert2, 0.5)
-- 	end
-- 	return center * self.this.Size + self.this.Position
-- end

function module:GetNormals()
	local normals = {}
	local triangles = self:GetTriangles()
	for _, points in ipairs(triangles) do
		table.insert(normals, getNormal(points[1], points[2], points[3], points[4]))
		table.insert(normals, getNormal(points[3], points[4], points[5], points[6]))
		table.insert(normals, getNormal(points[5], points[6], points[1], points[2]))
	end
	return normals
end
function module:GetFaces()
	local faces = {}
	local points = {}
	for i = 1, #self.Vertices do
		local dot = self:GetDot(i)
		table.insert(points, dot)
	end

	for i = 1, #points do
		local dot = points[i]
		local nextDot = points[i % #points + 1]
		table.insert(faces, {from = dot, to = nextDot})
	end
	return faces
end

local function Lerp(a,b,alpha)
	return (b-a)*alpha+a
end
local function dist(a,b)
	return math.abs(b-a)
end

local function getDistOnAxis(box1,box2, axis, offset)
	local min_proj_box1, max_proj_box1 = box1:GetMinMax(axis, offset)
	local min_proj_box2, max_proj_box2 = box2:GetMinMax(axis)
	local width1 = dist(min_proj_box1, max_proj_box1)
	local width2 = dist(min_proj_box2, max_proj_box2)
	local origin1 = Lerp(min_proj_box1, max_proj_box1, 1/2)
	local origin2 = Lerp(min_proj_box2, max_proj_box2, 1/2)

	local dist = dist(origin1, origin2)
	local range = (width1+width2)/2

	return dist, range
end

function module:TouchingPoint(point)
	for i, axis in pairs(self:GetNormals()) do
		local min, max = self:GetMinMax(axis)
		local width = dist(min, max)
		local origin = Lerp(min, max, 1/2)
		
		if dist(origin, point) > width/2 then -- if they are far apart enough, then they arent colliding
			return false
		end
	end
	return true
end

function module:AreColliding(other, offset)
	local normals = {}
	for _, v in pairs(self:GetNormals()) do
		table.insert(normals, v)
	end
	for _, v in pairs(other:GetNormals()) do
		table.insert(normals, v)
	end
	local deepestAxis, deepLength = nil, 0
	for i, axis in pairs(normals) do
		-- local axis = Vector.new(1,1).Unit
		local dist, range = getDistOnAxis(self, other, axis, offset)
		if dist > range then -- if they are far apart enough, then they arent colliding
			return false
		elseif dist > deepLength then
			deepestAxis, deepLength = axis, dist
		end
	end

	local offset = offset or Vector.new(0, 0)
	local dist, range = getDistOnAxis(self, other, deepestAxis, offset)
	
	return true, deepestAxis, (range-dist)
end

function module:DrawNormals()
	local normals = self:GetNormals()
	local pos = self.this.Position--self:GetCenterOfGeometry()
	local size = self.this.Size
	for _, normal in pairs(normals) do
		local from = (pos+normal*(size/2))
		local to = from + normal * 25
		love.graphics.line(from.X, from.Y, to.X, to.Y)
	end
end

function module:DrawTriangles()
	local triangles = self:GetTriangles()
	love.graphics.push()
	love.graphics.translate(self.this.Position.X, self.this.Position.Y)
	for i, triangle in ipairs(triangles) do
		local hue = math.map(1, #triangles, 0, 1, i)
		local color = Color.fromHSV(hue, 1, 1, 1)
		love.graphics.setColor(color:Get())
		love.graphics.polygon("fill", triangle)
	end
	love.graphics.pop()
end

function module:DrawPoints()
	-- local center = self:GetCenterOfGeometry()
	-- print(center.X, center.Y)
	-- love.graphics.circle("fill", center.X, center.Y, 3)
	for i = 1, #self.Vertices do
		local pos = self:GetDot(i)
		love.graphics.circle("fill", pos.X, pos.Y, 5)
	end
end

function module:Update(dt)
end

function module:Draw()
	-- self:DrawNormals()
	-- self:DrawPoints()
end

function module:Destroy()
end

return module