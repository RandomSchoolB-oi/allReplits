local module = {}
module.__index = module
module.ClassName = "Button"
module.Inherits = "BaseClasses/BaseComponent"

module.new = function(this)
	local self = setmetatable(module.InheritClass.new(), module)
	self.this = this
	self.Activated = Signal.new()
	self.HoverBegin = Signal.new()
	self.HoverEnded = Signal.new()
	self.Maid:GiveTask(self.Activated)
	self.Maid:GiveTask(this.MousePressed:Connect(function(x,y,button)
		if button == 1 then
			if self:IsHovering(x,y) then
				local renderer = self.this:GetComponent("Renderer")
				if renderer then
					renderer._buttonClick = true
				end
				self.Activated:Fire(x,y)
			end
		end
	end))
	self.Maid:GiveTask(this.MouseReleased:Connect(function(x,y,button)
		if button == 1 then
			local renderer = self.this:GetComponent("Renderer")
			if renderer then
				renderer._buttonClick = false
			end
		end
	end))
	self.Maid:GiveTask(function()
		local renderer = self.this:GetComponent("Renderer")
		if renderer then
			renderer._buttonHover = false
			renderer._buttonClick = false
		end
	end)
	return self
end

function module:IsHovering(x,y)
	local size = self.this.Size
	local pos = self.this.CFrame
	local min = pos - size/2
	local max = min + size

	return x > min.X and x < max.X and y > min.Y and y < max.Y
end

function module:Update(dt)
	local renderer = self.this:GetComponent("Renderer")
	if renderer then
		local game = self.this:GetGame()
		local mp = game and game:GetMousePosition()
		if mp and self:IsHovering(mp.X, mp.Y) then
			if not renderer._buttonHover then
				self.HoverBegin:Fire()
			end
			renderer._buttonHover = true
		else
			if renderer._buttonHover then
				self.HoverEnded:Fire()
			end
			renderer._buttonHover = false
		end
	end
end

function module:Draw()
end

return module