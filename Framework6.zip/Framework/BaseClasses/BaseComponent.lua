local module = {}
module.__index = module

module.new = function()
	local self = {}
	self.Maid = Maid.new()
	return self
end

function module:Destroy()
	self.Maid:Destroy()
end

return module