local module = {}
module.__index = module

module.new = function(r,g,b,a)
	local self = setmetatable({}, module)
	self.R = (r or 0)
	self.G = (g or 0)
	self.B = (b or 0)
	self.A = (a or 1)
	return self
end

module.fromHSV = function(h,s,v, a)
    if s <= 0 then return v,v,v end
    h = h*6
    local c = v*s
    local x = (1-math.abs((h%2)-1))*c
    local m,r,g,b = (v-c), 0, 0, 0
    if h < 1 then
        r, g, b = c, x, 0
    elseif h < 2 then
        r, g, b = x, c, 0
    elseif h < 3 then
        r, g, b = 0, c, x
    elseif h < 4 then
        r, g, b = 0, x, c
    elseif h < 5 then
        r, g, b = x, 0, c
    else
        r, g, b = c, 0, x
    end
    return module.new(r+m, g+m, b+m, a)
end

function module:Lerp(other, alpha)
	return module.new(
		math.lerp(self.R, other.R, alpha),
		math.lerp(self.G, other.G, alpha),
		math.lerp(self.B, other.B, alpha),
		math.lerp(self.A, other.A, alpha)
	)
end

function module:Get()
	-- return self.R, self.G, self.B, self.A
	return self.R*255, self.G*255, self.B*255, self.A*255
end

module.White = module.new(1,1,1,1)
module.Black = module.new(0,0,0,1)
module.Red = module.new(1,0,0,1)
module.Green = module.new(0,1,0,1)
module.Blue = module.new(0,0,1,1)

return module