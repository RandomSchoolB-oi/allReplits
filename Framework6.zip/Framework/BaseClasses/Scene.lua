local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Maid = Maid.new()
	self.OnDraw = Signal.new()
	self.OnUpdate = Signal.new()
	
	self.MousePressed = Signal.new()
	self.MouseReleased = Signal.new()
	self.KeyboardPressed = Signal.new()
	self.KeyboardReleased = Signal.new()
	
	self.Objects = {}
	self.Enabled = true
	self.Paused = false

	self.Maid:GiveTask(self.OnDraw)
	self.Maid:GiveTask(self.OnUpdate)

	self.OnDraw:Connect(function()
		if not self.Enabled then return end
		for object in pairs(self.Objects) do
			object:Draw()
		end
	end)
	self.OnUpdate:Connect(function(dt)
		if not self.Enabled or self.Paused then return end
		for object in pairs(self.Objects) do
			object:Update(dt)
		end
	end)
	self.MousePressed:Connect(function(...)
		if not self.Enabled or self.Paused then return end
		for object in pairs(self.Objects) do
			object.MousePressed:Fire(...)
		end
	end)
	self.MouseReleased:Connect(function(...)
		if not self.Enabled or self.Paused then return end
		for object in pairs(self.Objects) do
			object.MouseReleased:Fire(...)
		end
	end)
	self.KeyboardPressed:Connect(function(...)
		if not self.Enabled or self.Paused then return end
		for object in pairs(self.Objects) do
			object.KeyboardPressed:Fire(...)
		end
	end)
	self.KeyboardReleased:Connect(function(...)
		if not self.Enabled or self.Paused then return end
		for object in pairs(self.Objects) do
			object.KeyboardReleased:Fire(...)
		end
	end)
	
	return self
end

local cast = function(origin, goal, wall)
	local x1, y1 = wall.from:Get()
	local x2, y2 = wall.to:Get()

	local x3, y3 = origin:Get()
	local x4, y4 = goal:Get()

	local denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
	if denominator == 0 then
		return
	end
	
	local t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denominator
	local u =-((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denominator
	
	if t > 0 and t < 1 and u > 0 then
		return Vector.new(
			x1 + t * (x2 - x1),
			y1 + t * (y2 - y1)
		)
	end
end

function module:Raycast(origin, direction, filterType, filterList)
	local instance, position, normal
	local closest, closestDist = 0, math.huge
	local rayLength = direction.Magnitude
	local goal = origin + direction

	local objects
	if filterType == "wl" then
		objects = {}
		for _, object in pairs(filterList) do
			objects[object] = true
		end
	else
		objects = self.Objects
	end
	
	for part in pairs(self.Objects) do
		local can = true
		if filterType == "bl" then
			if table.find(filterList, part) then
				can = false
			end
		end
		local collider = part:GetComponent("Collider")
		if collider and can then
			local boundaries = collider:GetFaces()
		
			for i,v in ipairs(boundaries) do
				local collidingPos = cast(origin, goal, v) 
				if collidingPos then
					local dist = (collidingPos - origin).Magnitude
					if dist <= rayLength then
						if position and dist < closestDist or not position then
							closest, closestDist = part, dist
							instance, position, normal = part, collidingPos, (v.to-v.from).Unit:Rotate(-math.pi/2)
						end
					end
				end
			end
		end
	end
	return instance, position, normal
end

function module:GiveObject(object)
	self.Objects[object] = true
	object.Scene = self
end

function module:RemoveObject(object)
	self.Objects[object] = nil
	object.Scene = nil
end

--[[



function module:Cast()
	local instance, position, normal
	local closest, closestDist = 0, math.huge
	local rayLength = self.Direction.Magnitude
	for _, part in pairs(AllObjects) do
		local collider = part:GetComponent("PolygonCollider")
		if collider then
			local boundaries = collider:GetFaces()
		
			for i,v in pairs(boundaries) do
				local collidingPos = cast(self, v) 
				if collidingPos then
					local dist = (collidingPos - self.Origin).Magnitude
					if dist <= rayLength then
						if position and dist < closestDist or not position then
							closest, closestDist = part, dist
							instance, position, normal = part, collidingPos, CFrame.lookat(v.to.X,v.to.Y, v.from.X,v.from.Y).RightVector
						end
					end
				end
			end
		end
	end
	self.Result = {
		Object = instance,
		Position = position or self.Origin + self.Direction,
		Normal = normal,
	}
	return self.Result
end

function module:Draw()
	local ro = self.Origin * UnitSize
	local rd = self.Direction * UnitSize
	love.graphics.setColor(255,255,255)
	love.graphics.line(ro.X, ro.Y, ro.X+rd.X, ro.Y+rd.Y)

	local rayPart, rayPos, rayNormal = self.Result.Object, self.Result.Position, self.Result.Normal
		
	if rayPos then
		love.graphics.circle("fill", rayPos.X*UnitSize,rayPos.Y*UnitSize, 10)
	
		if rayNormal then
			local p, d = rayPos*UnitSize, (rayPos+rayNormal)*UnitSize
			love.graphics.line(p.X,p.Y, d.X,d.Y)
		end
	end
end

return module

]]

return module