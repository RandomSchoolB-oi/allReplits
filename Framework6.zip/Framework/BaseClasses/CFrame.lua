local module = {}
module.ClassName = "CFrame"
local pi = math.pi
local hpi = pi/2
local tpi = pi*2
module.__index = function(self, i)
	local selfHas = rawget(self,i)
	if selfHas then return selfHas end
	local moduleHas = rawget(module,i)
	if moduleHas then return moduleHas end
	if i == "RightVector" then
		local r = self.R
		return Vector.new(math.cos(r), math.sin(r))
	end
	if i == "UpVector" then
		local r = self.R
		return Vector.new(math.sin(r), math.cos(r))
	end
	if i == "Position" then
		return Vector.new(self.X, self.Y)
	end
end

module.new = function(x,y,r)
	return setmetatable({
		X = x or 0,
		Y = y or 0,
		R = (r or 0)%tpi,
	}, module)
end

function module:__mul(other)
	local movedX = self.RightVector * other.X
	local movedY = self.UpVector * other.Y
	local r = other.R + self.R

	return module.new(
		self.X + movedX.X + movedY.X, 
		self.Y + movedX.Y + movedY.Y, 
	r)
end

function module:__add(vec)
	return module.new(self.X + vec.X, self.Y + vec.Y, self.R)
end
function module:__sub(vec)
	return module.new(self.X - vec.X, self.Y - vec.Y, self.R)
end

function module:Inverse()
	return module.new(-self.X, -self.Y, self.R - hpi)
end

return module