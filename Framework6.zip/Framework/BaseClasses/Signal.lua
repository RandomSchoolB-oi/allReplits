local module = {}
module.__index = module
module.ClassName = "Signal"

module.new = function()
	return setmetatable({}, module)
end

function module:Fire(...)
	for _, v in pairs(self) do
		v.callback(...)
	end
end

function module:Connect(callback, order)
	local connection = {
		Disconnect = function(connection)
			for i,v in pairs(self) do
				if v == connection then
					table.remove(self, i)
					return
				end
			end
		end,
		callback = callback,
	}
	table.insert(self, connection, order)
	return connection
end

function module:Once(callback)
	local conn conn = self:Connect(function(...)
		conn:Disconnect()
		callback(...)
	end)
	return conn
end

function module:Wait()
	local thread = coroutine.running()
	self:Once(function(...)
		coroutine.resume(thread, ...)
	end)	
	return coroutine.yield(thread)
end

function module:Destroy()
	for _, conn in pairs(self) do
		conn:Disconnect()
	end
end

return module