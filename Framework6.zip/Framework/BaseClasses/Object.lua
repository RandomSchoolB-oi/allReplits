local module = {}
module.__index = module
module.ClassName = "Object"

module.new = function()
	local self = setmetatable({}, module)
	self.Maid = Maid.new()
	self.Components = {}
	self.CFrame = CFrame.new()
	self.Size = Vector.new(100, 100)
	self.MousePressed = Signal.new()
	self.MouseReleased = Signal.new()
	self.KeyboardPressed = Signal.new()
	self.KeyboardReleased = Signal.new()
	return self
end

function module:GetGame()
	return self.Scene and self.Scene.Game
end

function module:Update(dt)
	for _, v in pairs(self.Components) do
		v:Update(dt)
	end
end

function module:Draw()
	for _, v in pairs(self.Components) do
		v:Draw()
	end
end

function module:AddComponent(name)
	local component = AllComponents[name]
	if component and not self:GetComponent(name) then
		local newComp = component.new(self)
		self.Components[name] = newComp
		self.Maid:GiveTask(newComp)
		return newComp
	end
end

function module:GetComponent(name)
	return self.Components[name]
end

function module:RemoveComponent(name)
	local comp = self:GetComponent(name)
	if comp then
		comp:Destroy()
		self.Components[name] = nil
	end
end

function module:Destroy()
	for name in pairs(self.Components) do
		self:RemoveComponent(name)
	end
	self.Scene:RemoveObject(self)
end

return module