local module = {}
module.ClassName = "Vector"
module.__index = function(self, i)
	local selfHas = rawget(self,i)
	if selfHas then return selfHas end
	local moduleHas = rawget(module,i)
	if moduleHas then return moduleHas end
	if i == "Magnitude" then
		return math.sqrt(self.X^2+self.Y^2)
	end
	if i == "Unit" then
		return self/self.Magnitude
	end
end

module.new = function(x,y)
	local self = setmetatable({
		X = x or 0,
		Y = y or 0,
	}, module)
	return self
end

function module:Dot(other) -- expects the vectors to be normalized
	return (self.X * other.X) + (self.Y * other.Y)
end
function module:Cross(other)
	return (self.X * other.Y) + (self.Y * other.X)
end

function module:__add(other)
	return module.new(self.X+other.X, self.Y+other.Y)
end
function module:__sub(other)
	return module.new(self.X-other.X, self.Y-other.Y)
end
function module:__div(other)
	if typeof(other) == "Vector" then
		return module.new(self.X/other.X, self.Y/other.Y)
	end
	return module.new(self.X/other, self.Y/other)
end
function module:__mul(other)
	if typeof(other) == "Vector" then
		return module.new(self.X*other.X, self.Y*other.Y)
	end
	return module.new(self.X*other, self.Y*other)
end
function module:Rotate(rads)
	local magnitude = self.Magnitude
	local normalized = self/magnitude
	local rot = math.atan2(normalized.Y, normalized.X)
	local newRot = rot + rads
	return module.new(math.cos(newRot) * magnitude, math.sin(newRot) * magnitude)
end

function module:Lerp(b, x)
	return Vector.new(
		math.lerp(self.X, b.X, x),
		math.lerp(self.Y, b.Y, x)
	)
end

function module:Get()
	return self.X, self.Y
end

function module:__eq(other)
	return self.X == other.X and self.Y and other.Y
end

function module:__unm(other)
	return module.new(-self.X, -self.Y)
end


return module