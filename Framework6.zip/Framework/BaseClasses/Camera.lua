local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Position = Vector.new(0, 0)
	self:ChangeSize(Vector.new(800, 600))
	return self
end
function module:ChangeSize(newSize)
	self.Size = newSize
	love.window.setMode(self.Size.X, self.Size.Y)
end
function module:GetMousePos()
	return Vector.new(love.mouse:getPosition()) - self.Position
end

function module:Push()
	love.graphics.push()
	love.graphics.translate(-self.Position.X, -self.Position.Y)
end
function module:Pop()
	love.graphics.pop()
end

return module