local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Maid = Maid.new()
	self.Scenes = {}
	self.Camera = Camera.new()
	self.FPSCap = 60
	local lastUpdate = 0
	
	self:NewScene("Default")

	local _et = 0
	self.Maid:GiveTask(OnUpdate:Connect(function(dt)
		local t = os.clock()
		_et = _et + dt
		if t-lastUpdate < 1/self.FPSCap then
			return
		end
		lastUpdate = t
		et = _et
		_et = 0
		for sceneName, scene in pairs(self.Scenes) do
			scene.OnUpdate:Fire(et)
		end
	end))
	self.Maid:GiveTask(OnDraw:Connect(function(...)
		self.Camera:Push()
		for sceneName, scene in pairs(self.Scenes) do
			scene.OnDraw:Fire(...)
		end
		self.Camera:Pop()
	end))
	self.Maid:GiveTask(MousePressed:Connect(function(_,_,button)
		local mousePos = self:GetMousePosition()
		for sceneName, scene in pairs(self.Scenes) do
			scene.MousePressed:Fire(mousePos.X,mousePos.Y,button)
		end
	end))
	self.Maid:GiveTask(MouseReleased:Connect(function(_,_,button)
		local mousePos = self:GetMousePosition()
		for sceneName, scene in pairs(self.Scenes) do
			scene.MouseReleased:Fire(mousePos.X,mousePos.Y,button)
		end
	end))
	self.Maid:GiveTask(KeyboardPressed:Connect(function(...)
		for sceneName, scene in pairs(self.Scenes) do
			scene.KeyboardPressed:Fire(...)
		end
	end))
	self.Maid:GiveTask(KeyboardReleased:Connect(function(...)
		for sceneName, scene in pairs(self.Scenes) do
			scene.KeyboardReleased:Fire(...)
		end
	end))
	
	return self
end

function module:GetMousePosition()
	local x,y = love.mouse.getPosition()
	return Vector.new(x,y) - self.Camera.Position
end

function module:NewScene(name)
	local newScene = Scene.new()
	self.Scenes[name] = newScene
	newScene.Game = self
	self.Maid:GiveTask(newScene)
	return newScene
end

return module