local module = {}
module.__index = module

module.new = function()

end

return module