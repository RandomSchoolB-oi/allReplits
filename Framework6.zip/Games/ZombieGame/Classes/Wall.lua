local module = {}
module.__index = module

module.new = function()
	local box = Object.new()
	local collider = box:AddComponent("Collider")
	box:AddComponent("Renderer")
	
	ZombieGame.Scenes.Default:GiveObject(box)
	
	return box
end

return module