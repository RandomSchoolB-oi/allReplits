local module = {}
module.__index = module

module.new = function()
	local self = setmetatable({}, module)
	self.Maid = Maid.new()
	self.Object = Object.new()
	self.Object:AddComponent("Renderer")
	self.Object:AddComponent("Collider")

	self.WalkSpeed = 100
	self.MoveToPoint = nil
	self.MoveDirection = Vector.new(0, 0)

	self.Maid:GiveTask(ZombieGame.Scenes.Default.OnUpdate:Connect(function(dt)
		self:Update(dt)	
	end, 100))
	self.Maid:GiveTask(self.Object)
	ZombieGame.Scenes.Default:GiveObject(self.Object)
	
	return self
end

function module:MoveTo(position)
	self.MoveToPoint = position
end

function module:Move(direction)
	self.MoveDirection = direction
end

function module:Update(dt)
	if self.MoveToPoint then
		local normalized = self.MoveToPoint - self.Object.Position
		local magnitude = normalized.Magnitude
		if magnitude > 2 then
			self:Move(normalized/magnitude)
		end
	end
	-- local sizeOnAxis = self.Object.Size:Dot(self.MoveDirection)/2
	-- local origin = self.Object.CFrame.Position + self.MoveDirection * math.abs(sizeOnAxis)
	local direction = self.MoveDirection * self.WalkSpeed * dt
	
	-- local rayPart, rayPos, rayNormal = ZombieGame.Scenes.Default:Raycast(origin, direction, "bl", {self.Object})
	
	-- if rayPart then
	-- 	return
	-- end

	self.MoveDirection.X = 0
	self.MoveDirection.Y = 0
	local canMove = true
	
	local collider = self.Object:GetComponent("Collider")
	local pos = self.Object.CFrame.Position+direction
	for object in pairs(ZombieGame.Scenes.Default.Objects) do
		if object ~= self.Object then
			local otherCollider = object:GetComponent("Collider")
			if otherCollider then
				if math.AABB(pos, self.Object.Size, object.CFrame.Position, object.Size) then
					canMove = false
				end
			end
		end
	end

	if canMove then
		self.Object.CFrame.X = pos.X
		self.Object.CFrame.Y = pos.Y
	end
end

return module