local module = {}

module.GetMovementDelta = function()
	local dir = Vector.new(0, 0)

	if love.keyboard.isDown("w") then
		dir.Y = dir.Y - 1
	end
	if love.keyboard.isDown("s") then
		dir.Y = dir.Y + 1
	end
	if love.keyboard.isDown("a") then
		dir.X = dir.X - 1
	end
	if love.keyboard.isDown("d") then
		dir.X = dir.X + 1
	end

	if dir.Magnitude > 0.1 then
		return dir.Unit
	end

	return dir
end

return module