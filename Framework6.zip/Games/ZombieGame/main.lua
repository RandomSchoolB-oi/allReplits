local ogReq = require
local function require(dir)
	return ogReq("Games/ZombieGame/"..dir)
end
ZombieGame = Game.new()
local InputUtil = require("Utilities/InputUtil")
local WallClass = require("Classes/Wall")
local CharacterClass = require("Classes/Character")

ZombieGame.Camera:ChangeSize(Vector.new(500,500))

do
	local camSize = ZombieGame.Camera.Size
	local northWall = WallClass.new()
	northWall.Size = Vector.new(camSize.X, 10)
	northWall.CFrame = CFrame.new(camSize.X/2, 0)
	local southWall = WallClass.new()
	southWall.Size = Vector.new(camSize.X, 10)
	southWall.CFrame = CFrame.new(camSize.X/2, camSize.Y)
	local westWall = WallClass.new()
	westWall.Size = Vector.new(10, camSize.Y)
	westWall.CFrame = CFrame.new(0, camSize.Y/2)
	local eastWall = WallClass.new()
	eastWall.Size = Vector.new(10, camSize.Y)
	eastWall.CFrame = CFrame.new(camSize.X, camSize.Y/2)
end
	
local char = CharacterClass.new()
char.Object:GetComponent("Renderer").Image = "Games/ZombieGame/Images/SMG.png"
char.Object.CFrame = CFrame.new(100,100)
char.Object.Size = Vector.new(100,100)

ZombieGame.Scenes.Default.OnUpdate:Connect(function(dt)
	char:Move(InputUtil.GetMovementDelta())
	local mouseRotPos = ZombieGame.Camera:GetMousePos()-char.Object.CFrame.Position
	char.Object.CFrame.R = math.atan2(mouseRotPos.Y, mouseRotPos.X)
	-- char.Object.CFrame = char.Object.CFrame * CFrame.new(50*dt)
end)