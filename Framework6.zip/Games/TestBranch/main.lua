local mainGame = Game.new()

local p = Object.new()
local collider = p:AddComponent("Collider")
p:AddComponent("Renderer")
p:AddComponent("Button")
p.Position = Vector.new(100,100)

mainGame.Scenes.Default:GiveObject(p)

local rayInstance, rayPos, rayNorm
local rayOrigin = Vector.new(300,300)

mainGame.Scenes.Default.OnUpdate:Connect(function()
	rayInstance, rayPos, rayNorm = mainGame.Scenes.Default:Raycast(rayOrigin, mainGame:GetMousePosition() - rayOrigin)
end)

mainGame.Scenes.Default.OnDraw:Connect(function()
	if rayPos then
		love.graphics.circle("fill", rayPos.X, rayPos.Y, 5)
		love.graphics.line(rayPos.X, rayPos.Y, rayPos.X + rayNorm.X * 10, rayPos.Y + rayNorm.Y * 10)
		love.graphics.line(rayPos.X, rayPos.Y, rayOrigin.X, rayOrigin.Y)
	end
end)