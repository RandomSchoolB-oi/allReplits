require("Framework/Utility/Math")
require("Framework/Utility/Table")

Vector = require("Framework/BaseClasses/Vector")
CFrame = require("Framework/BaseClasses/CFrame")
Color = require("Framework/BaseClasses/Color")
Signal = require("Framework/BaseClasses/Signal")
Object = require("Framework/BaseClasses/Object")
Maid = require("Framework/BaseClasses/Maid")

Camera = require("Framework/BaseClasses/Camera")
Game = require("Framework/BaseClasses/Game")
Scene = require("Framework/BaseClasses/Scene")

OnDraw = Signal.new()
OnUpdate = Signal.new()
MousePressed = Signal.new()
MouseReleased = Signal.new()
KeyboardPressed = Signal.new()
KeyboardReleased = Signal.new()

function typeof(val)
	local t = type(val)
	if t == "table" and val.ClassName then
		return val.ClassName
	end
	return t
end

local function reqDirectory(dir)
	local list = {}
	local folders = {}
	for _, fileName in ipairs(love.filesystem.getDirectoryItems(dir)) do
		local value
		local fileDir = dir.."/"..fileName
		if fileName:find(".lua") then
			local modName = fileName:gsub(".lua", "")
			list[modName] = require(modName)
		else
			list[fileName] = reqDirectory(fileDir)
		end
	end
	return list
end

do
	AllComponents = {}
	local function loadComponentFolder(dir)
		for _, fileName in ipairs(love.filesystem.getDirectoryItems(dir)) do
			local value
			local fileDir = dir.."/"..fileName
			if fileName:find(".lua") then
				local modName = fileName:gsub(".lua", "")
				AllComponents[modName] = require(dir.."/"..modName)
			else
				loadComponentFolder(fileDir)
			end
		end
	end
	loadComponentFolder("Framework/Components")
	for componentName, component in pairs(AllComponents) do
		if component.Inherits then
			local inheritClass = require("Framework/"..component.Inherits)
			component.InheritClass = inheritClass
			setmetatable(component, inheritClass)
		end
	end
end



-- require("Games/TestBranch/main")
require("Games/ZombieGame/main")

love.draw = function(...)
	OnDraw:Fire(...)
end
love.update = function(...)
	OnUpdate:Fire(...)
end
love.mousepressed = function(...)
	MousePressed:Fire(...)
end
love.mousereleased = function(...)
	MouseReleased:Fire(...)
end
love.keypressed = function(...)
	KeyboardPressed:Fire(...)
end
love.keyreleased = function(...)
	KeyboardReleased:Fire(...)
end