Color3 = {}
Color3.__index = Color3

Color3.__add = function(self, other)
	if type(other) == "number" then
		self.R = self.R + other
		self.G = self.G + other
		self.B = self.B + other
		return self
	else
		self.R = self.R + other.R
		self.G = self.G + other.G
		self.B = self.B + other.B
		return self
	end
end

Color3.__sub = function(self, other)
	if type(other) == "number" then
		self.R = self.R - other
		self.G = self.G - other
		self.B = self.B - other
		return self
	else
		self.R = self.R - other.R
		self.G = self.G - other.G
		self.B = self.B - other.B
		return self
	end
end

Color3.__mul = function(self, other)
	if type(other) == "number" then
		self.R = self.R * other
		self.G = self.G * other
		self.B = self.B * other
		return self
	else
		self.R = self.R * other.R
		self.G = self.G * other.G
		self.B = self.B * other.B
		return self
	end
end

Color3.__div = function(self, other)
	if type(other) == "number" then
		self.R = self.R / other
		self.G = self.G / other
		self.B = self.B / other
		return self
	else
		self.R = self.R / other.R
		self.G = self.G / other.G
		self.B = self.B / other.B
		return self
	end
end

Color3.__mod = function(self, other)
	if type(other) == "number" then
		self.R = self.R % other
		self.G = self.G % other
		self.B = self.B % other
		return self
	else
		self.R = self.R % other.R
		self.G = self.G % other.G
		self.B = self.B % other.B
		return self
	end
end

Color3.__pow = function(self, other)
	if type(other) == "number" then
		self.R = self.R ^ other
		self.G = self.G ^ other
		self.B = self.B ^ other
		return self
	else
		self.R = self.R ^ other.R
		self.G = self.G ^ other.G
		self.B = self.B ^ other.B
		return self
	end
end

Color3.__tostring = function(self)
	return tostring(self.R)..", "..tostring(self.G)..", "..tostring(self.B)
end

Color3.__call = function(self)
	return self.R, self.G, self.B
end

Color3.new = function(r, g, b) -- from 0 to 1
	local color = {}
	color.R = r
	color.G = g
	color.B = b

	return setmetatable(color, Color3)
end

Color3.fromRGB = function(r, g, b) -- from 0 to 255
	local color = {}
	color.R = r / 255
	color.G = g / 255
	color.B = b / 255

	return setmetatable(color, Color3)
end

return Color3