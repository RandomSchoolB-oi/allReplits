require("Color3")
require("Vector2")
button = {}
button.__index = button

local colorOffset = Color3.new(0.1,0.1,0.1)

local inside = function(pos1,size1, pos2,size2)
	local x1,y1 = pos1()
	local x2,y2 = pos2()
	local w1,h1 = size1()
	local w2,h2 = size2()
	return x1 > x2 and x1 < x2 + w2 and y1 > y2 and y1 < y2 + h2
end

local mouse = function()
	return Vector2.new(love.mouse.getX(), love.mouse.getY()), Vector2.new(2,2,2) -- pos, size
end

function button.new()
	local new = {}
	new.position = Vector2.new(0, 0)
	new.size = Vector2.new(200, 50)
	new.color = Color3.new(1,1,1)
	new.textColor = Color3.new(0,0,0)
	new.text = ""
	new.autoColor = true
	new.mouseHover = nil
	new.mouseLeave = nil
	new.mouseButton1Down = nil
	new.mouseButton1Up = nil
	new.mouseButton2Down = nil
	new.mouseButton2Up = nil
	new.visible = true

	return setmetatable(new, button)
end

function button:update(dt)
	if self.visible then
		local pos, size = mouse()
		if inside(pos,size, self.position, self.size) then
			if not self._hovered then
				self._hovered = true
				if self.mouseHover then
					coroutine.wrap(self.mouseHover)()
				end
			end
			if not self._leftClicked and love.mouse.isDown(1) then
				self._leftClicked = true
				if self.mouseButton1Down then
					coroutine.wrap(self.mouseButton1Down)()
				end
			end
			if not self._rightClicked and love.mouse.isDown(2) then
				self._rightClicked = true
				if self.mouseButton2Down then
					coroutine.wrap(self.mouseButton2Down)()
				end
			end
		else
			if self._hovered then
				self._hovered = nil
				if self.mouseLeave then
					coroutine.wrap(self.mouseLeave)()
				end
			end
		end
		if self._leftClicked and not love.mouse.isDown(1) then
			self._leftClicked = nil
			if self.mouseButton1Up then
				coroutine.wrap(self.mouseButton1Up)()
			end
		end
		if self._rightClicked and not love.mouse.isDown(2) then
			self._rightClicked = nil
			if self.mouseButton2Up then
				coroutine.wrap(self.mouseButton2Up)()
			end
		end
	end
end

function button:draw()
	if self.visible then
		local pos, size = mouse()

		if inside(pos,size, self.position, self.size) then
			love.graphics.setColor(Color3.new(self.color.R - 0.15, self.color.G - 0.15, self.color.B - 0.15)())
		else
			love.graphics.setColor(self.color())
		end

		local x,y = self.position()
		local w,h = self.size()

		love.graphics.rectangle("fill", x,y,w,h)

		if self.text then
			love.graphics.setColor(self.textColor())
			love.graphics.printf(self.text, x,y,w, "center")
		end
	end
end

return button