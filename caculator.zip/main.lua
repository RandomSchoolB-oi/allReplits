
function love.draw()
    love.graphics.print("Hello World", 350, 250)
end