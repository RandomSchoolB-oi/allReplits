local GameClass = require("Game.Game")

Game = GameClass.new()

while true do
	Game:Step()
end