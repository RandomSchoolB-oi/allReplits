local module = {}
module.__index = module

local DialogClass = require("Game.Dialog")

module.new = function()
	local self = setmetatable({}, module)

	local message = DialogClass.new("", "awooga")
	local response1 = DialogClass.new("Yes", "asfdd")
	local response2 = DialogClass.new("no", "noooo")
	local response3 = DialogClass.new("nvm", "")
	response3:DirectsTo(message)
	message:Add(response1)
	message:Add(response2)
	response2:Add(response3)
	response3:WhenSelected(function()
		message.Response = "aw"..string.rep("o",message.Response:len()-3).."ga"
	end)
	
	self.CurrentDialog = message
	
	return self
end

function module:Display()
	local toPrint = {}

	if self.CurrentDialog then
		for _, v in ipairs(self.CurrentDialog:GetPrintList()) do
			table.insert(toPrint, v)
		end
	end

	os.execute("clear")
	for i = 1, #toPrint do
		print(toPrint[i])
	end
end

function module:ProcessInput(input)
	if self.CurrentDialog then
		local n = tonumber(input)
		self.CurrentDialog = self.CurrentDialog:Select(n)
	end
end

function module:Step()
	self:Display()

	local input = io.read()

	self:ProcessInput(input)
end

return module