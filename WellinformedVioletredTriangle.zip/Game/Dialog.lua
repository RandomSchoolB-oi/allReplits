local module = {}
module.__index = module

module.new = function(text, response, options)
	local self = setmetatable({}, module)
	self.Text = text
	self.Response = response
	self.Options = options or {}

	self.Callback = function() end
	
	return self
end

function module:WhenSelected(callback)
	self.Callback = callback
end

function module:Select(n)
	local newDialog = self.Options[n]
	if self.Options[n] then
		newDialog.Callback()
		if newDialog.DirectDialog then
			newDialog = newDialog.DirectDialog
			newDialog.Callback()
		end
		return newDialog
	end
	return self
end

function module:DirectsTo(dialog)
	self.DirectDialog = dialog
end

function module:Add(dialog)
	table.insert(self.Options, dialog)
end

function module:GetPrintList()
	local toPrint = {}
	table.insert(toPrint, self.Response)
	for i, v in ipairs(self.Options) do
		table.insert(toPrint, "["..tostring(i).."] - "..v.Text)
	end
	return toPrint
end

return module